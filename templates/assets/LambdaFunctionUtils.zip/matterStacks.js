"use strict";
/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: MIT-0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MatterStack = void 0;
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const aws_cloudtrail_1 = require("aws-cdk-lib/aws-cloudtrail");
const aws_s3_1 = require("aws-cdk-lib/aws-s3");
const aws_events_1 = require("aws-cdk-lib/aws-events");
const aws_backup_1 = require("aws-cdk-lib/aws-backup");
const aws_logs_1 = require("aws-cdk-lib/aws-logs");
const pca = require("aws-cdk-lib/aws-acmpca");
const aws_s3_sqs_1 = require("@aws-solutions-constructs/aws-s3-sqs");
const aws_sqs_lambda_1 = require("@aws-solutions-constructs/aws-sqs-lambda");
const lambda = require("aws-cdk-lib/aws-lambda");
const custom_resources_1 = require("aws-cdk-lib/custom-resources");
const aws_ssm_1 = require("aws-cdk-lib/aws-ssm");
const aws_kms_1 = require("aws-cdk-lib/aws-kms");
class MatterStack extends aws_cdk_lib_1.Stack {
    constructor(scope, id, prefix, genPaiCnt) {
        super(scope, id);
        // Note that CFN parameters are ony defined when you deploy resulting CFN template and provide values for them.
        const root = genPaiCnt === undefined;
        let paaRegion = this.region;
        if (root) {
            // Create Or Fetch PAA
            let paaArn;
            if (this.node.tryGetContext('generatePaa') === undefined) {
                paaArn = new aws_cdk_lib_1.CfnParameter(this, "paaArn", {
                    type: "String",
                    description: "The ARN of the Private Certificate Authority CA that is used as the Matter Product Attestation " +
                        "Authority (PAA)."
                }).valueAsString;
            }
            else {
                const validityInDays = new aws_cdk_lib_1.CfnParameter(this, "validityInDays", {
                    type: "Number",
                    description: "Validity in days for new PAA",
                    default: 3650
                }).valueAsNumber;
                const validityEndDate = new aws_cdk_lib_1.CfnParameter(this, "validityEndDate", {
                    type: "String",
                    description: "Validity End Date, is optional and overrides validityInDays. It's in YYYYMMDDHHMMSS format.",
                    default: ''
                }).valueAsString;
                const vendorIdInput = new aws_cdk_lib_1.CfnParameter(this, "vendorId", {
                    type: "String",
                    description: "The vendorId associated with this PAA. This must be a 4-digit hex value."
                }).valueAsString;
                const vendorId = this.validateVid(vendorIdInput);
                let commonName = new aws_cdk_lib_1.CfnParameter(this, 'paaCommonName', {
                    type: "String",
                    description: "The Common Name for this PAA."
                }).valueAsString;
                let paaOrganization = new aws_cdk_lib_1.CfnParameter(this, 'paaOrganization', {
                    type: "String",
                    description: "The Organization associated with this PAA."
                }).valueAsString;
                let paaOrganizationUnit = new aws_cdk_lib_1.CfnParameter(this, 'paaOU', {
                    type: "String",
                    description: "The Organizational Unit associated with this PAA.",
                    default: ''
                }).valueAsString;
                const validity = this.createPcaValidityInstance(validityInDays, validityEndDate);
                const paaActivation = this.createPAA(commonName, paaOrganization, paaOrganizationUnit, validity, vendorId);
                paaArn = paaActivation.certificateAuthorityArn;
            }
            // Global resources.
            this.matterManagePAARole = this.createMatterManagePAARole(prefix + MatterStack.MATTER_MANAGE_PAA_ROLE_NAME, paaArn);
            this.matterIssuePAIRole = this.createMatterIssuePAIRole(prefix + MatterStack.MATTER_ISSUE_PAI_ROLE_NAME, paaArn);
            this.matterAuditorRole = this.createMatterAuditorRole(prefix + MatterStack.MATTER_AUDITOR_ROLE_NAME, paaArn);
            this.matterAuditLoggingBackupRole = this.createMatterAuditLoggingBackupRole(prefix + MatterStack.MATTER_AUDIT_LOGGING_BACKUP_ROLE_NAME);
            this.matterIssueDACRole = this.createMatterIssueDACRole(prefix + MatterStack.MATTER_ISSUE_DAC_ROLE);
        }
        else {
            // Create PAI
            let prodIdsInput = new aws_cdk_lib_1.CfnParameter(this, "productIds", {
                type: "String",
                description: "A comma-separated list of product IDs associated with PAIs. These must be 4-digit hex values.",
                default: ''
            })?.valueAsString;
            const validityInDays = new aws_cdk_lib_1.CfnParameter(this, "validityInDays", {
                type: "Number",
                description: "Validity in days for new PAI(s)",
                default: 3600
            }).valueAsNumber;
            const validityEndDate = new aws_cdk_lib_1.CfnParameter(this, "validityEndDate", {
                type: "String",
                description: "Validity End Date, is optional and overrides validityInDays. It's in YYYYMMDDHHMMSS format.",
                default: ''
            }).valueAsString;
            const dacValidityInDays = new aws_cdk_lib_1.CfnParameter(this, "dacValidityInDays", {
                type: "Number",
                description: "Validity in days for DACs issued by the Lambda."
            }).valueAsNumber;
            const paaArn = new aws_cdk_lib_1.CfnParameter(this, "paaArn", {
                type: "String",
                description: "ARN of the PAA"
            }).valueAsString;
            paaRegion = aws_cdk_lib_1.Arn.split(paaArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME).region;
            const prodIdsSet = new aws_cdk_lib_1.CfnCondition(this, 'PidsWereProvided', {
                expression: aws_cdk_lib_1.Fn.conditionNot(aws_cdk_lib_1.Fn.conditionEquals(prodIdsInput, ''))
            });
            const prodIds = this.validatePids(prodIdsInput, prodIdsSet);
            let commonNames = new aws_cdk_lib_1.CfnParameter(this, 'paiCommonNames', {
                type: "String",
                description: "The Common Name for this PAI"
            }).valueAsString;
            let organizations = new aws_cdk_lib_1.CfnParameter(this, 'paiOrganizations', {
                type: "String",
                description: "The Organization associated with this PAI"
            }).valueAsString;
            let organizationalUnits = new aws_cdk_lib_1.CfnParameter(this, 'paiOrganizationalUnits', {
                type: "String",
                description: "The Organizational Unit associated with this PAI",
                default: ''
            }).valueAsString;
            const ouSet = new aws_cdk_lib_1.CfnCondition(this, "paiOUWasProvided", {
                expression: aws_cdk_lib_1.Fn.conditionNot(aws_cdk_lib_1.Fn.conditionEquals(organizationalUnits, ''))
            });
            const vendorId = this.getPaaVendorId(paaArn, paaRegion);
            const paaPem = this.getCertificatePem(id, paaArn, paaRegion);
            const validity = this.createPcaValidityStrings(validityInDays, validityEndDate);
            for (let index = 0; index < parseInt(genPaiCnt); index++) {
                const commonName = aws_cdk_lib_1.Fn.select(index, aws_cdk_lib_1.Fn.split(',', commonNames));
                const organization = aws_cdk_lib_1.Fn.select(index, aws_cdk_lib_1.Fn.split(',', organizations));
                const organizationalUnit = aws_cdk_lib_1.Fn.conditionIf(ouSet.logicalId, aws_cdk_lib_1.Fn.select(index, aws_cdk_lib_1.Fn.split(',', organizationalUnits)), '');
                this.createPAI(commonName, organization, organizationalUnit, ouSet, validity, vendorId, index, prodIds, prodIdsSet, paaArn, paaRegion, paaPem);
            }
            // Global resources.
            this.matterManagePAARole =
                aws_iam_1.Role.fromRoleName(this, "MatterManagePAARoleInPAIStack", MatterStack.MATTER_MANAGE_PAA_ROLE_NAME);
            this.matterIssuePAIRole =
                aws_iam_1.Role.fromRoleName(this, "MatterIssuePAIRoleInPAIStack", MatterStack.MATTER_ISSUE_PAI_ROLE_NAME);
            this.matterAuditorRole =
                aws_iam_1.Role.fromRoleName(this, "MatterAuditorRoleInPAIStack", MatterStack.MATTER_AUDITOR_ROLE_NAME);
            this.matterAuditLoggingBackupRole = aws_iam_1.Role.fromRoleName(this, "MatterAuditLoggingBackupRoleInPAIStack", MatterStack.MATTER_AUDIT_LOGGING_BACKUP_ROLE_NAME);
            this.matterIssueDACRole =
                aws_iam_1.Role.fromRoleName(this, "MatterIssueDACRoleInPAIStack", MatterStack.MATTER_ISSUE_DAC_ROLE);
            this.createDacIssuingLambda(dacValidityInDays);
        }
        // Regional resources shared between PAA and PAI stacks.
        const regionalSharedWithPAAStackResources = [];
        const [matterAuditLoggingBackupPlan, matterAuditLoggingBackupPlanTree] = this.createMatterAuditLoggingBackupPlan(prefix);
        regionalSharedWithPAAStackResources.push(...matterAuditLoggingBackupPlanTree);
        const [matterAuditLoggingBucket, matterAuditLoggingBucketTree] = this.createMatterAuditLoggingBucket(prefix, matterAuditLoggingBackupPlan);
        regionalSharedWithPAAStackResources.push(...matterAuditLoggingBucketTree);
        const [auditLogGroup, auditLogGroupTree] = this.createAuditLogGroup(prefix, root, matterAuditLoggingBucket, matterAuditLoggingBackupPlan);
        regionalSharedWithPAAStackResources.push(...auditLogGroupTree);
        const [, auditCloudTrailTree] = this.createAuditCloudTrail(prefix, root, auditLogGroup, matterAuditLoggingBucket);
        regionalSharedWithPAAStackResources.push(...auditCloudTrailTree);
        if (!root) {
            // Do not re-create regional shared with PAA Stack resources when adding PAIs into the same region.
            const createCondition = new aws_cdk_lib_1.CfnCondition(this, 'isMultiRegion', {
                // a condition needs an expression
                expression: aws_cdk_lib_1.Fn.conditionNot(aws_cdk_lib_1.Fn.conditionEquals(this.region, paaRegion))
            });
            regionalSharedWithPAAStackResources.map((v) => v.node.defaultChild).forEach((inst) => {
                inst.cfnOptions.condition = createCondition;
            });
        }
    }
    getPaaVendorId(paaArn, paaRegion) {
        const provider = aws_cdk_lib_1.CustomResourceProvider.getOrCreateProvider(this, 'Custom::LambdaFunctionUtils', {
            codeDirectory: `${__dirname}`,
            runtime: aws_cdk_lib_1.CustomResourceProviderRuntime.NODEJS_18_X,
            description: "Utility Lambda function"
        });
        provider.addToRolePolicy({
            Effect: 'Allow',
            Action: 'acm-pca:DescribeCertificateAuthority',
            Resource: paaArn,
        });
        return new aws_cdk_lib_1.CustomResource(this, 'ObtainPaaVid', {
            serviceToken: provider.serviceToken,
            resourceType: 'Custom::GetPaaVendorIdType',
            properties: {
                "command": "getPaaVendorId",
                "paaArn": paaArn,
                "paaRegion": paaRegion
            }
        }).getAtt('Result').toString();
    }
    validatePids(pids, pidsSet) {
        const provider = aws_cdk_lib_1.CustomResourceProvider.getOrCreateProvider(this, 'Custom::LambdaFunctionUtils', {
            codeDirectory: `${__dirname}`,
            runtime: aws_cdk_lib_1.CustomResourceProviderRuntime.NODEJS_18_X,
            description: "Utility Lambda function"
        });
        const outcome = new aws_cdk_lib_1.CustomResource(this, 'ValidatePid', {
            serviceToken: provider.serviceToken,
            resourceType: 'Custom::ValidatePidType',
            properties: {
                "command": "validateVidPid",
                "vid": undefined,
                "pids": aws_cdk_lib_1.Fn.conditionIf(pidsSet.logicalId, pids.split(','), ['AAAA'])
            }
        });
        return outcome.getAtt('pids').toStringList();
    }
    validateVid(vid) {
        const provider = aws_cdk_lib_1.CustomResourceProvider.getOrCreateProvider(this, 'Custom::LambdaFunctionUtils', {
            codeDirectory: `${__dirname}`,
            runtime: aws_cdk_lib_1.CustomResourceProviderRuntime.NODEJS_18_X,
            description: "Utility Lambda function"
        });
        const outcome = new aws_cdk_lib_1.CustomResource(this, 'ValidateVid', {
            serviceToken: provider.serviceToken,
            resourceType: 'Custom::ValidateVidType',
            properties: {
                "command": "validateVidPid",
                "vid": vid,
                "pids": undefined
            }
        });
        return outcome.getAtt('vid').toString();
    }
    // Creates the IAM role for issuing and revoking Device Attestation Certificates (DACs)
    createMatterIssueDACRole(roleName) {
        const matterIssueDACRole = new aws_iam_1.Role(this, roleName, {
            assumedBy: new aws_iam_1.AccountPrincipal(this.account),
            roleName: roleName,
            path: MatterStack.matterPKIRolesPath
        });
        aws_cdk_lib_1.Tags.of(matterIssueDACRole).add(MatterStack.matterPKITag, "");
        matterIssueDACRole.attachInlinePolicy(new aws_iam_1.Policy(this, `IssueDACCert`, {
            statements: this.getPolicyStatementsForDACIssuance(),
        }));
        return matterIssueDACRole;
    }
    getPolicyStatementsForDACIssuance() {
        return [
            new aws_iam_1.PolicyStatement({
                actions: ["acm-pca:IssueCertificate"],
                effect: aws_iam_1.Effect.ALLOW,
                resources: ["*"],
                conditions: {
                    StringLike: {
                        "acm-pca:TemplateArn": "arn:aws:acm-pca:::template/BlankEndEntityCertificate_CriticalBasicConstraints_APIPassthrough/V*"
                    },
                    StringEquals: {
                        "aws:ResourceTag/matterCAType": "pai"
                    }
                }
            }),
            new aws_iam_1.PolicyStatement({
                actions: ["acm-pca:IssueCertificate"],
                effect: aws_iam_1.Effect.DENY,
                resources: ["*"],
                conditions: {
                    StringNotLike: {
                        "acm-pca:TemplateArn": "arn:aws:acm-pca:::template/BlankEndEntityCertificate_CriticalBasicConstraints_APIPassthrough/V*"
                    },
                    StringEquals: {
                        "aws:ResourceTag/matterCAType": "pai"
                    }
                }
            }),
            new aws_iam_1.PolicyStatement({
                actions: ["acm-pca:RevokeCertificate",
                    "acm-pca:GetCertificate",
                    "acm-pca:GetCertificateAuthorityCertificate",
                    "acm-pca:DescribeCertificateAuthority"],
                effect: aws_iam_1.Effect.ALLOW,
                resources: ["*"],
                conditions: {
                    StringEquals: {
                        "aws:ResourceTag/matterCAType": "pai"
                    }
                }
            }),
            new aws_iam_1.PolicyStatement({
                actions: ["acm-pca:ListCertificateAuthorities"],
                effect: aws_iam_1.Effect.ALLOW,
                resources: ["*"],
            }),
        ];
    }
    // Creates the IAM role for creating and managing Product Attestation Intermediates (PAIs)
    createMatterIssuePAIRole(roleName, paaArn) {
        const matterIssuePAIRole = new aws_iam_1.Role(this, roleName, {
            assumedBy: new aws_iam_1.AccountPrincipal(this.account),
            roleName: roleName,
            path: MatterStack.matterPKIRolesPath
        });
        aws_cdk_lib_1.Tags.of(matterIssuePAIRole).add(MatterStack.matterPKITag, "");
        matterIssuePAIRole.attachInlinePolicy(new aws_iam_1.Policy(this, `IssuePAICert`, {
            statements: [
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:IssueCertificate"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: [paaArn],
                    conditions: {
                        StringLike: {
                            "acm-pca:TemplateArn": "arn:aws:acm-pca:::template/BlankSubordinateCACertificate_PathLen0_APIPassthrough/V*"
                        }
                    }
                }),
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:IssueCertificate"],
                    effect: aws_iam_1.Effect.DENY,
                    resources: [paaArn],
                    conditions: {
                        StringNotLike: {
                            "acm-pca:TemplateArn": "arn:aws:acm-pca:::template/BlankSubordinateCACertificate_PathLen0_APIPassthrough/V*"
                        }
                    }
                }),
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:GetCertificateAuthorityCertificate",
                        "acm-pca:ImportCertificateAuthorityCertificate",
                        "acm-pca:DeleteCertificateAuthority",
                        "acm-pca:UpdateCertificateAuthority",
                        "acm-pca:DescribeCertificateAuthority",
                        "acm-pca:GetCertificateAuthorityCsr"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: ["*"],
                    conditions: {
                        StringEquals: {
                            "aws:ResourceTag/matterCAType": "pai"
                        }
                    }
                }),
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:RevokeCertificate",
                        "acm-pca:GetCertificate",
                        "acm-pca:GetCertificateAuthorityCertificate",
                        "acm-pca:DescribeCertificateAuthority"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: [paaArn],
                }),
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:ListCertificateAuthorities",
                        "acm-pca:CreateCertificateAuthority",
                        "acm-pca:TagCertificateAuthority"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: ["*"],
                }),
            ],
        }));
        return matterIssuePAIRole;
    }
    // Creates the read-only IAM role for auditing the Matter PKI
    createMatterAuditorRole(roleName, paaArn) {
        const matterAuditorRole = new aws_iam_1.Role(this, roleName, {
            assumedBy: new aws_iam_1.AccountPrincipal(this.account),
            roleName: roleName,
            path: MatterStack.matterPKIRolesPath
        });
        aws_cdk_lib_1.Tags.of(matterAuditorRole).add(MatterStack.matterPKITag, "");
        matterAuditorRole.attachInlinePolicy(new aws_iam_1.Policy(this, `MatterAuditor`, {
            statements: [
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:CreateCertificateAuthorityAuditReport",
                        "acm-pca:DescribeCertificateAuthority",
                        "acm-pca:DescribeCertificateAuthorityAuditReport",
                        "acm-pca:GetCertificateAuthorityCsr",
                        "acm-pca:GetCertificateAuthorityCertificate",
                        "acm-pca:GetCertificate",
                        "acm-pca:GetPolicy",
                        "acm-pca:ListPermissions",
                        "acm-pca:ListTags"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: [paaArn],
                }),
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:CreateCertificateAuthorityAuditReport",
                        "acm-pca:DescribeCertificateAuthority",
                        "acm-pca:DescribeCertificateAuthorityAuditReport",
                        "acm-pca:GetCertificateAuthorityCsr",
                        "acm-pca:GetCertificateAuthorityCertificate",
                        "acm-pca:GetCertificate",
                        "acm-pca:GetPolicy",
                        "acm-pca:ListPermissions",
                        "acm-pca:ListTags"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: ["*"],
                    conditions: {
                        StringEquals: {
                            "aws:ResourceTag/matterCAType": "pai"
                        }
                    }
                })
            ],
        }));
        /*
            Note: This role gains access to the S3 bucket where the logs are stored via S3 resource policies when the bucket is created.
                  Access to the CloudWatch LogGroup is also granted below when the LogGroup is created.
        */
        return matterAuditorRole;
    }
    // Creates the IAM role for managing Product Attestation Authorities (PAAs)
    createMatterManagePAARole(roleName, paaArn) {
        const matterManagePAARole = new aws_iam_1.Role(this, roleName, {
            assumedBy: new aws_iam_1.AccountPrincipal(this.account),
            roleName: roleName,
            path: MatterStack.matterPKIRolesPath
        });
        aws_cdk_lib_1.Tags.of(matterManagePAARole).add(MatterStack.matterPKITag, "");
        matterManagePAARole.attachInlinePolicy(new aws_iam_1.Policy(this, `MatterPAA`, {
            statements: [
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:UpdateCertificateAuthority",
                        "acm-pca:DescribeCertificateAuthority",
                        "acm-pca:GetCertificate",
                        "acm-pca:GetCertificateAuthorityCertificate"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: [paaArn],
                }),
                new aws_iam_1.PolicyStatement({
                    actions: ["acm-pca:ListCertificateAuthorities"],
                    effect: aws_iam_1.Effect.ALLOW,
                    resources: ["*"],
                }),
            ],
        }));
        return matterManagePAARole;
    }
    // Create the backup plan using AWS Backup for the Matter PKI audit logging S3 bucket
    createMatterAuditLoggingBackupPlan(prefix) {
        const dependencies = [];
        const plan = new aws_backup_1.BackupPlan(this, prefix + "MatterAuditLoggingBackupPlan", {
            backupPlanName: prefix + "MatterAuditLoggingBackupPlan"
        });
        dependencies.push(plan);
        const vault = new aws_backup_1.BackupVault(this, prefix + "MatterAuditLoggingBackupVault", {
            backupVaultName: prefix + "MatterAuditLoggingBackupVault"
        });
        dependencies.push(vault);
        plan.addRule(new aws_backup_1.BackupPlanRule({
            backupVault: vault,
            ruleName: "RuleForMonthlyBackups",
            scheduleExpression: aws_events_1.Schedule.cron({ minute: '0', hour: '0', day: '1', month: '*', year: '*' }),
            deleteAfter: aws_cdk_lib_1.Duration.days(32), // 1 extra day, so that at-least one backup will stay in all conditions
        }));
        return [plan, dependencies];
    }
    // Creates the IAM role that will be used by AWSBackup to back-up data in audit logging S3 bucket
    createMatterAuditLoggingBackupRole(roleName) {
        return new aws_iam_1.Role(this, roleName, {
            roleName: roleName,
            assumedBy: new aws_iam_1.ServicePrincipal('backup.amazonaws.com'),
            managedPolicies: [
                aws_iam_1.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSBackupServiceRolePolicyForBackup'),
                aws_iam_1.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSBackupServiceRolePolicyForRestores'),
                aws_iam_1.ManagedPolicy.fromAwsManagedPolicyName('AWSBackupServiceRolePolicyForS3Backup'),
                aws_iam_1.ManagedPolicy.fromAwsManagedPolicyName('AWSBackupServiceRolePolicyForS3Restore'),
            ],
            path: MatterStack.matterPKIRolesPath
        });
    }
    // Creates the S3 bucket and Glacier vault that will contain the logs and audit data for Matter PKI.
    createMatterAuditLoggingBucket(prefix, matterAuditLoggingBackupPlan) {
        const dependencies = [];
        const bucketKMSKey = new aws_kms_1.Key(this, 'MatterPKIAuditLogsKMSKey', {
            enableKeyRotation: true
        });
        bucketKMSKey.grantEncrypt(new aws_iam_1.ServicePrincipal('cloudtrail.amazonaws.com'));
        dependencies.push(bucketKMSKey);
        const matterAuditLoggingBucket = new aws_s3_1.Bucket(this, prefix + `matter-pki-audit-logs`, {
            versioned: true,
            blockPublicAccess: {
                blockPublicPolicy: true,
                restrictPublicBuckets: true,
                blockPublicAcls: false,
                ignorePublicAcls: false
            },
            encryption: aws_s3_1.BucketEncryption.KMS,
            encryptionKey: bucketKMSKey,
            enforceSSL: true,
        });
        dependencies.push(matterAuditLoggingBucket);
        // Enable ObjectLock on S3 Bucket which makes objects write-once-read-many
        const cfnBucket = matterAuditLoggingBucket.node.defaultChild;
        cfnBucket.addPropertyOverride("ObjectLockEnabled", true);
        cfnBucket.addPropertyOverride("ObjectLockConfiguration.ObjectLockEnabled", "Enabled");
        cfnBucket.addPropertyOverride("ObjectLockConfiguration.Rule.DefaultRetention.Mode", "GOVERNANCE");
        cfnBucket.addPropertyOverride("ObjectLockConfiguration.Rule.DefaultRetention.Days", aws_logs_1.RetentionDays.FIVE_YEARS);
        // Grant Auditor role access to bucket
        matterAuditLoggingBucket.grantRead(new aws_iam_1.ArnPrincipal(this.matterAuditorRole.roleArn));
        // Add Lifecycle rule to move objects to Glacier after 2 months and keep them for 5 years
        matterAuditLoggingBucket.addLifecycleRule({
            id: 'MatterAuditLogsArchivingToGlacier',
            enabled: true,
            expiration: aws_cdk_lib_1.Duration.days(aws_logs_1.RetentionDays.FIVE_YEARS),
            transitions: [
                {
                    transitionAfter: aws_cdk_lib_1.Duration.days(aws_logs_1.RetentionDays.TWO_MONTHS),
                    storageClass: aws_s3_1.StorageClass.GLACIER,
                },
            ],
        });
        dependencies.push(matterAuditLoggingBackupPlan.addSelection("S3BackupSelection", {
            resources: [aws_backup_1.BackupResource.fromArn(matterAuditLoggingBucket.bucketArn)],
            role: this.matterAuditLoggingBackupRole
        }));
        return [matterAuditLoggingBucket, dependencies];
    }
    // Creates the CloudWatch LogGroup where matter PKI audit logs will be filtered and displayed.
    createAuditLogGroup(prefix, root, matterAuditLoggingBucket, matterAuditLoggingBackupPlan) {
        const dependencies = [];
        const logGroup = new aws_logs_1.LogGroup(this, prefix + "MatterAudit", {
            logGroupName: prefix + "MatterAudit",
            retention: aws_logs_1.RetentionDays.TWO_MONTHS
        });
        dependencies.push(logGroup);
        // Grant Auditor role access to LogGroup
        const logGroupActions = ["logs:Describe*",
            "logs:Get*",
            "logs:List*",
            "logs:StartQuery",
            "logs:StopQuery",
            "logs:TestMetricFilter",
            "logs:FilterLogEvents"];
        logGroup.grant(this.matterAuditorRole, ...logGroupActions);
        if (this.matterAuditorRole.node.tryFindChild('Policy'))
            dependencies.push(this.matterAuditorRole.node.tryFindChild('Policy'));
        // Filter LogGroup to contain only Matter relevant events
        dependencies.push(this.createMetricFilter(logGroup, 'AllPCAEventsFilter', '{ ($.eventSource = "acm-pca.amazonaws.com") }'));
        dependencies.push(this.createMetricFilter(logGroup, 'MatterAuditLoggingBucketFilter', '{ ($.eventSource= "s3.amazonaws.com") && ($.requestParameters.bucketName = "' + matterAuditLoggingBucket.bucketName + '*") }'));
        dependencies.push(this.createMetricFilter(logGroup, 'MatterTaggedFilter', MatterStack.matterPKITag));
        if (root) {
            dependencies.push(this.createMetricFilter(logGroup, 'MatterPAARoleFilter', 'iam.amazonaws.com ' + this.matterManagePAARole.roleName));
            dependencies.push(this.createMetricFilter(logGroup, 'MatterPAIRoleFilter', 'iam.amazonaws.com ' + this.matterIssuePAIRole.roleName));
        }
        else {
            dependencies.push(this.createMetricFilter(logGroup, 'MatterIssueDACRoleFilter', 'iam.amazonaws.com ' + this.matterIssueDACRole.roleName));
        }
        dependencies.push(this.createMetricFilter(logGroup, 'MatterAuditorRoleFilter', 'iam.amazonaws.com ' + this.matterAuditorRole.roleName));
        dependencies.push(this.createMetricFilter(logGroup, 'MatterAuditLoggingBackupRoleFilter', 'iam.amazonaws.com ' + this.matterAuditLoggingBackupRole.roleName));
        dependencies.push(this.createMetricFilter(logGroup, 'MatterAuditLoggingBackupPlanFilter', 'backup.amazonaws.com ' + matterAuditLoggingBackupPlan.backupPlanId));
        if (root) {
            new aws_cdk_lib_1.CfnOutput(this, 'LogGroupName', {
                value: logGroup.logGroupName,
                description: 'The name of the CloudWatch LogGroup',
            });
        }
        return [logGroup, dependencies];
    }
    // Creates the CloudTrail for recording AWS events which will be stored in S3
    createAuditCloudTrail(prefix, root, auditLogGroup, matterAuditLoggingBucket) {
        const dependencies = [];
        const trail = new aws_cloudtrail_1.Trail(this, prefix + 'MatterAuditTrail', {
            sendToCloudWatchLogs: true,
            enableFileValidation: true,
            bucket: matterAuditLoggingBucket,
            cloudWatchLogGroup: auditLogGroup,
            encryptionKey: matterAuditLoggingBucket.encryptionKey
        });
        dependencies.push(trail);
        const role = trail.node.findChild('LogsRole');
        const rolePolicy = role.node.findChild("DefaultPolicy");
        dependencies.push(rolePolicy);
        const s3EventSelector = {
            bucket: matterAuditLoggingBucket,
        };
        const bucketPolicy = matterAuditLoggingBucket.node.findChild('Policy');
        dependencies.push(bucketPolicy);
        trail.addS3EventSelector([s3EventSelector]);
        if (root) {
            new aws_cdk_lib_1.CfnOutput(this, 'CloudTrailArn', {
                value: trail.trailArn,
                description: 'The ARN of the CloudTrail',
            });
        }
        return [trail, dependencies];
    }
    createMetricFilter(logGroup, metricName, metricPattern) {
        return new aws_logs_1.MetricFilter(this, metricName, {
            metricName: metricName,
            filterPattern: {
                logPatternString: metricPattern
            },
            logGroup: logGroup,
            metricNamespace: 'CloudTrail'
        });
    }
    createPcaValidityInstance(validityInDays, validityEndDate) {
        const useValidityEndDate = new aws_cdk_lib_1.CfnCondition(this, 'ValidityEndDateWasProvided', {
            expression: aws_cdk_lib_1.Fn.conditionNot(aws_cdk_lib_1.Fn.conditionEquals(validityEndDate, ''))
        });
        return aws_cdk_lib_1.Fn.conditionIf(useValidityEndDate.logicalId, { Type: "END_DATE", Value: validityEndDate }, { Type: "DAYS", Value: validityInDays });
    }
    createPcaValidityStrings(validityInDays, validityEndDate) {
        const useValidityEndDate = new aws_cdk_lib_1.CfnCondition(this, 'ValidityEndDateWasProvided', {
            expression: aws_cdk_lib_1.Fn.conditionNot(aws_cdk_lib_1.Fn.conditionEquals(validityEndDate, ''))
        });
        return [aws_cdk_lib_1.Fn.conditionIf(useValidityEndDate.logicalId, "END_DATE", "DAYS"),
            aws_cdk_lib_1.Fn.conditionIf(useValidityEndDate.logicalId, validityEndDate, validityInDays)];
    }
    createPAA(commonName, organization, organizationalUnit, validity, vendorId) {
        const customAttributes = [
            {
                ObjectIdentifier: "2.5.4.3",
                Value: commonName
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.1",
                Value: vendorId
            },
            {
                ObjectIdentifier: "2.5.4.10",
                Value: organization
            }
        ];
        const customAttributesWithOU = [
            {
                ObjectIdentifier: "2.5.4.3",
                Value: commonName
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.1",
                Value: vendorId
            },
            {
                ObjectIdentifier: "2.5.4.10",
                Value: organization
            },
            {
                ObjectIdentifier: "2.5.4.11",
                Value: organizationalUnit
            }
        ];
        const useCustomAttrsWithOU = new aws_cdk_lib_1.CfnCondition(this, 'OrgUnitWasProvided', {
            expression: aws_cdk_lib_1.Fn.conditionNot(aws_cdk_lib_1.Fn.conditionEquals(organizationalUnit, ''))
        });
        const cfnCA = new pca.CfnCertificateAuthority(this, 'CA-PAA', {
            type: 'ROOT',
            keyAlgorithm: 'EC_prime256v1',
            signingAlgorithm: 'SHA256WITHECDSA',
            keyStorageSecurityStandard: 'FIPS_140_2_LEVEL_3_OR_HIGHER',
            subject: {
                customAttributes: aws_cdk_lib_1.Fn.conditionIf(useCustomAttrsWithOU.logicalId, customAttributesWithOU, customAttributes)
            },
            tags: [
                { key: "matterCAType", value: "paa" },
                { key: MatterStack.matterPKITag, value: "" }
            ],
        });
        // Staying on safe side here.
        cfnCA.cfnOptions.deletionPolicy = aws_cdk_lib_1.CfnDeletionPolicy.RETAIN;
        cfnCA.cfnOptions.updateReplacePolicy = aws_cdk_lib_1.CfnDeletionPolicy.RETAIN;
        const cfnCaCert = new pca.CfnCertificate(this, 'Cert-PAA', {
            certificateAuthorityArn: cfnCA.attrArn,
            certificateSigningRequest: cfnCA.attrCertificateSigningRequest,
            signingAlgorithm: 'SHA256WITHECDSA',
            validity: validity,
            // This template comes with keyCertSign, cRLSign, and digitalSignature Key Usage bits set.
            templateArn: "arn:aws:acm-pca:::template/RootCACertificate_APIPassthrough/V1"
        });
        new aws_cdk_lib_1.CfnOutput(this, 'PAACertArn', {
            value: cfnCaCert.attrArn,
            description: 'The ARN of the PAA certificate',
        });
        new aws_cdk_lib_1.CfnOutput(this, 'PAACertLink', {
            value: "https://console.aws.amazon.com/acm-pca/home?region=" + this.region + "#/details?arn=" + cfnCA.attrArn + "&tab=certificate",
            description: 'The link to the PAA certificate in the AWS Private CA console',
        });
        new aws_cdk_lib_1.CfnOutput(this, 'PAA', {
            value: "VID=" + vendorId + " CN=" + commonName + " " + cfnCA.attrArn,
            description: 'The ARN of the PAA',
        });
        return new pca.CfnCertificateAuthorityActivation(this, 'CertActivation' + '-PAA', {
            certificateAuthorityArn: cfnCA.attrArn,
            certificate: cfnCaCert.attrCertificate,
            status: "ACTIVE"
        });
    }
    createPAI(commonName, organization, organizationalUnit, organizationalUnitSet, validity, vendorId, paiId, productIds, productIdsSet, parentCAArn, parentRegion, parentPem) {
        const id = '-PAI-' + paiId;
        const pid = aws_cdk_lib_1.Fn.conditionIf(productIdsSet.logicalId, aws_cdk_lib_1.Fn.select(paiId, productIds), '');
        const customAttributes = [
            {
                ObjectIdentifier: "2.5.4.3",
                Value: commonName
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.1",
                Value: vendorId
            },
            {
                ObjectIdentifier: "2.5.4.10",
                Value: organization
            }
        ];
        const customAttributesWithPid = [
            {
                ObjectIdentifier: "2.5.4.3",
                Value: commonName
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.1",
                Value: vendorId
            },
            {
                ObjectIdentifier: "2.5.4.10",
                Value: organization
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.2",
                Value: pid
            }
        ];
        const customAttributesWithOu = [
            {
                ObjectIdentifier: "2.5.4.3",
                Value: commonName
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.1",
                Value: vendorId
            },
            {
                ObjectIdentifier: "2.5.4.10",
                Value: organization
            },
            {
                ObjectIdentifier: "2.5.4.11",
                Value: organizationalUnit
            }
        ];
        const customAttributesWithOuPid = [
            {
                ObjectIdentifier: "2.5.4.3",
                Value: commonName
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.1",
                Value: vendorId
            },
            {
                ObjectIdentifier: "2.5.4.10",
                Value: organization
            },
            {
                ObjectIdentifier: "2.5.4.11",
                Value: organizationalUnit
            },
            {
                ObjectIdentifier: "1.3.6.1.4.1.37244.2.2",
                Value: pid
            }
        ];
        const pidAndOuSet = new aws_cdk_lib_1.CfnCondition(this, `PaiPidAndOuWereProvided-${paiId}`, {
            expression: aws_cdk_lib_1.Fn.conditionAnd(productIdsSet, organizationalUnitSet)
        });
        const targetCustomAttributes = aws_cdk_lib_1.Fn.conditionIf(pidAndOuSet.logicalId, customAttributesWithOuPid, aws_cdk_lib_1.Fn.conditionIf(productIdsSet.logicalId, customAttributesWithPid, aws_cdk_lib_1.Fn.conditionIf(organizationalUnitSet.logicalId, customAttributesWithOu, customAttributes)));
        const cfnCA = new pca.CfnCertificateAuthority(this, 'CA' + id, {
            type: 'SUBORDINATE',
            keyAlgorithm: 'EC_prime256v1',
            signingAlgorithm: 'SHA256WITHECDSA',
            keyStorageSecurityStandard: 'FIPS_140_2_LEVEL_3_OR_HIGHER',
            subject: {
                customAttributes: targetCustomAttributes
            },
            tags: [
                { key: MatterStack.matterCATypeTag, value: "pai" },
                { key: MatterStack.matterPKITag, value: "" }
            ]
        });
        // Staying on safe side here.
        cfnCA.cfnOptions.deletionPolicy = aws_cdk_lib_1.CfnDeletionPolicy.RETAIN;
        cfnCA.cfnOptions.updateReplacePolicy = aws_cdk_lib_1.CfnDeletionPolicy.RETAIN;
        // CDK workaround.
        //
        // We need to remove '\n' characters from the CSR (which must be present). Otherwise, AwsCustomResource, while formatting Lambda
        // input JSON string, would add them as is, ending up with an invalid JSON. Instead, they need to be escaped like '\\n'.
        //
        // We could just use Fn.join('\\n', Fn.split('\n', ...)) if AwsCustomResource didn't escape those literals into  '\\\\n' and
        // '\\n', which prevents Fn.split() from finding any characters. We also cannot pass in any Token as a delimiter, it's not
        // supported.
        //
        // Here we simply write CSR with escaped newline characters into an SSM parameter, and then pass its value to AwsCustomResource.
        // This way we avoid any issues.
        const caCertCsrParam = new aws_ssm_1.StringParameter(this, this.node.id + '-PAI-CSR-' + paiId, {
            parameterName: '/' + this.node.id + '/PAI-CSR' + paiId,
            stringValue: aws_cdk_lib_1.Fn.join('\\n', aws_cdk_lib_1.Fn.split('\n', cfnCA.attrCertificateSigningRequest))
        });
        const caCertArn = new custom_resources_1.AwsCustomResource(this, 'Certificate' + id, {
            onUpdate: {
                service: 'ACMPCA',
                action: 'issueCertificate',
                parameters: {
                    CertificateAuthorityArn: parentCAArn,
                    Csr: caCertCsrParam.stringValue,
                    SigningAlgorithm: 'SHA256WITHECDSA',
                    Validity: {
                        Type: validity[0],
                        Value: aws_cdk_lib_1.Token.asNumber(validity[1])
                    },
                    TemplateArn: "arn:aws:acm-pca:::template/BlankSubordinateCACertificate_PathLen0_APIPassthrough/V1",
                    // Currently the only way to only set keyCertSign and cRLSign bits (and not digitalSignature) and get Matter-compatible certificate.
                    ApiPassthrough: {
                        Extensions: {
                            CustomExtensions: [
                                {
                                    ObjectIdentifier: '2.5.29.15',
                                    Value: 'AwIBBg==',
                                    Critical: true
                                }
                            ]
                        }
                    }
                },
                region: parentRegion,
                physicalResourceId: { id: Date.now().toString() } // Update physical id to always fetch the latest version
            },
            policy: {
                statements: [
                    new aws_iam_1.PolicyStatement({
                        resources: [parentCAArn],
                        actions: ['acm-pca:IssueCertificate'],
                        effect: aws_iam_1.Effect.ALLOW,
                    }),
                ],
            },
            installLatestAwsSdk: true // Standard, provided by Lambda, version doesn't have CustomExtensions!
        }).getResponseField('CertificateArn');
        const certificate = new custom_resources_1.AwsCustomResource(this, 'CertificatePem' + id, {
            onUpdate: {
                service: 'ACMPCA',
                action: 'getCertificate',
                parameters: {
                    CertificateArn: caCertArn,
                    CertificateAuthorityArn: parentCAArn
                },
                region: parentRegion,
                physicalResourceId: { id: Date.now().toString() } // Update physical id to always fetch the latest version
            },
            policy: {
                statements: [
                    new aws_iam_1.PolicyStatement({
                        resources: [parentCAArn],
                        actions: ['acm-pca:GetCertificate'],
                        effect: aws_iam_1.Effect.ALLOW,
                    }),
                ],
            },
            installLatestAwsSdk: false
        }).getResponseField('Certificate');
        const caCertArnOutputName = 'CertArnPAI' + paiId;
        new aws_cdk_lib_1.CfnOutput(this, caCertArnOutputName, {
            value: caCertArn,
            description: 'The certificate Arn for PAI' + paiId,
        });
        const caArnOutputName = 'PAI' + paiId;
        new aws_cdk_lib_1.CfnOutput(this, caArnOutputName, {
            value: "VID=" + vendorId + " PID=" + pid + " CN=" + commonName + " " + cfnCA.attrArn,
            description: 'The ARN of PAI' + paiId,
        });
        const certLinkOutputName = 'CertLinkPAI' + paiId;
        new aws_cdk_lib_1.CfnOutput(this, certLinkOutputName, {
            value: "https://console.aws.amazon.com/acm-pca/home?region=" + this.region + "#/details?arn=" + cfnCA.attrArn + "&tab=certificate",
            description: 'The link to the PAI certificate in the AWS Private CA console',
        });
        return new pca.CfnCertificateAuthorityActivation(this, 'CertActivation' + id, {
            certificateAuthorityArn: cfnCA.attrArn,
            certificate: certificate,
            certificateChain: parentPem,
            status: "ACTIVE"
        });
    }
    getCertificatePem(id, parentCAArn, parentRegion) {
        // Need to remove newline characters as we're going to pass it into JSON attribute.
        return new custom_resources_1.AwsCustomResource(this, 'PaaPem' + id, {
            onUpdate: {
                service: 'ACMPCA',
                action: 'getCertificateAuthorityCertificate',
                parameters: {
                    CertificateAuthorityArn: parentCAArn
                },
                region: parentRegion,
                physicalResourceId: { id: Date.now().toString() } // Update physical id to always fetch the latest version
            },
            policy: {
                statements: [
                    new aws_iam_1.PolicyStatement({
                        resources: [parentCAArn],
                        actions: ['acm-pca:GetCertificateAuthorityCertificate'],
                        effect: aws_iam_1.Effect.ALLOW,
                    }),
                ],
            },
            installLatestAwsSdk: false
        }).getResponseField('Certificate');
    }
    createDacIssuingLambda(dacValidityInDays) {
        const lambdaTimeout = aws_cdk_lib_1.Duration.minutes(1);
        const lambdaBatchSize = 5;
        const pcaIssueCertificateMaxTps = 25;
        const lambdaAvgExecTimeInSeconds = 11;
        const s3ToSqs = new aws_s3_sqs_1.S3ToSqs(this, 'DacInputS3ToSQS', {
            s3EventFilters: [
                { prefix: '', suffix: '.csr' }
            ],
            queueProps: {
                visibilityTimeout: aws_cdk_lib_1.Duration.minutes(lambdaTimeout.toMinutes() * 6), // Lambda's recommended at least 6 times.
            }
        });
        aws_cdk_lib_1.Tags.of(s3ToSqs.sqsQueue).add(MatterStack.matterPKITag, "");
        aws_cdk_lib_1.Tags.of(s3ToSqs.deadLetterQueue.queue).add(MatterStack.matterPKITag, "");
        aws_cdk_lib_1.Tags.of(s3ToSqs.s3Bucket).add(MatterStack.matterPKITag, "");
        aws_cdk_lib_1.Tags.of(s3ToSqs.s3LoggingBucket).add(MatterStack.matterPKITag, "");
        s3ToSqs.s3LoggingBucket?.grantRead(this.matterAuditorRole);
        const sqsToLambda = new aws_sqs_lambda_1.SqsToLambda(this, 'SqsToDacIssuingLambda', {
            existingQueueObj: s3ToSqs.sqsQueue,
            lambdaFunctionProps: {
                // https://docs.aws.amazon.com/lambda/latest/dg/java-package.html#java-package-gradle
                code: lambda.Code.fromAsset('lambda/build/distributions/lambda.zip'),
                runtime: lambda.Runtime.JAVA_11,
                handler: 'com.sample.Handler',
                timeout: lambdaTimeout,
                memorySize: 512,
                reservedConcurrentExecutions: pcaIssueCertificateMaxTps / lambdaBatchSize * lambdaAvgExecTimeInSeconds,
                logRetention: aws_logs_1.RetentionDays.TWO_MONTHS,
                environment: {
                    "dacValidityInDays": dacValidityInDays.toString()
                }
            },
            maxReceiveCount: 5,
            sqsEventSourceProps: {
                reportBatchItemFailures: true,
                batchSize: lambdaBatchSize,
                enabled: true
            }
        });
        aws_cdk_lib_1.Tags.of(sqsToLambda.lambdaFunction).add(MatterStack.matterPKITag, "");
        s3ToSqs.s3Bucket.grantReadWrite(sqsToLambda.lambdaFunction);
        for (const stmt of this.getPolicyStatementsForDACIssuance()) {
            sqsToLambda.lambdaFunction.addToRolePolicy(stmt);
        }
        const auditorLogGroupActions = ["logs:Describe*",
            "logs:Get*",
            "logs:List*",
            "logs:StartQuery",
            "logs:StopQuery",
            "logs:TestMetricFilter",
            "logs:FilterLogEvents"];
        sqsToLambda.lambdaFunction.logGroup.grant(this.matterAuditorRole, ...auditorLogGroupActions);
        new aws_cdk_lib_1.CfnOutput(this, 'DACIssuingLambdaFunctionName', {
            value: sqsToLambda.lambdaFunction.functionName,
            description: 'The name of the Lambda Function that issues DACs',
        });
    }
}
exports.MatterStack = MatterStack;
MatterStack.matterPKITag = "matterPKITag"; // The tag that should be attached to all PAIs created in PCA.
MatterStack.matterCATypeTag = "matterCAType"; // The tag that should be attached to all CAs created in PCA and have value "paa" or "pai" only.
MatterStack.MATTER_ISSUE_PAI_ROLE_NAME = "MatterIssuePAIRole";
MatterStack.MATTER_MANAGE_PAA_ROLE_NAME = "MatterManagePAARole";
MatterStack.MATTER_AUDITOR_ROLE_NAME = "MatterAuditorRole";
MatterStack.MATTER_AUDIT_LOGGING_BACKUP_ROLE_NAME = 'S3BackupRole';
MatterStack.MATTER_ISSUE_DAC_ROLE = "MatterIssueDACRole";
MatterStack.matterPKIRolesPath = "/MatterPKI/";
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0dGVyU3RhY2tzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWF0dGVyU3RhY2tzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7OztBQUVILDZDQWVxQjtBQUVyQixpREFVNkI7QUFDN0IsK0RBQWlFO0FBQ2pFLCtDQUF3RztBQUN4Ryx1REFBZ0Q7QUFDaEQsdURBQStGO0FBQy9GLG1EQUEyRTtBQUMzRSw4Q0FBOEM7QUFFOUMscUVBQTZEO0FBQzdELDZFQUFxRTtBQUNyRSxpREFBaUQ7QUFDakQsbUVBQStEO0FBQy9ELGlEQUFvRDtBQUNwRCxpREFBd0M7QUFFeEMsTUFBYSxXQUFZLFNBQVEsbUJBQUs7SUFrQmxDLFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsTUFBYyxFQUFFLFNBQTZCO1FBQ25GLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFakIsK0dBQStHO1FBRS9HLE1BQU0sSUFBSSxHQUFHLFNBQVMsS0FBSyxTQUFTLENBQUM7UUFDckMsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNwQyxJQUFJLElBQUksRUFBRTtZQUNOLHNCQUFzQjtZQUN0QixJQUFJLE1BQWMsQ0FBQztZQUNuQixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxLQUFLLFNBQVMsRUFBRTtnQkFDdEQsTUFBTSxHQUFHLElBQUksMEJBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFO29CQUN0QyxJQUFJLEVBQUUsUUFBUTtvQkFDZCxXQUFXLEVBQUUsaUdBQWlHO3dCQUNqRyxrQkFBa0I7aUJBQ2xDLENBQUMsQ0FBQyxhQUFhLENBQUM7YUFDcEI7aUJBQU07Z0JBQ0gsTUFBTSxjQUFjLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtvQkFDNUQsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsV0FBVyxFQUFFLDhCQUE4QjtvQkFDM0MsT0FBTyxFQUFFLElBQUk7aUJBQ2hCLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQ2pCLE1BQU0sZUFBZSxHQUFHLElBQUksMEJBQVksQ0FBQyxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7b0JBQzlELElBQUksRUFBRSxRQUFRO29CQUNkLFdBQVcsRUFBRSw2RkFBNkY7b0JBQzFHLE9BQU8sRUFBRSxFQUFFO2lCQUNkLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQ2pCLE1BQU0sYUFBYSxHQUFHLElBQUksMEJBQVksQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO29CQUNyRCxJQUFJLEVBQUUsUUFBUTtvQkFDZCxXQUFXLEVBQUUsMEVBQTBFO2lCQUMxRixDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUVqQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUVqRCxJQUFJLFVBQVUsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRTtvQkFDckQsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsV0FBVyxFQUFFLCtCQUErQjtpQkFDL0MsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQkFDakIsSUFBSSxlQUFlLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSxpQkFBaUIsRUFBRTtvQkFDNUQsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsV0FBVyxFQUFFLDRDQUE0QztpQkFDNUQsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQkFDakIsSUFBSSxtQkFBbUIsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRTtvQkFDdEQsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsV0FBVyxFQUFFLG1EQUFtRDtvQkFDaEUsT0FBTyxFQUFFLEVBQUU7aUJBQ2QsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQkFFakIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLGNBQWMsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFDakYsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsZUFBZSxFQUFFLG1CQUFtQixFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDM0csTUFBTSxHQUFHLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQTthQUNqRDtZQUVELG9CQUFvQjtZQUNwQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsMkJBQTJCLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDcEgsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLDBCQUEwQixFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2pILElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyx3QkFBd0IsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUM3RyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMscUNBQXFDLENBQUMsQ0FBQztZQUN4SSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMscUJBQXFCLENBQUMsQ0FBQztTQUN2RzthQUNJO1lBQ0QsYUFBYTtZQUNiLElBQUksWUFBWSxHQUFHLElBQUksMEJBQVksQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFO2dCQUNwRCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxXQUFXLEVBQUUsK0ZBQStGO2dCQUM1RyxPQUFPLEVBQUUsRUFBRTthQUNkLENBQUMsRUFBRSxhQUFhLENBQUM7WUFDbEIsTUFBTSxjQUFjLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtnQkFDNUQsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsV0FBVyxFQUFFLGlDQUFpQztnQkFDOUMsT0FBTyxFQUFFLElBQUk7YUFDaEIsQ0FBQyxDQUFDLGFBQWEsQ0FBQztZQUNqQixNQUFNLGVBQWUsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLGlCQUFpQixFQUFFO2dCQUM5RCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxXQUFXLEVBQUUsNkZBQTZGO2dCQUMxRyxPQUFPLEVBQUUsRUFBRTthQUNkLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFDakIsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLG1CQUFtQixFQUFFO2dCQUNsRSxJQUFJLEVBQUUsUUFBUTtnQkFDZCxXQUFXLEVBQUUsaURBQWlEO2FBQ2pFLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFDakIsTUFBTSxNQUFNLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUU7Z0JBQzVDLElBQUksRUFBRSxRQUFRO2dCQUNkLFdBQVcsRUFBRSxnQkFBZ0I7YUFDaEMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztZQUNqQixTQUFTLEdBQUcsaUJBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLHVCQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFPLENBQUM7WUFFckUsTUFBTSxVQUFVLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRTtnQkFDMUQsVUFBVSxFQUFFLGdCQUFFLENBQUMsWUFBWSxDQUFDLGdCQUFFLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQzthQUNwRSxDQUFDLENBQUM7WUFDSCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsQ0FBQztZQUU1RCxJQUFJLFdBQVcsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLGdCQUFnQixFQUFFO2dCQUN2RCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxXQUFXLEVBQUUsOEJBQThCO2FBQzlDLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFDakIsSUFBSSxhQUFhLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRTtnQkFDM0QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsV0FBVyxFQUFFLDJDQUEyQzthQUMzRCxDQUFDLENBQUMsYUFBYSxDQUFDO1lBQ2pCLElBQUksbUJBQW1CLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSx3QkFBd0IsRUFBRTtnQkFDdkUsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsV0FBVyxFQUFFLGtEQUFrRDtnQkFDL0QsT0FBTyxFQUFFLEVBQUU7YUFDZCxDQUFDLENBQUMsYUFBYSxDQUFDO1lBRWpCLE1BQU0sS0FBSyxHQUFHLElBQUksMEJBQVksQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7Z0JBQ3JELFVBQVUsRUFBRSxnQkFBRSxDQUFDLFlBQVksQ0FBQyxnQkFBRSxDQUFDLGVBQWUsQ0FBQyxtQkFBbUIsRUFBRSxFQUFFLENBQUMsQ0FBQzthQUMzRSxDQUFDLENBQUM7WUFFSCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztZQUN4RCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM3RCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsY0FBYyxFQUFFLGVBQWUsQ0FBQyxDQUFDO1lBQ2hGLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ3RELE1BQU0sVUFBVSxHQUFHLGdCQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxnQkFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztnQkFDaEUsTUFBTSxZQUFZLEdBQUcsZ0JBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLGdCQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNLGtCQUFrQixHQUFHLGdCQUFFLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsZ0JBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLGdCQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3JILElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxrQkFBa0IsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2FBQ2xKO1lBRUQsb0JBQW9CO1lBQ3BCLElBQUksQ0FBQyxtQkFBbUI7Z0JBQ3BCLGNBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLCtCQUErQixFQUFFLFdBQVcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFBO1lBQ3JHLElBQUksQ0FBQyxrQkFBa0I7Z0JBQ25CLGNBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLDhCQUE4QixFQUFFLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFBO1lBQ25HLElBQUksQ0FBQyxpQkFBaUI7Z0JBQ2xCLGNBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLDZCQUE2QixFQUFFLFdBQVcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO1lBQ2hHLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxjQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSx3Q0FBd0MsRUFDaEcsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLENBQUE7WUFDdEQsSUFBSSxDQUFDLGtCQUFrQjtnQkFDbkIsY0FBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsOEJBQThCLEVBQUUsV0FBVyxDQUFDLHFCQUFxQixDQUFDLENBQUE7WUFDOUYsSUFBSSxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDbEQ7UUFFRCx3REFBd0Q7UUFDeEQsTUFBTSxtQ0FBbUMsR0FBaUIsRUFBRSxDQUFDO1FBQzdELE1BQU0sQ0FBQyw0QkFBNEIsRUFBRSxnQ0FBZ0MsQ0FBQyxHQUFHLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6SCxtQ0FBbUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxnQ0FBZ0MsQ0FBQyxDQUFDO1FBQzlFLE1BQU0sQ0FBQyx3QkFBd0IsRUFBRSw0QkFBNEIsQ0FBQyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxNQUFNLEVBQUUsNEJBQTRCLENBQUMsQ0FBQztRQUMzSSxtQ0FBbUMsQ0FBQyxJQUFJLENBQUMsR0FBRyw0QkFBNEIsQ0FBQyxDQUFDO1FBQzFFLE1BQU0sQ0FBQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRSw0QkFBNEIsQ0FBQyxDQUFDO1FBQzFJLG1DQUFtQyxDQUFDLElBQUksQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUM7UUFFL0QsTUFBTSxDQUFDLEVBQUUsbUJBQW1CLENBQUMsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUNsSCxtQ0FBbUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxDQUFDO1FBRWpFLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDUCxtR0FBbUc7WUFDbkcsTUFBTSxlQUFlLEdBQUcsSUFBSSwwQkFBWSxDQUNwQyxJQUFJLEVBQ0osZUFBZSxFQUNmO2dCQUNJLGtDQUFrQztnQkFDbEMsVUFBVSxFQUFFLGdCQUFFLENBQUMsWUFBWSxDQUFDLGdCQUFFLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7YUFDMUUsQ0FDSixDQUFBO1lBQ0QsbUNBQW1DLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQTJCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtnQkFDaEcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsZUFBZSxDQUFDO1lBQ2hELENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sY0FBYyxDQUFDLE1BQWMsRUFBRSxTQUFpQjtRQUNwRCxNQUFNLFFBQVEsR0FBRyxvQ0FBc0IsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsNkJBQTZCLEVBQUU7WUFDN0YsYUFBYSxFQUFFLEdBQUcsU0FBUyxFQUFFO1lBQzdCLE9BQU8sRUFBRSwyQ0FBNkIsQ0FBQyxXQUFXO1lBQ2xELFdBQVcsRUFBRSx5QkFBeUI7U0FDekMsQ0FBQyxDQUFDO1FBQ0gsUUFBUSxDQUFDLGVBQWUsQ0FBQztZQUNyQixNQUFNLEVBQUUsT0FBTztZQUNmLE1BQU0sRUFBRSxzQ0FBc0M7WUFDOUMsUUFBUSxFQUFFLE1BQU07U0FDbkIsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxJQUFJLDRCQUFjLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUM1QyxZQUFZLEVBQUUsUUFBUSxDQUFDLFlBQVk7WUFDbkMsWUFBWSxFQUFFLDRCQUE0QjtZQUMxQyxVQUFVLEVBQUU7Z0JBQ1IsU0FBUyxFQUFFLGdCQUFnQjtnQkFDM0IsUUFBUSxFQUFFLE1BQU07Z0JBQ2hCLFdBQVcsRUFBRSxTQUFTO2FBQ3pCO1NBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQyxDQUFDO0lBRU8sWUFBWSxDQUFDLElBQVksRUFBRSxPQUFxQjtRQUNwRCxNQUFNLFFBQVEsR0FBRyxvQ0FBc0IsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsNkJBQTZCLEVBQUU7WUFDN0YsYUFBYSxFQUFFLEdBQUcsU0FBUyxFQUFFO1lBQzdCLE9BQU8sRUFBRSwyQ0FBNkIsQ0FBQyxXQUFXO1lBQ2xELFdBQVcsRUFBRSx5QkFBeUI7U0FDekMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxPQUFPLEdBQUcsSUFBSSw0QkFBYyxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDcEQsWUFBWSxFQUFFLFFBQVEsQ0FBQyxZQUFZO1lBQ25DLFlBQVksRUFBRSx5QkFBeUI7WUFDdkMsVUFBVSxFQUFFO2dCQUNSLFNBQVMsRUFBRSxnQkFBZ0I7Z0JBQzNCLEtBQUssRUFBRSxTQUFTO2dCQUNoQixNQUFNLEVBQUUsZ0JBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDdkU7U0FDSixDQUFDLENBQUM7UUFDSCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDbEQsQ0FBQztJQUVPLFdBQVcsQ0FBQyxHQUFXO1FBQzNCLE1BQU0sUUFBUSxHQUFHLG9DQUFzQixDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSw2QkFBNkIsRUFBRTtZQUM3RixhQUFhLEVBQUUsR0FBRyxTQUFTLEVBQUU7WUFDN0IsT0FBTyxFQUFFLDJDQUE2QixDQUFDLFdBQVc7WUFDbEQsV0FBVyxFQUFFLHlCQUF5QjtTQUN6QyxDQUFDLENBQUM7UUFDSCxNQUFNLE9BQU8sR0FBRyxJQUFJLDRCQUFjLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUNwRCxZQUFZLEVBQUUsUUFBUSxDQUFDLFlBQVk7WUFDbkMsWUFBWSxFQUFFLHlCQUF5QjtZQUN2QyxVQUFVLEVBQUU7Z0JBQ1IsU0FBUyxFQUFFLGdCQUFnQjtnQkFDM0IsS0FBSyxFQUFFLEdBQUc7Z0JBQ1YsTUFBTSxFQUFFLFNBQVM7YUFDcEI7U0FDSixDQUFDLENBQUM7UUFDSCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDN0MsQ0FBQztJQUVELHVGQUF1RjtJQUMvRSx3QkFBd0IsQ0FBQyxRQUFnQjtRQUM3QyxNQUFNLGtCQUFrQixHQUFHLElBQUksY0FBSSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUU7WUFDaEQsU0FBUyxFQUFFLElBQUksMEJBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUM3QyxRQUFRLEVBQUUsUUFBUTtZQUNsQixJQUFJLEVBQUUsV0FBVyxDQUFDLGtCQUFrQjtTQUN2QyxDQUFDLENBQUM7UUFFSCxrQkFBSSxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRTlELGtCQUFrQixDQUFDLGtCQUFrQixDQUNqQyxJQUFJLGdCQUFNLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUM3QixVQUFVLEVBQUUsSUFBSSxDQUFDLGlDQUFpQyxFQUFFO1NBQ3ZELENBQUMsQ0FDTCxDQUFDO1FBRUYsT0FBTyxrQkFBa0IsQ0FBQztJQUM5QixDQUFDO0lBRU8saUNBQWlDO1FBQ3JDLE9BQU87WUFDSCxJQUFJLHlCQUFlLENBQUM7Z0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDBCQUEwQixDQUFDO2dCQUNyQyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO2dCQUNwQixTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUM7Z0JBQ2hCLFVBQVUsRUFBRTtvQkFDUixVQUFVLEVBQUU7d0JBQ1IscUJBQXFCLEVBQUUsaUdBQWlHO3FCQUMzSDtvQkFDRCxZQUFZLEVBQUU7d0JBQ1YsOEJBQThCLEVBQUUsS0FBSztxQkFDeEM7aUJBQ0o7YUFDSixDQUFDO1lBQ0YsSUFBSSx5QkFBZSxDQUFDO2dCQUNoQixPQUFPLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztnQkFDckMsTUFBTSxFQUFFLGdCQUFNLENBQUMsSUFBSTtnQkFDbkIsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDO2dCQUNoQixVQUFVLEVBQUU7b0JBQ1IsYUFBYSxFQUFFO3dCQUNYLHFCQUFxQixFQUFFLGlHQUFpRztxQkFDM0g7b0JBQ0QsWUFBWSxFQUFFO3dCQUNWLDhCQUE4QixFQUFFLEtBQUs7cUJBQ3hDO2lCQUNKO2FBQ0osQ0FBQztZQUNGLElBQUkseUJBQWUsQ0FBQztnQkFDaEIsT0FBTyxFQUFFLENBQUMsMkJBQTJCO29CQUNqQyx3QkFBd0I7b0JBQ3hCLDRDQUE0QztvQkFDNUMsc0NBQXNDLENBQUM7Z0JBQzNDLE1BQU0sRUFBRSxnQkFBTSxDQUFDLEtBQUs7Z0JBQ3BCLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQztnQkFDaEIsVUFBVSxFQUFFO29CQUNSLFlBQVksRUFBRTt3QkFDViw4QkFBOEIsRUFBRSxLQUFLO3FCQUN4QztpQkFDSjthQUNKLENBQUM7WUFDRixJQUFJLHlCQUFlLENBQUM7Z0JBQ2hCLE9BQU8sRUFBRSxDQUFDLG9DQUFvQyxDQUFDO2dCQUMvQyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO2dCQUNwQixTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUM7YUFDbkIsQ0FBQztTQUNMLENBQUM7SUFDTixDQUFDO0lBRUwsMEZBQTBGO0lBQzlFLHdCQUF3QixDQUFDLFFBQWdCLEVBQUUsTUFBYztRQUM3RCxNQUFNLGtCQUFrQixHQUFHLElBQUksY0FBSSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUU7WUFDaEQsU0FBUyxFQUFFLElBQUksMEJBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUM3QyxRQUFRLEVBQUUsUUFBUTtZQUNsQixJQUFJLEVBQUUsV0FBVyxDQUFDLGtCQUFrQjtTQUN2QyxDQUFDLENBQUM7UUFFSCxrQkFBSSxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRTlELGtCQUFrQixDQUFDLGtCQUFrQixDQUNqQyxJQUFJLGdCQUFNLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUM3QixVQUFVLEVBQUU7Z0JBQ1IsSUFBSSx5QkFBZSxDQUFDO29CQUNoQixPQUFPLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztvQkFDckMsTUFBTSxFQUFFLGdCQUFNLENBQUMsS0FBSztvQkFDcEIsU0FBUyxFQUFFLENBQUMsTUFBTSxDQUFDO29CQUNuQixVQUFVLEVBQUU7d0JBQ1IsVUFBVSxFQUFHOzRCQUNULHFCQUFxQixFQUFFLHFGQUFxRjt5QkFDL0c7cUJBQ0o7aUJBQ0osQ0FBQztnQkFDRixJQUFJLHlCQUFlLENBQUM7b0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDBCQUEwQixDQUFDO29CQUNyQyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxJQUFJO29CQUNuQixTQUFTLEVBQUUsQ0FBQyxNQUFNLENBQUM7b0JBQ25CLFVBQVUsRUFBRTt3QkFDUixhQUFhLEVBQUc7NEJBQ1oscUJBQXFCLEVBQUUscUZBQXFGO3lCQUMvRztxQkFDSjtpQkFDSixDQUFDO2dCQUNGLElBQUkseUJBQWUsQ0FBQztvQkFDaEIsT0FBTyxFQUFFLENBQUMsNENBQTRDO3dCQUNsRCwrQ0FBK0M7d0JBQy9DLG9DQUFvQzt3QkFDcEMsb0NBQW9DO3dCQUNwQyxzQ0FBc0M7d0JBQ3RDLG9DQUFvQyxDQUFDO29CQUN6QyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO29CQUNwQixTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUM7b0JBQ2hCLFVBQVUsRUFBRTt3QkFDUixZQUFZLEVBQUc7NEJBQ1gsOEJBQThCLEVBQUUsS0FBSzt5QkFDeEM7cUJBQ0o7aUJBQ0osQ0FBQztnQkFDRixJQUFJLHlCQUFlLENBQUM7b0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDJCQUEyQjt3QkFDakMsd0JBQXdCO3dCQUN4Qiw0Q0FBNEM7d0JBQzVDLHNDQUFzQyxDQUFDO29CQUMzQyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO29CQUNwQixTQUFTLEVBQUUsQ0FBQyxNQUFNLENBQUM7aUJBQ3RCLENBQUM7Z0JBQ0YsSUFBSSx5QkFBZSxDQUFDO29CQUNoQixPQUFPLEVBQUUsQ0FBQyxvQ0FBb0M7d0JBQzFDLG9DQUFvQzt3QkFDcEMsaUNBQWlDLENBQUM7b0JBQ3RDLE1BQU0sRUFBRSxnQkFBTSxDQUFDLEtBQUs7b0JBQ3BCLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQztpQkFDbkIsQ0FBQzthQUNMO1NBQ0osQ0FBQyxDQUNMLENBQUM7UUFFRixPQUFPLGtCQUFrQixDQUFDO0lBQzlCLENBQUM7SUFFRCw2REFBNkQ7SUFDckQsdUJBQXVCLENBQUMsUUFBZ0IsRUFBRSxNQUFjO1FBQzVELE1BQU0saUJBQWlCLEdBQUcsSUFBSSxjQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRTtZQUMvQyxTQUFTLEVBQUUsSUFBSSwwQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1lBQzdDLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLElBQUksRUFBRSxXQUFXLENBQUMsa0JBQWtCO1NBQ3ZDLENBQUMsQ0FBQztRQUVILGtCQUFJLENBQUMsRUFBRSxDQUFDLGlCQUFpQixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFN0QsaUJBQWlCLENBQUMsa0JBQWtCLENBQ2hDLElBQUksZ0JBQU0sQ0FBQyxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQzlCLFVBQVUsRUFBRTtnQkFDUixJQUFJLHlCQUFlLENBQUM7b0JBQ2hCLE9BQU8sRUFBRSxDQUFDLCtDQUErQzt3QkFDckQsc0NBQXNDO3dCQUN0QyxpREFBaUQ7d0JBQ2pELG9DQUFvQzt3QkFDcEMsNENBQTRDO3dCQUM1Qyx3QkFBd0I7d0JBQ3hCLG1CQUFtQjt3QkFDbkIseUJBQXlCO3dCQUN6QixrQkFBa0IsQ0FBQztvQkFDdkIsTUFBTSxFQUFFLGdCQUFNLENBQUMsS0FBSztvQkFDcEIsU0FBUyxFQUFFLENBQUMsTUFBTSxDQUFDO2lCQUN0QixDQUFDO2dCQUNGLElBQUkseUJBQWUsQ0FBQztvQkFDaEIsT0FBTyxFQUFFLENBQUMsK0NBQStDO3dCQUNyRCxzQ0FBc0M7d0JBQ3RDLGlEQUFpRDt3QkFDakQsb0NBQW9DO3dCQUNwQyw0Q0FBNEM7d0JBQzVDLHdCQUF3Qjt3QkFDeEIsbUJBQW1CO3dCQUNuQix5QkFBeUI7d0JBQ3pCLGtCQUFrQixDQUFDO29CQUN2QixNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO29CQUNwQixTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUM7b0JBQ2hCLFVBQVUsRUFBRTt3QkFDUixZQUFZLEVBQUc7NEJBQ1gsOEJBQThCLEVBQUUsS0FBSzt5QkFDeEM7cUJBQ0o7aUJBQ0osQ0FBQzthQUNMO1NBQ0osQ0FBQyxDQUNMLENBQUM7UUFFRjs7O1VBR0U7UUFFRixPQUFPLGlCQUFpQixDQUFDO0lBQzdCLENBQUM7SUFFRCwyRUFBMkU7SUFDbkUseUJBQXlCLENBQUMsUUFBZ0IsRUFBRSxNQUFjO1FBQzlELE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxjQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRTtZQUNqRCxTQUFTLEVBQUUsSUFBSSwwQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1lBQzdDLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLElBQUksRUFBRSxXQUFXLENBQUMsa0JBQWtCO1NBQ3ZDLENBQUMsQ0FBQztRQUVILGtCQUFJLENBQUMsRUFBRSxDQUFDLG1CQUFtQixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFL0QsbUJBQW1CLENBQUMsa0JBQWtCLENBQ2xDLElBQUksZ0JBQU0sQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFO1lBQzFCLFVBQVUsRUFBRTtnQkFDUixJQUFJLHlCQUFlLENBQUM7b0JBQ2hCLE9BQU8sRUFBRSxDQUFDLG9DQUFvQzt3QkFDMUMsc0NBQXNDO3dCQUN0Qyx3QkFBd0I7d0JBQ3hCLDRDQUE0QyxDQUFDO29CQUNqRCxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO29CQUNwQixTQUFTLEVBQUUsQ0FBQyxNQUFNLENBQUM7aUJBQ3RCLENBQUM7Z0JBQ0YsSUFBSSx5QkFBZSxDQUFDO29CQUNoQixPQUFPLEVBQUUsQ0FBQyxvQ0FBb0MsQ0FBQztvQkFDL0MsTUFBTSxFQUFFLGdCQUFNLENBQUMsS0FBSztvQkFDcEIsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDO2lCQUNuQixDQUFDO2FBQ0w7U0FDSixDQUFDLENBQ0wsQ0FBQztRQUVGLE9BQU8sbUJBQW1CLENBQUM7SUFDL0IsQ0FBQztJQUVELHFGQUFxRjtJQUM3RSxrQ0FBa0MsQ0FBQyxNQUFjO1FBQ3JELE1BQU0sWUFBWSxHQUFpQixFQUFFLENBQUM7UUFFdEMsTUFBTSxJQUFJLEdBQUcsSUFBSSx1QkFBVSxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUcsOEJBQThCLEVBQUU7WUFDdkUsY0FBYyxFQUFFLE1BQU0sR0FBRyw4QkFBOEI7U0FDMUQsQ0FBQyxDQUFDO1FBQ0gsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixNQUFNLEtBQUssR0FBRyxJQUFJLHdCQUFXLENBQUMsSUFBSSxFQUFFLE1BQU0sR0FBRywrQkFBK0IsRUFBRTtZQUMxRSxlQUFlLEVBQUUsTUFBTSxHQUFHLCtCQUErQjtTQUM1RCxDQUFDLENBQUM7UUFDSCxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSwyQkFBYyxDQUFDO1lBQzVCLFdBQVcsRUFBRSxLQUFLO1lBQ2xCLFFBQVEsRUFBRSx1QkFBdUI7WUFDakMsa0JBQWtCLEVBQUUscUJBQVEsQ0FBQyxJQUFJLENBQUMsRUFBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUMsQ0FBQztZQUM1RixXQUFXLEVBQUUsc0JBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsdUVBQXVFO1NBQzFHLENBQUMsQ0FBQyxDQUFDO1FBRUosT0FBTyxDQUFDLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQsaUdBQWlHO0lBQ3pGLGtDQUFrQyxDQUFDLFFBQWdCO1FBQ3ZELE9BQU8sSUFBSSxjQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRTtZQUM1QixRQUFRLEVBQUUsUUFBUTtZQUNsQixTQUFTLEVBQUUsSUFBSSwwQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQztZQUN2RCxlQUFlLEVBQUU7Z0JBQ2IsdUJBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxrREFBa0QsQ0FBQztnQkFDMUYsdUJBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxvREFBb0QsQ0FBQztnQkFDNUYsdUJBQWEsQ0FBQyx3QkFBd0IsQ0FBQyx1Q0FBdUMsQ0FBQztnQkFDL0UsdUJBQWEsQ0FBQyx3QkFBd0IsQ0FBQyx3Q0FBd0MsQ0FBQzthQUNuRjtZQUNELElBQUksRUFBRSxXQUFXLENBQUMsa0JBQWtCO1NBQ3ZDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxvR0FBb0c7SUFDNUYsOEJBQThCLENBQUMsTUFBYyxFQUFFLDRCQUF3QztRQUMzRixNQUFNLFlBQVksR0FBaUIsRUFBRSxDQUFDO1FBRXRDLE1BQU0sWUFBWSxHQUFHLElBQUksYUFBRyxDQUFDLElBQUksRUFBRSwwQkFBMEIsRUFBRTtZQUMzRCxpQkFBaUIsRUFBRSxJQUFJO1NBQzFCLENBQUMsQ0FBQTtRQUNGLFlBQVksQ0FBQyxZQUFZLENBQUMsSUFBSSwwQkFBZ0IsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUM7UUFFNUUsWUFBWSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVoQyxNQUFNLHdCQUF3QixHQUFHLElBQUksZUFBTSxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUcsdUJBQXVCLEVBQUU7WUFDaEYsU0FBUyxFQUFFLElBQUk7WUFDZixpQkFBaUIsRUFBRTtnQkFDZixpQkFBaUIsRUFBRSxJQUFJO2dCQUN2QixxQkFBcUIsRUFBRSxJQUFJO2dCQUMzQixlQUFlLEVBQUUsS0FBSztnQkFDdEIsZ0JBQWdCLEVBQUUsS0FBSzthQUMxQjtZQUNELFVBQVUsRUFBRSx5QkFBZ0IsQ0FBQyxHQUFHO1lBQ2hDLGFBQWEsRUFBRSxZQUFZO1lBQzNCLFVBQVUsRUFBRSxJQUFJO1NBQ25CLENBQUMsQ0FBQztRQUNILFlBQVksQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUU1QywwRUFBMEU7UUFDMUUsTUFBTSxTQUFTLEdBQUcsd0JBQXdCLENBQUMsSUFBSSxDQUFDLFlBQXlCLENBQUM7UUFDMUUsU0FBUyxDQUFDLG1CQUFtQixDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3pELFNBQVMsQ0FBQyxtQkFBbUIsQ0FDekIsMkNBQTJDLEVBQzNDLFNBQVMsQ0FDWixDQUFDO1FBQ0YsU0FBUyxDQUFDLG1CQUFtQixDQUN6QixvREFBb0QsRUFDcEQsWUFBWSxDQUNmLENBQUM7UUFDRixTQUFTLENBQUMsbUJBQW1CLENBQ3pCLG9EQUFvRCxFQUNwRCx3QkFBYSxDQUFDLFVBQVUsQ0FDM0IsQ0FBQztRQUVGLHNDQUFzQztRQUN0Qyx3QkFBd0IsQ0FBQyxTQUFTLENBQzlCLElBQUksc0JBQVksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtRQUVyRCx5RkFBeUY7UUFDekYsd0JBQXdCLENBQUMsZ0JBQWdCLENBQUM7WUFDdEMsRUFBRSxFQUFFLG1DQUFtQztZQUN2QyxPQUFPLEVBQUUsSUFBSTtZQUNiLFVBQVUsRUFBRSxzQkFBUSxDQUFDLElBQUksQ0FBQyx3QkFBYSxDQUFDLFVBQVUsQ0FBQztZQUNuRCxXQUFXLEVBQUU7Z0JBQ1Q7b0JBQ0ksZUFBZSxFQUFFLHNCQUFRLENBQUMsSUFBSSxDQUFDLHdCQUFhLENBQUMsVUFBVSxDQUFDO29CQUN4RCxZQUFZLEVBQUUscUJBQVksQ0FBQyxPQUFPO2lCQUNyQzthQUNKO1NBQ0osQ0FBQyxDQUFDO1FBRUgsWUFBWSxDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxZQUFZLENBQUMsbUJBQW1CLEVBQUU7WUFDN0UsU0FBUyxFQUFFLENBQUMsMkJBQWMsQ0FBQyxPQUFPLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDdkUsSUFBSSxFQUFFLElBQUksQ0FBQyw0QkFBNEI7U0FDMUMsQ0FBQyxDQUFDLENBQUM7UUFFSixPQUFPLENBQUMsd0JBQXdCLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELDhGQUE4RjtJQUN2RixtQkFBbUIsQ0FBQyxNQUFjLEVBQUUsSUFBYSxFQUFFLHdCQUFnQyxFQUFFLDRCQUF3QztRQUNoSSxNQUFNLFlBQVksR0FBaUIsRUFBRSxDQUFBO1FBRXJDLE1BQU0sUUFBUSxHQUFHLElBQUksbUJBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxHQUFHLGFBQWEsRUFBRTtZQUN4RCxZQUFZLEVBQUUsTUFBTSxHQUFHLGFBQWE7WUFDcEMsU0FBUyxFQUFFLHdCQUFhLENBQUMsVUFBVTtTQUN0QyxDQUFDLENBQUM7UUFFSCxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTVCLHdDQUF3QztRQUN4QyxNQUFNLGVBQWUsR0FBRyxDQUFDLGdCQUFnQjtZQUNyQyxXQUFXO1lBQ1gsWUFBWTtZQUNaLGlCQUFpQjtZQUNqQixnQkFBZ0I7WUFDaEIsdUJBQXVCO1lBQ3ZCLHNCQUFzQixDQUFDLENBQUE7UUFDM0IsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxlQUFlLENBQUMsQ0FBQztRQUMzRCxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztZQUNsRCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBZSxDQUFDLENBQUM7UUFFeEYseURBQXlEO1FBQ3pELFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxvQkFBb0IsRUFBRSwrQ0FBK0MsQ0FBQyxDQUFDLENBQUM7UUFDNUgsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLGdDQUFnQyxFQUNsRSw4RUFBOEUsR0FBRyx3QkFBd0IsQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNuSixZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLEVBQUUsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDckcsSUFBSSxJQUFJLEVBQUU7WUFDTixZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUscUJBQXFCLEVBQUUsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDdEksWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLHFCQUFxQixFQUFFLG9CQUFvQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1NBQ3hJO2FBQU07WUFDSCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsMEJBQTBCLEVBQUUsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDN0k7UUFDRCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUseUJBQXlCLEVBQUUsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDeEksWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLG9DQUFvQyxFQUFFLG9CQUFvQixHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzlKLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxvQ0FBb0MsRUFBRSx1QkFBdUIsR0FBRyw0QkFBNEIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRWhLLElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSx1QkFBUyxDQUFDLElBQUksRUFBRSxjQUFjLEVBQUU7Z0JBQ2hDLEtBQUssRUFBRSxRQUFRLENBQUMsWUFBWTtnQkFDNUIsV0FBVyxFQUFFLHFDQUFxQzthQUNyRCxDQUFDLENBQUM7U0FDTjtRQUVELE9BQU8sQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELDZFQUE2RTtJQUN0RSxxQkFBcUIsQ0FBQyxNQUFjLEVBQUUsSUFBYSxFQUFFLGFBQXVCLEVBQUUsd0JBQWdDO1FBQ2pILE1BQU0sWUFBWSxHQUFpQixFQUFFLENBQUM7UUFFdEMsTUFBTSxLQUFLLEdBQUcsSUFBSSxzQkFBSyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUcsa0JBQWtCLEVBQUU7WUFDdkQsb0JBQW9CLEVBQUUsSUFBSTtZQUMxQixvQkFBb0IsRUFBRSxJQUFJO1lBQzFCLE1BQU0sRUFBRSx3QkFBd0I7WUFDaEMsa0JBQWtCLEVBQUUsYUFBYTtZQUNqQyxhQUFhLEVBQUUsd0JBQXdCLENBQUMsYUFBYTtTQUN4RCxDQUFDLENBQUM7UUFDSCxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXpCLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBUyxDQUFBO1FBQ3JELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBVyxDQUFDO1FBQ2xFLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFOUIsTUFBTSxlQUFlLEdBQW9CO1lBQ3JDLE1BQU0sRUFBRSx3QkFBd0I7U0FDbkMsQ0FBQztRQUNGLE1BQU0sWUFBWSxHQUFHLHdCQUF3QixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFXLENBQUM7UUFDakYsWUFBWSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVoQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1FBRTVDLElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSx1QkFBUyxDQUFDLElBQUksRUFBRSxlQUFlLEVBQUU7Z0JBQ2pDLEtBQUssRUFBRSxLQUFLLENBQUMsUUFBUTtnQkFDckIsV0FBVyxFQUFFLDJCQUEyQjthQUMzQyxDQUFDLENBQUM7U0FDTjtRQUVELE9BQU8sQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVPLGtCQUFrQixDQUFDLFFBQWtCLEVBQUUsVUFBa0IsRUFBRSxhQUFxQjtRQUNwRixPQUFPLElBQUksdUJBQVksQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3RDLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLGFBQWEsRUFBRTtnQkFDWCxnQkFBZ0IsRUFBRSxhQUFhO2FBQ2xDO1lBQ0QsUUFBUSxFQUFFLFFBQVE7WUFDbEIsZUFBZSxFQUFFLFlBQVk7U0FDaEMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLHlCQUF5QixDQUFDLGNBQXNCLEVBQUUsZUFBdUI7UUFDN0UsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLDRCQUE0QixFQUFFO1lBQzVFLFVBQVUsRUFBRSxnQkFBRSxDQUFDLFlBQVksQ0FBQyxnQkFBRSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDdkUsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxnQkFBRSxDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQzVCLEVBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFDLEVBQzFDLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFDLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRU8sd0JBQXdCLENBQUMsY0FBc0IsRUFBRSxlQUF1QjtRQUM1RSxNQUFNLGtCQUFrQixHQUFHLElBQUksMEJBQVksQ0FBQyxJQUFJLEVBQUUsNEJBQTRCLEVBQUU7WUFDNUUsVUFBVSxFQUFFLGdCQUFFLENBQUMsWUFBWSxDQUFDLGdCQUFFLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN2RSxDQUFDLENBQUM7UUFDSCxPQUFPLENBQUMsZ0JBQUUsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUM7WUFDaEUsZ0JBQUUsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsU0FBUyxFQUFFLGVBQWUsRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDO0lBQzNGLENBQUM7SUFFTyxTQUFTLENBQUMsVUFBa0IsRUFDbEIsWUFBb0IsRUFDcEIsa0JBQTBCLEVBQzFCLFFBQXFDLEVBQ3JDLFFBQWdCO1FBRTlCLE1BQU0sZ0JBQWdCLEdBQUc7WUFDckI7Z0JBQ0ksZ0JBQWdCLEVBQUUsU0FBUztnQkFDM0IsS0FBSyxFQUFFLFVBQVU7YUFDcEI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSx1QkFBdUI7Z0JBQ3pDLEtBQUssRUFBRSxRQUFRO2FBQ2xCO1lBQ0Q7Z0JBQ0ksZ0JBQWdCLEVBQUUsVUFBVTtnQkFDNUIsS0FBSyxFQUFFLFlBQVk7YUFDdEI7U0FDSixDQUFDO1FBRUYsTUFBTSxzQkFBc0IsR0FBRztZQUMzQjtnQkFDSSxnQkFBZ0IsRUFBRSxTQUFTO2dCQUMzQixLQUFLLEVBQUUsVUFBVTthQUNwQjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLHVCQUF1QjtnQkFDekMsS0FBSyxFQUFFLFFBQVE7YUFDbEI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSxVQUFVO2dCQUM1QixLQUFLLEVBQUUsWUFBWTthQUN0QjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLFVBQVU7Z0JBQzVCLEtBQUssRUFBRSxrQkFBa0I7YUFDNUI7U0FDSixDQUFDO1FBRUYsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLDBCQUFZLENBQUMsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQ3ZFLFVBQVUsRUFBRSxnQkFBRSxDQUFDLFlBQVksQ0FBQyxnQkFBRSxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN6RSxDQUFDLENBQUM7UUFFSCxNQUFNLEtBQUssR0FBRyxJQUFJLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFO1lBQzFELElBQUksRUFBRSxNQUFNO1lBQ1osWUFBWSxFQUFFLGVBQWU7WUFDN0IsZ0JBQWdCLEVBQUUsaUJBQWlCO1lBQ25DLDBCQUEwQixFQUFFLDhCQUE4QjtZQUMxRCxPQUFPLEVBQUU7Z0JBQ0wsZ0JBQWdCLEVBQUUsZ0JBQUUsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLHNCQUFzQixFQUFFLGdCQUFnQixDQUFDO2FBQzdHO1lBQ0QsSUFBSSxFQUFFO2dCQUNGLEVBQUUsR0FBRyxFQUFFLGNBQWMsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFO2dCQUNyQyxFQUFFLEdBQUcsRUFBRSxXQUFXLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUc7YUFDaEQ7U0FDSixDQUFDLENBQUM7UUFFSCw2QkFBNkI7UUFDN0IsS0FBSyxDQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsK0JBQWlCLENBQUMsTUFBTSxDQUFDO1FBQzNELEtBQUssQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEdBQUcsK0JBQWlCLENBQUMsTUFBTSxDQUFDO1FBRWhFLE1BQU0sU0FBUyxHQUFHLElBQUksR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3ZELHVCQUF1QixFQUFFLEtBQUssQ0FBQyxPQUFPO1lBQ3RDLHlCQUF5QixFQUFFLEtBQUssQ0FBQyw2QkFBNkI7WUFDOUQsZ0JBQWdCLEVBQUUsaUJBQWlCO1lBQ25DLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLDBGQUEwRjtZQUMxRixXQUFXLEVBQUUsZ0VBQWdFO1NBQ2hGLENBQUMsQ0FBQztRQUVILElBQUksdUJBQVMsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQzlCLEtBQUssRUFBRSxTQUFTLENBQUMsT0FBTztZQUN4QixXQUFXLEVBQUUsZ0NBQWdDO1NBQ2hELENBQUMsQ0FBQztRQUVILElBQUksdUJBQVMsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQy9CLEtBQUssRUFBQyxxREFBcUQsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxPQUFPLEdBQUcsa0JBQWtCO1lBQ2pJLFdBQVcsRUFBRSwrREFBK0Q7U0FDL0UsQ0FBQyxDQUFDO1FBRUgsSUFBSSx1QkFBUyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUU7WUFDdkIsS0FBSyxFQUFFLE1BQU0sR0FBRyxRQUFRLEdBQUcsTUFBTSxHQUFHLFVBQVUsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDLE9BQU87WUFDcEUsV0FBVyxFQUFFLG9CQUFvQjtTQUNwQyxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksR0FBRyxDQUFDLGlDQUFpQyxDQUFDLElBQUksRUFBRSxnQkFBZ0IsR0FBRyxNQUFNLEVBQUU7WUFDOUUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLE9BQU87WUFDdEMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxlQUFlO1lBQ3RDLE1BQU0sRUFBRSxRQUFRO1NBQ25CLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxTQUFTLENBQUMsVUFBa0IsRUFDbEIsWUFBb0IsRUFDcEIsa0JBQTJDLEVBQzNDLHFCQUFtQyxFQUNuQyxRQUE0RCxFQUM1RCxRQUFnQixFQUNoQixLQUFhLEVBQ2IsVUFBb0IsRUFDcEIsYUFBMkIsRUFDM0IsV0FBbUIsRUFDbkIsWUFBb0IsRUFDcEIsU0FBaUI7UUFFL0IsTUFBTSxFQUFFLEdBQUcsT0FBTyxHQUFHLEtBQU0sQ0FBQztRQUU1QixNQUFNLEdBQUcsR0FBRyxnQkFBRSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLGdCQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUV0RixNQUFNLGdCQUFnQixHQUFHO1lBQ3JCO2dCQUNJLGdCQUFnQixFQUFFLFNBQVM7Z0JBQzNCLEtBQUssRUFBRSxVQUFVO2FBQ3BCO1lBQ0Q7Z0JBQ0ksZ0JBQWdCLEVBQUUsdUJBQXVCO2dCQUN6QyxLQUFLLEVBQUUsUUFBUTthQUNsQjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLFVBQVU7Z0JBQzVCLEtBQUssRUFBRSxZQUFZO2FBQ3RCO1NBQ0osQ0FBQztRQUVGLE1BQU0sdUJBQXVCLEdBQUc7WUFDNUI7Z0JBQ0ksZ0JBQWdCLEVBQUUsU0FBUztnQkFDM0IsS0FBSyxFQUFFLFVBQVU7YUFDcEI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSx1QkFBdUI7Z0JBQ3pDLEtBQUssRUFBRSxRQUFRO2FBQ2xCO1lBQ0Q7Z0JBQ0ksZ0JBQWdCLEVBQUUsVUFBVTtnQkFDNUIsS0FBSyxFQUFFLFlBQVk7YUFDdEI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSx1QkFBdUI7Z0JBQ3pDLEtBQUssRUFBRSxHQUFHO2FBQ2I7U0FDSixDQUFDO1FBRUYsTUFBTSxzQkFBc0IsR0FBRztZQUMzQjtnQkFDSSxnQkFBZ0IsRUFBRSxTQUFTO2dCQUMzQixLQUFLLEVBQUUsVUFBVTthQUNwQjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLHVCQUF1QjtnQkFDekMsS0FBSyxFQUFFLFFBQVE7YUFDbEI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSxVQUFVO2dCQUM1QixLQUFLLEVBQUUsWUFBWTthQUN0QjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLFVBQVU7Z0JBQzVCLEtBQUssRUFBRSxrQkFBa0I7YUFDNUI7U0FDSixDQUFDO1FBRUYsTUFBTSx5QkFBeUIsR0FBRztZQUM5QjtnQkFDSSxnQkFBZ0IsRUFBRSxTQUFTO2dCQUMzQixLQUFLLEVBQUUsVUFBVTthQUNwQjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLHVCQUF1QjtnQkFDekMsS0FBSyxFQUFFLFFBQVE7YUFDbEI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSxVQUFVO2dCQUM1QixLQUFLLEVBQUUsWUFBWTthQUN0QjtZQUNEO2dCQUNJLGdCQUFnQixFQUFFLFVBQVU7Z0JBQzVCLEtBQUssRUFBRSxrQkFBa0I7YUFDNUI7WUFDRDtnQkFDSSxnQkFBZ0IsRUFBRSx1QkFBdUI7Z0JBQ3pDLEtBQUssRUFBRSxHQUFHO2FBQ2I7U0FDSixDQUFDO1FBRUYsTUFBTSxXQUFXLEdBQUcsSUFBSSwwQkFBWSxDQUFDLElBQUksRUFBRSwyQkFBMkIsS0FBSyxFQUFFLEVBQUU7WUFDM0UsVUFBVSxFQUFFLGdCQUFFLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxxQkFBcUIsQ0FBQztTQUNwRSxDQUFDLENBQUM7UUFDSCxNQUFNLHNCQUFzQixHQUN4QixnQkFBRSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLHlCQUF5QixFQUMzRCxnQkFBRSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLHVCQUF1QixFQUMzRCxnQkFBRSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLEVBQUUsc0JBQXNCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFeEcsTUFBTSxLQUFLLEdBQUcsSUFBSSxHQUFHLENBQUMsdUJBQXVCLENBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFLEVBQUU7WUFDM0QsSUFBSSxFQUFFLGFBQWE7WUFDbkIsWUFBWSxFQUFFLGVBQWU7WUFDN0IsZ0JBQWdCLEVBQUUsaUJBQWlCO1lBQ25DLDBCQUEwQixFQUFFLDhCQUE4QjtZQUMxRCxPQUFPLEVBQUU7Z0JBQ0wsZ0JBQWdCLEVBQUUsc0JBQXNCO2FBQzNDO1lBQ0QsSUFBSSxFQUFFO2dCQUNGLEVBQUUsR0FBRyxFQUFFLFdBQVcsQ0FBQyxlQUFlLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRTtnQkFDbEQsRUFBRSxHQUFHLEVBQUUsV0FBVyxDQUFDLFlBQVksRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFO2FBQy9DO1NBQ0osQ0FBQyxDQUFDO1FBRUgsNkJBQTZCO1FBQzdCLEtBQUssQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLCtCQUFpQixDQUFDLE1BQU0sQ0FBQztRQUMzRCxLQUFLLENBQUMsVUFBVSxDQUFDLG1CQUFtQixHQUFHLCtCQUFpQixDQUFDLE1BQU0sQ0FBQztRQUVoRSxrQkFBa0I7UUFDbEIsRUFBRTtRQUNGLGdJQUFnSTtRQUNoSSx3SEFBd0g7UUFDeEgsRUFBRTtRQUNGLDRIQUE0SDtRQUM1SCwwSEFBMEg7UUFDMUgsYUFBYTtRQUNiLEVBQUU7UUFDRixnSUFBZ0k7UUFDaEksZ0NBQWdDO1FBQ2hDLE1BQU0sY0FBYyxHQUFHLElBQUkseUJBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsV0FBVyxHQUFHLEtBQUssRUFBRTtZQUNqRixhQUFhLEVBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLFVBQVUsR0FBRyxLQUFLO1lBQ3RELFdBQVcsRUFBRSxnQkFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsZ0JBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1NBQ25GLENBQUMsQ0FBQztRQUVILE1BQU0sU0FBUyxHQUFHLElBQUksb0NBQWlCLENBQUMsSUFBSSxFQUFFLGFBQWEsR0FBRyxFQUFFLEVBQUU7WUFDOUQsUUFBUSxFQUFFO2dCQUNOLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixVQUFVLEVBQUU7b0JBQ1IsdUJBQXVCLEVBQUUsV0FBVztvQkFDcEMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxXQUFXO29CQUMvQixnQkFBZ0IsRUFBRSxpQkFBaUI7b0JBQ25DLFFBQVEsRUFBRTt3QkFDTixJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDakIsS0FBSyxFQUFFLG1CQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDckM7b0JBQ0QsV0FBVyxFQUFFLHFGQUFxRjtvQkFDbEcsb0lBQW9JO29CQUNwSSxjQUFjLEVBQUU7d0JBQ1osVUFBVSxFQUFFOzRCQUNSLGdCQUFnQixFQUFFO2dDQUNkO29DQUNJLGdCQUFnQixFQUFFLFdBQVc7b0NBQzdCLEtBQUssRUFBRSxVQUFVO29DQUNqQixRQUFRLEVBQUUsSUFBSTtpQ0FDakI7NkJBQ0o7eUJBQ0o7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTSxFQUFFLFlBQVk7Z0JBQ3BCLGtCQUFrQixFQUFFLEVBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBQyxDQUFDLHdEQUF3RDthQUMzRztZQUNELE1BQU0sRUFBRTtnQkFDSixVQUFVLEVBQUU7b0JBQ1IsSUFBSSx5QkFBZSxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQyxXQUFXLENBQUM7d0JBQ3hCLE9BQU8sRUFBRSxDQUFDLDBCQUEwQixDQUFDO3dCQUNyQyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO3FCQUN2QixDQUFDO2lCQUNMO2FBQ0o7WUFDRCxtQkFBbUIsRUFBRSxJQUFJLENBQUcsdUVBQXVFO1NBQ3RHLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXRDLE1BQU0sV0FBVyxHQUFHLElBQUksb0NBQWlCLENBQUMsSUFBSSxFQUFFLGdCQUFnQixHQUFHLEVBQUUsRUFBRTtZQUNuRSxRQUFRLEVBQUU7Z0JBQ04sT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLE1BQU0sRUFBRSxnQkFBZ0I7Z0JBQ3hCLFVBQVUsRUFBRTtvQkFDUixjQUFjLEVBQUUsU0FBUztvQkFDekIsdUJBQXVCLEVBQUUsV0FBVztpQkFDdkM7Z0JBQ0QsTUFBTSxFQUFFLFlBQVk7Z0JBQ3BCLGtCQUFrQixFQUFFLEVBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBQyxDQUFDLHdEQUF3RDthQUMzRztZQUNELE1BQU0sRUFBRTtnQkFDSixVQUFVLEVBQUU7b0JBQ1IsSUFBSSx5QkFBZSxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQyxXQUFXLENBQUM7d0JBQ3hCLE9BQU8sRUFBRSxDQUFDLHdCQUF3QixDQUFDO3dCQUNuQyxNQUFNLEVBQUUsZ0JBQU0sQ0FBQyxLQUFLO3FCQUN2QixDQUFDO2lCQUNMO2FBQ0o7WUFDRCxtQkFBbUIsRUFBRSxLQUFLO1NBQzdCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUVuQyxNQUFNLG1CQUFtQixHQUFHLFlBQVksR0FBRyxLQUFNLENBQUM7UUFFbEQsSUFBSSx1QkFBUyxDQUFDLElBQUksRUFBRSxtQkFBbUIsRUFBRTtZQUNyQyxLQUFLLEVBQUUsU0FBUztZQUNoQixXQUFXLEVBQUUsNkJBQTZCLEdBQUcsS0FBTTtTQUN0RCxDQUFDLENBQUM7UUFFSCxNQUFNLGVBQWUsR0FBRyxLQUFLLEdBQUcsS0FBTSxDQUFDO1FBRXZDLElBQUksdUJBQVMsQ0FBQyxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ2pDLEtBQUssRUFBRSxNQUFNLEdBQUcsUUFBUSxHQUFHLE9BQU8sR0FBRyxHQUFHLEdBQUcsTUFBTSxHQUFHLFVBQVUsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDLE9BQU87WUFDcEYsV0FBVyxFQUFFLGdCQUFnQixHQUFHLEtBQU07U0FDekMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxrQkFBa0IsR0FBRyxhQUFhLEdBQUcsS0FBTSxDQUFDO1FBRWxELElBQUksdUJBQVMsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDcEMsS0FBSyxFQUFDLHFEQUFxRCxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLE9BQU8sR0FBRyxrQkFBa0I7WUFDakksV0FBVyxFQUFFLCtEQUErRDtTQUMvRSxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksR0FBRyxDQUFDLGlDQUFpQyxDQUFDLElBQUksRUFBRSxnQkFBZ0IsR0FBRyxFQUFFLEVBQUU7WUFDMUUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLE9BQU87WUFDdEMsV0FBVyxFQUFFLFdBQVc7WUFDeEIsZ0JBQWdCLEVBQUUsU0FBUztZQUMzQixNQUFNLEVBQUUsUUFBUTtTQUNuQixDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8saUJBQWlCLENBQUMsRUFBVSxFQUFFLFdBQW1CLEVBQUUsWUFBb0I7UUFDM0UsbUZBQW1GO1FBQ25GLE9BQU8sSUFBSSxvQ0FBaUIsQ0FBQyxJQUFJLEVBQUUsUUFBUSxHQUFHLEVBQUUsRUFBRTtZQUM5QyxRQUFRLEVBQUU7Z0JBQ04sT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLE1BQU0sRUFBRSxvQ0FBb0M7Z0JBQzVDLFVBQVUsRUFBRTtvQkFDUix1QkFBdUIsRUFBRSxXQUFXO2lCQUN2QztnQkFDRCxNQUFNLEVBQUUsWUFBWTtnQkFDcEIsa0JBQWtCLEVBQUUsRUFBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFDLENBQUMsd0RBQXdEO2FBQzNHO1lBQ0QsTUFBTSxFQUFFO2dCQUNKLFVBQVUsRUFBRTtvQkFDUixJQUFJLHlCQUFlLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQzt3QkFDeEIsT0FBTyxFQUFFLENBQUMsNENBQTRDLENBQUM7d0JBQ3ZELE1BQU0sRUFBRSxnQkFBTSxDQUFDLEtBQUs7cUJBQ3ZCLENBQUM7aUJBQ0w7YUFDSjtZQUNELG1CQUFtQixFQUFFLEtBQUs7U0FDN0IsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTyxzQkFBc0IsQ0FBQyxpQkFBeUI7UUFDcEQsTUFBTSxhQUFhLEdBQUcsc0JBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUMsTUFBTSxlQUFlLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLE1BQU0seUJBQXlCLEdBQUcsRUFBRSxDQUFDO1FBQ3JDLE1BQU0sMEJBQTBCLEdBQUcsRUFBRSxDQUFDO1FBRXRDLE1BQU0sT0FBTyxHQUFHLElBQUksb0JBQU8sQ0FBQyxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDakQsY0FBYyxFQUFFO2dCQUNaLEVBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFDO2FBQy9CO1lBQ0QsVUFBVSxFQUFFO2dCQUNSLGlCQUFpQixFQUFFLHNCQUFRLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRyx5Q0FBeUM7YUFDakg7U0FDSixDQUFDLENBQUM7UUFDSCxrQkFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDNUQsa0JBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLGVBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDMUUsa0JBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLFFBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzdELGtCQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxlQUFnQixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFcEUsT0FBTyxDQUFDLGVBQWUsRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFFM0QsTUFBTSxXQUFXLEdBQUcsSUFBSSw0QkFBVyxDQUFDLElBQUksRUFBRSx1QkFBdUIsRUFBRTtZQUMvRCxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsUUFBUTtZQUNsQyxtQkFBbUIsRUFBRTtnQkFDakIscUZBQXFGO2dCQUNyRixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsdUNBQXVDLENBQUM7Z0JBQ3BFLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU87Z0JBQy9CLE9BQU8sRUFBRSxvQkFBb0I7Z0JBRTdCLE9BQU8sRUFBRSxhQUFhO2dCQUN0QixVQUFVLEVBQUUsR0FBRztnQkFDZiw0QkFBNEIsRUFBRSx5QkFBeUIsR0FBRyxlQUFlLEdBQUcsMEJBQTBCO2dCQUV0RyxZQUFZLEVBQUUsd0JBQWEsQ0FBQyxVQUFVO2dCQUN0QyxXQUFXLEVBQUU7b0JBQ1QsbUJBQW1CLEVBQUUsaUJBQWlCLENBQUMsUUFBUSxFQUFFO2lCQUNwRDthQUNKO1lBQ0QsZUFBZSxFQUFFLENBQUM7WUFDbEIsbUJBQW1CLEVBQUU7Z0JBQ2pCLHVCQUF1QixFQUFFLElBQUk7Z0JBQzdCLFNBQVMsRUFBRSxlQUFlO2dCQUMxQixPQUFPLEVBQUUsSUFBSTthQUNoQjtTQUNKLENBQUMsQ0FBQztRQUNILGtCQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztRQUV0RSxPQUFPLENBQUMsUUFBUyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFN0QsS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJLENBQUMsaUNBQWlDLEVBQUUsRUFBRTtZQUN6RCxXQUFXLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNwRDtRQUVELE1BQU0sc0JBQXNCLEdBQUcsQ0FBQyxnQkFBZ0I7WUFDNUMsV0FBVztZQUNYLFlBQVk7WUFDWixpQkFBaUI7WUFDakIsZ0JBQWdCO1lBQ2hCLHVCQUF1QjtZQUN2QixzQkFBc0IsQ0FBQyxDQUFBO1FBQzNCLFdBQVcsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxzQkFBc0IsQ0FBQyxDQUFDO1FBRTdGLElBQUksdUJBQVMsQ0FBQyxJQUFJLEVBQUUsOEJBQThCLEVBQUU7WUFDaEQsS0FBSyxFQUFFLFdBQVcsQ0FBQyxjQUFjLENBQUMsWUFBWTtZQUM5QyxXQUFXLEVBQUUsa0RBQWtEO1NBQ2xFLENBQUMsQ0FBQztJQUNQLENBQUM7O0FBcGtDTCxrQ0Fxa0NDO0FBOWpDMEIsd0JBQVksR0FBRyxjQUFjLENBQUMsQ0FBTyw4REFBOEQ7QUFDbkcsMkJBQWUsR0FBRyxjQUFjLENBQUMsQ0FBSSxnR0FBZ0c7QUFHckksc0NBQTBCLEdBQUksb0JBQW9CLENBQUE7QUFDbEQsdUNBQTJCLEdBQUcscUJBQXFCLENBQUE7QUFDbkQsb0NBQXdCLEdBQUcsbUJBQW1CLENBQUE7QUFDOUMsaURBQXFDLEdBQUcsY0FBYyxDQUFBO0FBQ3RELGlDQUFxQixHQUFHLG9CQUFvQixDQUFBO0FBQzNDLDhCQUFrQixHQUFHLGFBQWEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBNSVQtMFxuICovXG5cbmltcG9ydCB7XG4gICAgQXJuLFxuICAgIEFybkZvcm1hdCxcbiAgICBDZm5Db25kaXRpb24sXG4gICAgQ2ZuRGVsZXRpb25Qb2xpY3ksXG4gICAgQ2ZuT3V0cHV0LFxuICAgIENmblBhcmFtZXRlcixcbiAgICBDZm5SZXNvdXJjZSxcbiAgICBDdXN0b21SZXNvdXJjZSxcbiAgICBDdXN0b21SZXNvdXJjZVByb3ZpZGVyLFxuICAgIEN1c3RvbVJlc291cmNlUHJvdmlkZXJSdW50aW1lLFxuICAgIER1cmF0aW9uLFxuICAgIEZuLCBJQ2ZuQ29uZGl0aW9uRXhwcmVzc2lvbiwgSUNmblJ1bGVDb25kaXRpb25FeHByZXNzaW9uLFxuICAgIFN0YWNrLFxuICAgIFRhZ3MsIFRva2VuXG59IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB7Q29uc3RydWN0LCBJQ29uc3RydWN0fSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCB7XG4gICAgQWNjb3VudFByaW5jaXBhbCxcbiAgICBBcm5QcmluY2lwYWwsXG4gICAgRWZmZWN0LFxuICAgIElSb2xlLFxuICAgIE1hbmFnZWRQb2xpY3ksXG4gICAgUG9saWN5LFxuICAgIFBvbGljeVN0YXRlbWVudCxcbiAgICBSb2xlLFxuICAgIFNlcnZpY2VQcmluY2lwYWxcbn0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQge1MzRXZlbnRTZWxlY3RvciwgVHJhaWx9IGZyb20gXCJhd3MtY2RrLWxpYi9hd3MtY2xvdWR0cmFpbFwiXG5pbXBvcnQge0Jsb2NrUHVibGljQWNjZXNzLCBCdWNrZXQsIEJ1Y2tldEVuY3J5cHRpb24sIENmbkJ1Y2tldCwgU3RvcmFnZUNsYXNzfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtczMnO1xuaW1wb3J0IHtTY2hlZHVsZX0gZnJvbSBcImF3cy1jZGstbGliL2F3cy1ldmVudHNcIjtcbmltcG9ydCB7QmFja3VwUGxhbiwgQmFja3VwUGxhblJ1bGUsIEJhY2t1cFJlc291cmNlLCBCYWNrdXBWYXVsdH0gZnJvbSBcImF3cy1jZGstbGliL2F3cy1iYWNrdXBcIjtcbmltcG9ydCB7TG9nR3JvdXAsIE1ldHJpY0ZpbHRlciwgUmV0ZW50aW9uRGF5c30gZnJvbSBcImF3cy1jZGstbGliL2F3cy1sb2dzXCI7XG5pbXBvcnQgKiBhcyBwY2EgZnJvbSBcImF3cy1jZGstbGliL2F3cy1hY21wY2FcIjtcbmltcG9ydCB7Q2ZuQ2VydGlmaWNhdGVBdXRob3JpdHlBY3RpdmF0aW9ufSBmcm9tIFwiYXdzLWNkay1saWIvYXdzLWFjbXBjYVwiO1xuaW1wb3J0IHtTM1RvU3FzfSBmcm9tIFwiQGF3cy1zb2x1dGlvbnMtY29uc3RydWN0cy9hd3MtczMtc3FzXCI7XG5pbXBvcnQge1Nxc1RvTGFtYmRhfSBmcm9tIFwiQGF3cy1zb2x1dGlvbnMtY29uc3RydWN0cy9hd3Mtc3FzLWxhbWJkYVwiO1xuaW1wb3J0ICogYXMgbGFtYmRhIGZyb20gXCJhd3MtY2RrLWxpYi9hd3MtbGFtYmRhXCI7XG5pbXBvcnQge0F3c0N1c3RvbVJlc291cmNlfSBmcm9tIFwiYXdzLWNkay1saWIvY3VzdG9tLXJlc291cmNlc1wiO1xuaW1wb3J0IHtTdHJpbmdQYXJhbWV0ZXJ9IGZyb20gXCJhd3MtY2RrLWxpYi9hd3Mtc3NtXCI7XG5pbXBvcnQge0tleX0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWttcyc7XG5cbmV4cG9ydCBjbGFzcyBNYXR0ZXJTdGFjayBleHRlbmRzIFN0YWNrIHtcbiAgICBwdWJsaWMgcmVhZG9ubHkgbWF0dGVySXNzdWVEQUNSb2xlOiBSb2xlIHwgSVJvbGU7XG4gICAgcHVibGljIHJlYWRvbmx5IG1hdHRlcklzc3VlUEFJUm9sZTogUm9sZSB8IElSb2xlO1xuICAgIHB1YmxpYyByZWFkb25seSBtYXR0ZXJBdWRpdG9yUm9sZTogUm9sZSB8IElSb2xlO1xuICAgIHB1YmxpYyByZWFkb25seSBtYXR0ZXJNYW5hZ2VQQUFSb2xlOiBSb2xlIHwgSVJvbGU7XG4gICAgcHVibGljIHJlYWRvbmx5IG1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFJvbGU6IFJvbGUgfCBJUm9sZTtcblxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgbWF0dGVyUEtJVGFnID0gXCJtYXR0ZXJQS0lUYWdcIjsgICAgICAgLy8gVGhlIHRhZyB0aGF0IHNob3VsZCBiZSBhdHRhY2hlZCB0byBhbGwgUEFJcyBjcmVhdGVkIGluIFBDQS5cbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IG1hdHRlckNBVHlwZVRhZyA9IFwibWF0dGVyQ0FUeXBlXCI7ICAgIC8vIFRoZSB0YWcgdGhhdCBzaG91bGQgYmUgYXR0YWNoZWQgdG8gYWxsIENBcyBjcmVhdGVkIGluIFBDQSBhbmQgaGF2ZSB2YWx1ZSBcInBhYVwiIG9yIFwicGFpXCIgb25seS5cblxuXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBNQVRURVJfSVNTVUVfUEFJX1JPTEVfTkFNRSA9ICBcIk1hdHRlcklzc3VlUEFJUm9sZVwiXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBNQVRURVJfTUFOQUdFX1BBQV9ST0xFX05BTUUgPSBcIk1hdHRlck1hbmFnZVBBQVJvbGVcIlxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUFUVEVSX0FVRElUT1JfUk9MRV9OQU1FID0gXCJNYXR0ZXJBdWRpdG9yUm9sZVwiXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBNQVRURVJfQVVESVRfTE9HR0lOR19CQUNLVVBfUk9MRV9OQU1FID0gJ1MzQmFja3VwUm9sZSdcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1BVFRFUl9JU1NVRV9EQUNfUk9MRSA9IFwiTWF0dGVySXNzdWVEQUNSb2xlXCJcbiAgICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBtYXR0ZXJQS0lSb2xlc1BhdGggPSBcIi9NYXR0ZXJQS0kvXCI7XG5cbiAgICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcmVmaXg6IHN0cmluZywgZ2VuUGFpQ250OiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICAgICAgc3VwZXIoc2NvcGUsIGlkKTtcblxuICAgICAgICAvLyBOb3RlIHRoYXQgQ0ZOIHBhcmFtZXRlcnMgYXJlIG9ueSBkZWZpbmVkIHdoZW4geW91IGRlcGxveSByZXN1bHRpbmcgQ0ZOIHRlbXBsYXRlIGFuZCBwcm92aWRlIHZhbHVlcyBmb3IgdGhlbS5cblxuICAgICAgICBjb25zdCByb290ID0gZ2VuUGFpQ250ID09PSB1bmRlZmluZWQ7XG4gICAgICAgIGxldCBwYWFSZWdpb246IHN0cmluZyA9IHRoaXMucmVnaW9uO1xuICAgICAgICBpZiAocm9vdCkge1xuICAgICAgICAgICAgLy8gQ3JlYXRlIE9yIEZldGNoIFBBQVxuICAgICAgICAgICAgbGV0IHBhYUFybjogc3RyaW5nO1xuICAgICAgICAgICAgaWYgKHRoaXMubm9kZS50cnlHZXRDb250ZXh0KCdnZW5lcmF0ZVBhYScpID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBwYWFBcm4gPSBuZXcgQ2ZuUGFyYW1ldGVyKHRoaXMsIFwicGFhQXJuXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhlIEFSTiBvZiB0aGUgUHJpdmF0ZSBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgQ0EgdGhhdCBpcyB1c2VkIGFzIHRoZSBNYXR0ZXIgUHJvZHVjdCBBdHRlc3RhdGlvbiBcIiArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkF1dGhvcml0eSAoUEFBKS5cIlxuICAgICAgICAgICAgICAgIH0pLnZhbHVlQXNTdHJpbmc7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbGlkaXR5SW5EYXlzID0gbmV3IENmblBhcmFtZXRlcih0aGlzLCBcInZhbGlkaXR5SW5EYXlzXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJOdW1iZXJcIixcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVmFsaWRpdHkgaW4gZGF5cyBmb3IgbmV3IFBBQVwiLFxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OiAzNjUwXG4gICAgICAgICAgICAgICAgfSkudmFsdWVBc051bWJlcjtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWxpZGl0eUVuZERhdGUgPSBuZXcgQ2ZuUGFyYW1ldGVyKHRoaXMsIFwidmFsaWRpdHlFbmREYXRlXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVmFsaWRpdHkgRW5kIERhdGUsIGlzIG9wdGlvbmFsIGFuZCBvdmVycmlkZXMgdmFsaWRpdHlJbkRheXMuIEl0J3MgaW4gWVlZWU1NRERISE1NU1MgZm9ybWF0LlwiLFxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICAgICAgICAgIH0pLnZhbHVlQXNTdHJpbmc7XG4gICAgICAgICAgICAgICAgY29uc3QgdmVuZG9ySWRJbnB1dCA9IG5ldyBDZm5QYXJhbWV0ZXIodGhpcywgXCJ2ZW5kb3JJZFwiLCB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiU3RyaW5nXCIsXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoZSB2ZW5kb3JJZCBhc3NvY2lhdGVkIHdpdGggdGhpcyBQQUEuIFRoaXMgbXVzdCBiZSBhIDQtZGlnaXQgaGV4IHZhbHVlLlwiXG4gICAgICAgICAgICAgICAgfSkudmFsdWVBc1N0cmluZztcblxuICAgICAgICAgICAgICAgIGNvbnN0IHZlbmRvcklkID0gdGhpcy52YWxpZGF0ZVZpZCh2ZW5kb3JJZElucHV0KTtcblxuICAgICAgICAgICAgICAgIGxldCBjb21tb25OYW1lID0gbmV3IENmblBhcmFtZXRlcih0aGlzLCAncGFhQ29tbW9uTmFtZScsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhlIENvbW1vbiBOYW1lIGZvciB0aGlzIFBBQS5cIlxuICAgICAgICAgICAgICAgIH0pLnZhbHVlQXNTdHJpbmc7XG4gICAgICAgICAgICAgICAgbGV0IHBhYU9yZ2FuaXphdGlvbiA9IG5ldyBDZm5QYXJhbWV0ZXIodGhpcywgJ3BhYU9yZ2FuaXphdGlvbicsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhlIE9yZ2FuaXphdGlvbiBhc3NvY2lhdGVkIHdpdGggdGhpcyBQQUEuXCJcbiAgICAgICAgICAgICAgICB9KS52YWx1ZUFzU3RyaW5nO1xuICAgICAgICAgICAgICAgIGxldCBwYWFPcmdhbml6YXRpb25Vbml0ID0gbmV3IENmblBhcmFtZXRlcih0aGlzLCAncGFhT1UnLCB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiU3RyaW5nXCIsXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoZSBPcmdhbml6YXRpb25hbCBVbml0IGFzc29jaWF0ZWQgd2l0aCB0aGlzIFBBQS5cIixcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDogJydcbiAgICAgICAgICAgICAgICB9KS52YWx1ZUFzU3RyaW5nO1xuXG4gICAgICAgICAgICAgICAgY29uc3QgdmFsaWRpdHkgPSB0aGlzLmNyZWF0ZVBjYVZhbGlkaXR5SW5zdGFuY2UodmFsaWRpdHlJbkRheXMsIHZhbGlkaXR5RW5kRGF0ZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgcGFhQWN0aXZhdGlvbiA9IHRoaXMuY3JlYXRlUEFBKGNvbW1vbk5hbWUsIHBhYU9yZ2FuaXphdGlvbiwgcGFhT3JnYW5pemF0aW9uVW5pdCwgdmFsaWRpdHksIHZlbmRvcklkKTtcbiAgICAgICAgICAgICAgICBwYWFBcm4gPSBwYWFBY3RpdmF0aW9uLmNlcnRpZmljYXRlQXV0aG9yaXR5QXJuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIEdsb2JhbCByZXNvdXJjZXMuXG4gICAgICAgICAgICB0aGlzLm1hdHRlck1hbmFnZVBBQVJvbGUgPSB0aGlzLmNyZWF0ZU1hdHRlck1hbmFnZVBBQVJvbGUocHJlZml4ICsgTWF0dGVyU3RhY2suTUFUVEVSX01BTkFHRV9QQUFfUk9MRV9OQU1FLCBwYWFBcm4pO1xuICAgICAgICAgICAgdGhpcy5tYXR0ZXJJc3N1ZVBBSVJvbGUgPSB0aGlzLmNyZWF0ZU1hdHRlcklzc3VlUEFJUm9sZShwcmVmaXggKyBNYXR0ZXJTdGFjay5NQVRURVJfSVNTVUVfUEFJX1JPTEVfTkFNRSwgcGFhQXJuKTtcbiAgICAgICAgICAgIHRoaXMubWF0dGVyQXVkaXRvclJvbGUgPSB0aGlzLmNyZWF0ZU1hdHRlckF1ZGl0b3JSb2xlKHByZWZpeCArIE1hdHRlclN0YWNrLk1BVFRFUl9BVURJVE9SX1JPTEVfTkFNRSwgcGFhQXJuKTtcbiAgICAgICAgICAgIHRoaXMubWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUm9sZSA9IHRoaXMuY3JlYXRlTWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUm9sZShwcmVmaXggKyBNYXR0ZXJTdGFjay5NQVRURVJfQVVESVRfTE9HR0lOR19CQUNLVVBfUk9MRV9OQU1FKTtcbiAgICAgICAgICAgIHRoaXMubWF0dGVySXNzdWVEQUNSb2xlID0gdGhpcy5jcmVhdGVNYXR0ZXJJc3N1ZURBQ1JvbGUocHJlZml4ICsgTWF0dGVyU3RhY2suTUFUVEVSX0lTU1VFX0RBQ19ST0xFKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIENyZWF0ZSBQQUlcbiAgICAgICAgICAgIGxldCBwcm9kSWRzSW5wdXQgPSBuZXcgQ2ZuUGFyYW1ldGVyKHRoaXMsIFwicHJvZHVjdElkc1wiLCB7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJBIGNvbW1hLXNlcGFyYXRlZCBsaXN0IG9mIHByb2R1Y3QgSURzIGFzc29jaWF0ZWQgd2l0aCBQQUlzLiBUaGVzZSBtdXN0IGJlIDQtZGlnaXQgaGV4IHZhbHVlcy5cIixcbiAgICAgICAgICAgICAgICBkZWZhdWx0OiAnJ1xuICAgICAgICAgICAgfSk/LnZhbHVlQXNTdHJpbmc7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGl0eUluRGF5cyA9IG5ldyBDZm5QYXJhbWV0ZXIodGhpcywgXCJ2YWxpZGl0eUluRGF5c1wiLCB7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJOdW1iZXJcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJWYWxpZGl0eSBpbiBkYXlzIGZvciBuZXcgUEFJKHMpXCIsXG4gICAgICAgICAgICAgICAgZGVmYXVsdDogMzYwMFxuICAgICAgICAgICAgfSkudmFsdWVBc051bWJlcjtcbiAgICAgICAgICAgIGNvbnN0IHZhbGlkaXR5RW5kRGF0ZSA9IG5ldyBDZm5QYXJhbWV0ZXIodGhpcywgXCJ2YWxpZGl0eUVuZERhdGVcIiwge1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiU3RyaW5nXCIsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVmFsaWRpdHkgRW5kIERhdGUsIGlzIG9wdGlvbmFsIGFuZCBvdmVycmlkZXMgdmFsaWRpdHlJbkRheXMuIEl0J3MgaW4gWVlZWU1NRERISE1NU1MgZm9ybWF0LlwiLFxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6ICcnXG4gICAgICAgICAgICB9KS52YWx1ZUFzU3RyaW5nO1xuICAgICAgICAgICAgY29uc3QgZGFjVmFsaWRpdHlJbkRheXMgPSBuZXcgQ2ZuUGFyYW1ldGVyKHRoaXMsIFwiZGFjVmFsaWRpdHlJbkRheXNcIiwge1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiTnVtYmVyXCIsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVmFsaWRpdHkgaW4gZGF5cyBmb3IgREFDcyBpc3N1ZWQgYnkgdGhlIExhbWJkYS5cIlxuICAgICAgICAgICAgfSkudmFsdWVBc051bWJlcjtcbiAgICAgICAgICAgIGNvbnN0IHBhYUFybiA9IG5ldyBDZm5QYXJhbWV0ZXIodGhpcywgXCJwYWFBcm5cIiwge1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiU3RyaW5nXCIsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiQVJOIG9mIHRoZSBQQUFcIlxuICAgICAgICAgICAgfSkudmFsdWVBc1N0cmluZztcbiAgICAgICAgICAgIHBhYVJlZ2lvbiA9IEFybi5zcGxpdChwYWFBcm4sIEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FKS5yZWdpb24hO1xuXG4gICAgICAgICAgICBjb25zdCBwcm9kSWRzU2V0ID0gbmV3IENmbkNvbmRpdGlvbih0aGlzLCAnUGlkc1dlcmVQcm92aWRlZCcsIHtcbiAgICAgICAgICAgICAgICBleHByZXNzaW9uOiBGbi5jb25kaXRpb25Ob3QoRm4uY29uZGl0aW9uRXF1YWxzKHByb2RJZHNJbnB1dCwgJycpKVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb25zdCBwcm9kSWRzID0gdGhpcy52YWxpZGF0ZVBpZHMocHJvZElkc0lucHV0LCBwcm9kSWRzU2V0KTtcblxuICAgICAgICAgICAgbGV0IGNvbW1vbk5hbWVzID0gbmV3IENmblBhcmFtZXRlcih0aGlzLCAncGFpQ29tbW9uTmFtZXMnLCB7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGUgQ29tbW9uIE5hbWUgZm9yIHRoaXMgUEFJXCJcbiAgICAgICAgICAgIH0pLnZhbHVlQXNTdHJpbmc7XG4gICAgICAgICAgICBsZXQgb3JnYW5pemF0aW9ucyA9IG5ldyBDZm5QYXJhbWV0ZXIodGhpcywgJ3BhaU9yZ2FuaXphdGlvbnMnLCB7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJTdHJpbmdcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGUgT3JnYW5pemF0aW9uIGFzc29jaWF0ZWQgd2l0aCB0aGlzIFBBSVwiXG4gICAgICAgICAgICB9KS52YWx1ZUFzU3RyaW5nO1xuICAgICAgICAgICAgbGV0IG9yZ2FuaXphdGlvbmFsVW5pdHMgPSBuZXcgQ2ZuUGFyYW1ldGVyKHRoaXMsICdwYWlPcmdhbml6YXRpb25hbFVuaXRzJywge1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiU3RyaW5nXCIsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhlIE9yZ2FuaXphdGlvbmFsIFVuaXQgYXNzb2NpYXRlZCB3aXRoIHRoaXMgUEFJXCIsXG4gICAgICAgICAgICAgICAgZGVmYXVsdDogJydcbiAgICAgICAgICAgIH0pLnZhbHVlQXNTdHJpbmc7XG5cbiAgICAgICAgICAgIGNvbnN0IG91U2V0ID0gbmV3IENmbkNvbmRpdGlvbih0aGlzLCBcInBhaU9VV2FzUHJvdmlkZWRcIiwge1xuICAgICAgICAgICAgICAgIGV4cHJlc3Npb246IEZuLmNvbmRpdGlvbk5vdChGbi5jb25kaXRpb25FcXVhbHMob3JnYW5pemF0aW9uYWxVbml0cywgJycpKVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGNvbnN0IHZlbmRvcklkID0gdGhpcy5nZXRQYWFWZW5kb3JJZChwYWFBcm4sIHBhYVJlZ2lvbik7XG4gICAgICAgICAgICBjb25zdCBwYWFQZW0gPSB0aGlzLmdldENlcnRpZmljYXRlUGVtKGlkLCBwYWFBcm4sIHBhYVJlZ2lvbik7XG4gICAgICAgICAgICBjb25zdCB2YWxpZGl0eSA9IHRoaXMuY3JlYXRlUGNhVmFsaWRpdHlTdHJpbmdzKHZhbGlkaXR5SW5EYXlzLCB2YWxpZGl0eUVuZERhdGUpO1xuICAgICAgICAgICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHBhcnNlSW50KGdlblBhaUNudCk7IGluZGV4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb21tb25OYW1lID0gRm4uc2VsZWN0KGluZGV4LCBGbi5zcGxpdCgnLCcsIGNvbW1vbk5hbWVzKSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgb3JnYW5pemF0aW9uID0gRm4uc2VsZWN0KGluZGV4LCBGbi5zcGxpdCgnLCcsIG9yZ2FuaXphdGlvbnMpKTtcbiAgICAgICAgICAgICAgICBjb25zdCBvcmdhbml6YXRpb25hbFVuaXQgPSBGbi5jb25kaXRpb25JZihvdVNldC5sb2dpY2FsSWQsIEZuLnNlbGVjdChpbmRleCwgRm4uc3BsaXQoJywnLCBvcmdhbml6YXRpb25hbFVuaXRzKSksICcnKTtcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0ZVBBSShjb21tb25OYW1lLCBvcmdhbml6YXRpb24sIG9yZ2FuaXphdGlvbmFsVW5pdCwgb3VTZXQsIHZhbGlkaXR5LCB2ZW5kb3JJZCwgaW5kZXgsIHByb2RJZHMsIHByb2RJZHNTZXQsIHBhYUFybiwgcGFhUmVnaW9uLCBwYWFQZW0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBHbG9iYWwgcmVzb3VyY2VzLlxuICAgICAgICAgICAgdGhpcy5tYXR0ZXJNYW5hZ2VQQUFSb2xlID1cbiAgICAgICAgICAgICAgICBSb2xlLmZyb21Sb2xlTmFtZSh0aGlzLCBcIk1hdHRlck1hbmFnZVBBQVJvbGVJblBBSVN0YWNrXCIsIE1hdHRlclN0YWNrLk1BVFRFUl9NQU5BR0VfUEFBX1JPTEVfTkFNRSlcbiAgICAgICAgICAgIHRoaXMubWF0dGVySXNzdWVQQUlSb2xlID1cbiAgICAgICAgICAgICAgICBSb2xlLmZyb21Sb2xlTmFtZSh0aGlzLCBcIk1hdHRlcklzc3VlUEFJUm9sZUluUEFJU3RhY2tcIiwgTWF0dGVyU3RhY2suTUFUVEVSX0lTU1VFX1BBSV9ST0xFX05BTUUpXG4gICAgICAgICAgICB0aGlzLm1hdHRlckF1ZGl0b3JSb2xlID1cbiAgICAgICAgICAgICAgICBSb2xlLmZyb21Sb2xlTmFtZSh0aGlzLCBcIk1hdHRlckF1ZGl0b3JSb2xlSW5QQUlTdGFja1wiLCBNYXR0ZXJTdGFjay5NQVRURVJfQVVESVRPUl9ST0xFX05BTUUpXG4gICAgICAgICAgICB0aGlzLm1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFJvbGUgPSBSb2xlLmZyb21Sb2xlTmFtZSh0aGlzLCBcIk1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFJvbGVJblBBSVN0YWNrXCIsXG4gICAgICAgICAgICAgICAgTWF0dGVyU3RhY2suTUFUVEVSX0FVRElUX0xPR0dJTkdfQkFDS1VQX1JPTEVfTkFNRSlcbiAgICAgICAgICAgIHRoaXMubWF0dGVySXNzdWVEQUNSb2xlID1cbiAgICAgICAgICAgICAgICBSb2xlLmZyb21Sb2xlTmFtZSh0aGlzLCBcIk1hdHRlcklzc3VlREFDUm9sZUluUEFJU3RhY2tcIiwgTWF0dGVyU3RhY2suTUFUVEVSX0lTU1VFX0RBQ19ST0xFKVxuICAgICAgICAgICAgdGhpcy5jcmVhdGVEYWNJc3N1aW5nTGFtYmRhKGRhY1ZhbGlkaXR5SW5EYXlzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlZ2lvbmFsIHJlc291cmNlcyBzaGFyZWQgYmV0d2VlbiBQQUEgYW5kIFBBSSBzdGFja3MuXG4gICAgICAgIGNvbnN0IHJlZ2lvbmFsU2hhcmVkV2l0aFBBQVN0YWNrUmVzb3VyY2VzOiBJQ29uc3RydWN0W10gPSBbXTtcbiAgICAgICAgY29uc3QgW21hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFBsYW4sIG1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFBsYW5UcmVlXSA9IHRoaXMuY3JlYXRlTWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUGxhbihwcmVmaXgpO1xuICAgICAgICByZWdpb25hbFNoYXJlZFdpdGhQQUFTdGFja1Jlc291cmNlcy5wdXNoKC4uLm1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFBsYW5UcmVlKTtcbiAgICAgICAgY29uc3QgW21hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldCwgbWF0dGVyQXVkaXRMb2dnaW5nQnVja2V0VHJlZV0gPSB0aGlzLmNyZWF0ZU1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldChwcmVmaXgsIG1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFBsYW4pO1xuICAgICAgICByZWdpb25hbFNoYXJlZFdpdGhQQUFTdGFja1Jlc291cmNlcy5wdXNoKC4uLm1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldFRyZWUpO1xuICAgICAgICBjb25zdCBbYXVkaXRMb2dHcm91cCwgYXVkaXRMb2dHcm91cFRyZWVdID0gdGhpcy5jcmVhdGVBdWRpdExvZ0dyb3VwKHByZWZpeCwgcm9vdCwgbWF0dGVyQXVkaXRMb2dnaW5nQnVja2V0LCBtYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBQbGFuKTtcbiAgICAgICAgcmVnaW9uYWxTaGFyZWRXaXRoUEFBU3RhY2tSZXNvdXJjZXMucHVzaCguLi5hdWRpdExvZ0dyb3VwVHJlZSk7XG5cbiAgICAgICAgY29uc3QgWywgYXVkaXRDbG91ZFRyYWlsVHJlZV0gPSB0aGlzLmNyZWF0ZUF1ZGl0Q2xvdWRUcmFpbChwcmVmaXgsIHJvb3QsIGF1ZGl0TG9nR3JvdXAsIG1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldCk7XG4gICAgICAgIHJlZ2lvbmFsU2hhcmVkV2l0aFBBQVN0YWNrUmVzb3VyY2VzLnB1c2goLi4uYXVkaXRDbG91ZFRyYWlsVHJlZSk7XG5cbiAgICAgICAgaWYgKCFyb290KSB7XG4gICAgICAgICAgICAvLyBEbyBub3QgcmUtY3JlYXRlIHJlZ2lvbmFsIHNoYXJlZCB3aXRoIFBBQSBTdGFjayByZXNvdXJjZXMgd2hlbiBhZGRpbmcgUEFJcyBpbnRvIHRoZSBzYW1lIHJlZ2lvbi5cbiAgICAgICAgICAgIGNvbnN0IGNyZWF0ZUNvbmRpdGlvbiA9IG5ldyBDZm5Db25kaXRpb24oXG4gICAgICAgICAgICAgICAgdGhpcyxcbiAgICAgICAgICAgICAgICAnaXNNdWx0aVJlZ2lvbicsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAvLyBhIGNvbmRpdGlvbiBuZWVkcyBhbiBleHByZXNzaW9uXG4gICAgICAgICAgICAgICAgICAgIGV4cHJlc3Npb246IEZuLmNvbmRpdGlvbk5vdChGbi5jb25kaXRpb25FcXVhbHModGhpcy5yZWdpb24sIHBhYVJlZ2lvbikpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgcmVnaW9uYWxTaGFyZWRXaXRoUEFBU3RhY2tSZXNvdXJjZXMubWFwKCh2KSA9PiB2Lm5vZGUuZGVmYXVsdENoaWxkIGFzIENmblJlc291cmNlKS5mb3JFYWNoKChpbnN0KSA9PiB7XG4gICAgICAgICAgICAgICAgaW5zdC5jZm5PcHRpb25zLmNvbmRpdGlvbiA9IGNyZWF0ZUNvbmRpdGlvbjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRQYWFWZW5kb3JJZChwYWFBcm46IHN0cmluZywgcGFhUmVnaW9uOiBzdHJpbmcpIHtcbiAgICAgICAgY29uc3QgcHJvdmlkZXIgPSBDdXN0b21SZXNvdXJjZVByb3ZpZGVyLmdldE9yQ3JlYXRlUHJvdmlkZXIodGhpcywgJ0N1c3RvbTo6TGFtYmRhRnVuY3Rpb25VdGlscycsIHtcbiAgICAgICAgICAgIGNvZGVEaXJlY3Rvcnk6IGAke19fZGlybmFtZX1gLFxuICAgICAgICAgICAgcnVudGltZTogQ3VzdG9tUmVzb3VyY2VQcm92aWRlclJ1bnRpbWUuTk9ERUpTXzE4X1gsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJVdGlsaXR5IExhbWJkYSBmdW5jdGlvblwiXG4gICAgICAgIH0pO1xuICAgICAgICBwcm92aWRlci5hZGRUb1JvbGVQb2xpY3koe1xuICAgICAgICAgICAgRWZmZWN0OiAnQWxsb3cnLFxuICAgICAgICAgICAgQWN0aW9uOiAnYWNtLXBjYTpEZXNjcmliZUNlcnRpZmljYXRlQXV0aG9yaXR5JyxcbiAgICAgICAgICAgIFJlc291cmNlOiBwYWFBcm4sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gbmV3IEN1c3RvbVJlc291cmNlKHRoaXMsICdPYnRhaW5QYWFWaWQnLCB7XG4gICAgICAgICAgICBzZXJ2aWNlVG9rZW46IHByb3ZpZGVyLnNlcnZpY2VUb2tlbixcbiAgICAgICAgICAgIHJlc291cmNlVHlwZTogJ0N1c3RvbTo6R2V0UGFhVmVuZG9ySWRUeXBlJyxcbiAgICAgICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICAgICAgICBcImNvbW1hbmRcIjogXCJnZXRQYWFWZW5kb3JJZFwiLFxuICAgICAgICAgICAgICAgIFwicGFhQXJuXCI6IHBhYUFybixcbiAgICAgICAgICAgICAgICBcInBhYVJlZ2lvblwiOiBwYWFSZWdpb25cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuZ2V0QXR0KCdSZXN1bHQnKS50b1N0cmluZygpO1xuICAgIH1cblxuICAgIHByaXZhdGUgdmFsaWRhdGVQaWRzKHBpZHM6IHN0cmluZywgcGlkc1NldDogQ2ZuQ29uZGl0aW9uKTogc3RyaW5nW10ge1xuICAgICAgICBjb25zdCBwcm92aWRlciA9IEN1c3RvbVJlc291cmNlUHJvdmlkZXIuZ2V0T3JDcmVhdGVQcm92aWRlcih0aGlzLCAnQ3VzdG9tOjpMYW1iZGFGdW5jdGlvblV0aWxzJywge1xuICAgICAgICAgICAgY29kZURpcmVjdG9yeTogYCR7X19kaXJuYW1lfWAsXG4gICAgICAgICAgICBydW50aW1lOiBDdXN0b21SZXNvdXJjZVByb3ZpZGVyUnVudGltZS5OT0RFSlNfMThfWCxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlV0aWxpdHkgTGFtYmRhIGZ1bmN0aW9uXCJcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IG91dGNvbWUgPSBuZXcgQ3VzdG9tUmVzb3VyY2UodGhpcywgJ1ZhbGlkYXRlUGlkJywge1xuICAgICAgICAgICAgc2VydmljZVRva2VuOiBwcm92aWRlci5zZXJ2aWNlVG9rZW4sXG4gICAgICAgICAgICByZXNvdXJjZVR5cGU6ICdDdXN0b206OlZhbGlkYXRlUGlkVHlwZScsXG4gICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgICAgXCJjb21tYW5kXCI6IFwidmFsaWRhdGVWaWRQaWRcIixcbiAgICAgICAgICAgICAgICBcInZpZFwiOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgXCJwaWRzXCI6IEZuLmNvbmRpdGlvbklmKHBpZHNTZXQubG9naWNhbElkLCBwaWRzLnNwbGl0KCcsJyksIFsnQUFBQSddKVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG91dGNvbWUuZ2V0QXR0KCdwaWRzJykhLnRvU3RyaW5nTGlzdCgpO1xuICAgIH1cblxuICAgIHByaXZhdGUgdmFsaWRhdGVWaWQodmlkOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICBjb25zdCBwcm92aWRlciA9IEN1c3RvbVJlc291cmNlUHJvdmlkZXIuZ2V0T3JDcmVhdGVQcm92aWRlcih0aGlzLCAnQ3VzdG9tOjpMYW1iZGFGdW5jdGlvblV0aWxzJywge1xuICAgICAgICAgICAgY29kZURpcmVjdG9yeTogYCR7X19kaXJuYW1lfWAsXG4gICAgICAgICAgICBydW50aW1lOiBDdXN0b21SZXNvdXJjZVByb3ZpZGVyUnVudGltZS5OT0RFSlNfMThfWCxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlV0aWxpdHkgTGFtYmRhIGZ1bmN0aW9uXCJcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IG91dGNvbWUgPSBuZXcgQ3VzdG9tUmVzb3VyY2UodGhpcywgJ1ZhbGlkYXRlVmlkJywge1xuICAgICAgICAgICAgc2VydmljZVRva2VuOiBwcm92aWRlci5zZXJ2aWNlVG9rZW4sXG4gICAgICAgICAgICByZXNvdXJjZVR5cGU6ICdDdXN0b206OlZhbGlkYXRlVmlkVHlwZScsXG4gICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgICAgXCJjb21tYW5kXCI6IFwidmFsaWRhdGVWaWRQaWRcIixcbiAgICAgICAgICAgICAgICBcInZpZFwiOiB2aWQsXG4gICAgICAgICAgICAgICAgXCJwaWRzXCI6IHVuZGVmaW5lZFxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG91dGNvbWUuZ2V0QXR0KCd2aWQnKSEudG9TdHJpbmcoKTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGVzIHRoZSBJQU0gcm9sZSBmb3IgaXNzdWluZyBhbmQgcmV2b2tpbmcgRGV2aWNlIEF0dGVzdGF0aW9uIENlcnRpZmljYXRlcyAoREFDcylcbiAgICBwcml2YXRlIGNyZWF0ZU1hdHRlcklzc3VlREFDUm9sZShyb2xlTmFtZTogc3RyaW5nKTogUm9sZSB7XG4gICAgICAgIGNvbnN0IG1hdHRlcklzc3VlREFDUm9sZSA9IG5ldyBSb2xlKHRoaXMsIHJvbGVOYW1lLCB7XG4gICAgICAgICAgICBhc3N1bWVkQnk6IG5ldyBBY2NvdW50UHJpbmNpcGFsKHRoaXMuYWNjb3VudCksXG4gICAgICAgICAgICByb2xlTmFtZTogcm9sZU5hbWUsXG4gICAgICAgICAgICBwYXRoOiBNYXR0ZXJTdGFjay5tYXR0ZXJQS0lSb2xlc1BhdGhcbiAgICAgICAgfSk7XG5cbiAgICAgICAgVGFncy5vZihtYXR0ZXJJc3N1ZURBQ1JvbGUpLmFkZChNYXR0ZXJTdGFjay5tYXR0ZXJQS0lUYWcsIFwiXCIpO1xuXG4gICAgICAgIG1hdHRlcklzc3VlREFDUm9sZS5hdHRhY2hJbmxpbmVQb2xpY3koXG4gICAgICAgICAgICBuZXcgUG9saWN5KHRoaXMsIGBJc3N1ZURBQ0NlcnRgLCB7XG4gICAgICAgICAgICAgICAgc3RhdGVtZW50czogdGhpcy5nZXRQb2xpY3lTdGF0ZW1lbnRzRm9yREFDSXNzdWFuY2UoKSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICApO1xuXG4gICAgICAgIHJldHVybiBtYXR0ZXJJc3N1ZURBQ1JvbGU7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBnZXRQb2xpY3lTdGF0ZW1lbnRzRm9yREFDSXNzdWFuY2UoKTogUG9saWN5U3RhdGVtZW50W10ge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7IC8vIEFsbG93IGlzc3VhbmNlIG9mIG9ubHkgREFDcyBmcm9tIFBBSXNcbiAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhY20tcGNhOklzc3VlQ2VydGlmaWNhdGVcIl0sXG4gICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgcmVzb3VyY2VzOiBbXCIqXCJdLFxuICAgICAgICAgICAgICAgIGNvbmRpdGlvbnM6IHtcbiAgICAgICAgICAgICAgICAgICAgU3RyaW5nTGlrZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOlRlbXBsYXRlQXJuXCI6IFwiYXJuOmF3czphY20tcGNhOjo6dGVtcGxhdGUvQmxhbmtFbmRFbnRpdHlDZXJ0aWZpY2F0ZV9Dcml0aWNhbEJhc2ljQ29uc3RyYWludHNfQVBJUGFzc3Rocm91Z2gvVipcIlxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBTdHJpbmdFcXVhbHM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYXdzOlJlc291cmNlVGFnL21hdHRlckNBVHlwZVwiOiBcInBhaVwiXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG5ldyBQb2xpY3lTdGF0ZW1lbnQoeyAvLyBEZW55IGlzc3VhbmNlIG9mIGNlcnRzIG90aGVyIHRoYW4gREFDc1xuICAgICAgICAgICAgICAgIGFjdGlvbnM6IFtcImFjbS1wY2E6SXNzdWVDZXJ0aWZpY2F0ZVwiXSxcbiAgICAgICAgICAgICAgICBlZmZlY3Q6IEVmZmVjdC5ERU5ZLFxuICAgICAgICAgICAgICAgIHJlc291cmNlczogW1wiKlwiXSxcbiAgICAgICAgICAgICAgICBjb25kaXRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgIFN0cmluZ05vdExpa2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpUZW1wbGF0ZUFyblwiOiBcImFybjphd3M6YWNtLXBjYTo6OnRlbXBsYXRlL0JsYW5rRW5kRW50aXR5Q2VydGlmaWNhdGVfQ3JpdGljYWxCYXNpY0NvbnN0cmFpbnRzX0FQSVBhc3N0aHJvdWdoL1YqXCJcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgU3RyaW5nRXF1YWxzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcImF3czpSZXNvdXJjZVRhZy9tYXR0ZXJDQVR5cGVcIjogXCJwYWlcIlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBuZXcgUG9saWN5U3RhdGVtZW50KHtcbiAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhY20tcGNhOlJldm9rZUNlcnRpZmljYXRlXCIsXG4gICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6RGVzY3JpYmVDZXJ0aWZpY2F0ZUF1dGhvcml0eVwiXSxcbiAgICAgICAgICAgICAgICBlZmZlY3Q6IEVmZmVjdC5BTExPVyxcbiAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtcIipcIl0sXG4gICAgICAgICAgICAgICAgY29uZGl0aW9uczoge1xuICAgICAgICAgICAgICAgICAgICBTdHJpbmdFcXVhbHM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYXdzOlJlc291cmNlVGFnL21hdHRlckNBVHlwZVwiOiBcInBhaVwiXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG5ldyBQb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgICAgICAgIGFjdGlvbnM6IFtcImFjbS1wY2E6TGlzdENlcnRpZmljYXRlQXV0aG9yaXRpZXNcIl0sXG4gICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgcmVzb3VyY2VzOiBbXCIqXCJdLFxuICAgICAgICAgICAgfSksXG4gICAgICAgIF07XG4gICAgfVxuXG4vLyBDcmVhdGVzIHRoZSBJQU0gcm9sZSBmb3IgY3JlYXRpbmcgYW5kIG1hbmFnaW5nIFByb2R1Y3QgQXR0ZXN0YXRpb24gSW50ZXJtZWRpYXRlcyAoUEFJcylcbiAgICBwcml2YXRlIGNyZWF0ZU1hdHRlcklzc3VlUEFJUm9sZShyb2xlTmFtZTogc3RyaW5nLCBwYWFBcm46IHN0cmluZyk6IFJvbGUge1xuICAgICAgICBjb25zdCBtYXR0ZXJJc3N1ZVBBSVJvbGUgPSBuZXcgUm9sZSh0aGlzLCByb2xlTmFtZSwge1xuICAgICAgICAgICAgYXNzdW1lZEJ5OiBuZXcgQWNjb3VudFByaW5jaXBhbCh0aGlzLmFjY291bnQpLFxuICAgICAgICAgICAgcm9sZU5hbWU6IHJvbGVOYW1lLFxuICAgICAgICAgICAgcGF0aDogTWF0dGVyU3RhY2subWF0dGVyUEtJUm9sZXNQYXRoXG4gICAgICAgIH0pO1xuXG4gICAgICAgIFRhZ3Mub2YobWF0dGVySXNzdWVQQUlSb2xlKS5hZGQoTWF0dGVyU3RhY2subWF0dGVyUEtJVGFnLCBcIlwiKTtcblxuICAgICAgICBtYXR0ZXJJc3N1ZVBBSVJvbGUuYXR0YWNoSW5saW5lUG9saWN5KFxuICAgICAgICAgICAgbmV3IFBvbGljeSh0aGlzLCBgSXNzdWVQQUlDZXJ0YCwge1xuICAgICAgICAgICAgICAgIHN0YXRlbWVudHM6IFtcbiAgICAgICAgICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7IC8vIEFsbG93IGlzc3VhbmNlIG9mIG9ubHkgUEFJIGNlcnRzIGZyb20gUEFBc1xuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uczogW1wiYWNtLXBjYTpJc3N1ZUNlcnRpZmljYXRlXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtwYWFBcm5dLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uZGl0aW9uczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZ0xpa2UgOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpUZW1wbGF0ZUFyblwiOiBcImFybjphd3M6YWNtLXBjYTo6OnRlbXBsYXRlL0JsYW5rU3Vib3JkaW5hdGVDQUNlcnRpZmljYXRlX1BhdGhMZW4wX0FQSVBhc3N0aHJvdWdoL1YqXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICBuZXcgUG9saWN5U3RhdGVtZW50KHsgLy8gRGVueSBpc3N1YW5jZSBvZiBjZXJ0cyBvdGhlciB0aGFuIFBBSSBjZXJ0c1xuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uczogW1wiYWNtLXBjYTpJc3N1ZUNlcnRpZmljYXRlXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuREVOWSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc291cmNlczogW3BhYUFybl0sXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25kaXRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nTm90TGlrZSA6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOlRlbXBsYXRlQXJuXCI6IFwiYXJuOmF3czphY20tcGNhOjo6dGVtcGxhdGUvQmxhbmtTdWJvcmRpbmF0ZUNBQ2VydGlmaWNhdGVfUGF0aExlbjBfQVBJUGFzc3Rocm91Z2gvVipcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgIG5ldyBQb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uczogW1wiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZUF1dGhvcml0eUNlcnRpZmljYXRlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOkltcG9ydENlcnRpZmljYXRlQXV0aG9yaXR5Q2VydGlmaWNhdGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6RGVsZXRlQ2VydGlmaWNhdGVBdXRob3JpdHlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6VXBkYXRlQ2VydGlmaWNhdGVBdXRob3JpdHlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6RGVzY3JpYmVDZXJ0aWZpY2F0ZUF1dGhvcml0eVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZUF1dGhvcml0eUNzclwiXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVmZmVjdDogRWZmZWN0LkFMTE9XLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb3VyY2VzOiBbXCIqXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uZGl0aW9uczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZ0VxdWFscyA6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhd3M6UmVzb3VyY2VUYWcvbWF0dGVyQ0FUeXBlXCI6IFwicGFpXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICBuZXcgUG9saWN5U3RhdGVtZW50KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbnM6IFtcImFjbS1wY2E6UmV2b2tlQ2VydGlmaWNhdGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpEZXNjcmliZUNlcnRpZmljYXRlQXV0aG9yaXR5XCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtwYWFBcm5dLFxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhY20tcGNhOkxpc3RDZXJ0aWZpY2F0ZUF1dGhvcml0aWVzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOkNyZWF0ZUNlcnRpZmljYXRlQXV0aG9yaXR5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOlRhZ0NlcnRpZmljYXRlQXV0aG9yaXR5XCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtcIipcIl0sXG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcblxuICAgICAgICByZXR1cm4gbWF0dGVySXNzdWVQQUlSb2xlO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZXMgdGhlIHJlYWQtb25seSBJQU0gcm9sZSBmb3IgYXVkaXRpbmcgdGhlIE1hdHRlciBQS0lcbiAgICBwcml2YXRlIGNyZWF0ZU1hdHRlckF1ZGl0b3JSb2xlKHJvbGVOYW1lOiBzdHJpbmcsIHBhYUFybjogc3RyaW5nKTogUm9sZSB7XG4gICAgICAgIGNvbnN0IG1hdHRlckF1ZGl0b3JSb2xlID0gbmV3IFJvbGUodGhpcywgcm9sZU5hbWUsIHtcbiAgICAgICAgICAgIGFzc3VtZWRCeTogbmV3IEFjY291bnRQcmluY2lwYWwodGhpcy5hY2NvdW50KSxcbiAgICAgICAgICAgIHJvbGVOYW1lOiByb2xlTmFtZSxcbiAgICAgICAgICAgIHBhdGg6IE1hdHRlclN0YWNrLm1hdHRlclBLSVJvbGVzUGF0aFxuICAgICAgICB9KTtcblxuICAgICAgICBUYWdzLm9mKG1hdHRlckF1ZGl0b3JSb2xlKS5hZGQoTWF0dGVyU3RhY2subWF0dGVyUEtJVGFnLCBcIlwiKTtcblxuICAgICAgICBtYXR0ZXJBdWRpdG9yUm9sZS5hdHRhY2hJbmxpbmVQb2xpY3koXG4gICAgICAgICAgICBuZXcgUG9saWN5KHRoaXMsIGBNYXR0ZXJBdWRpdG9yYCwge1xuICAgICAgICAgICAgICAgIHN0YXRlbWVudHM6IFtcbiAgICAgICAgICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhY20tcGNhOkNyZWF0ZUNlcnRpZmljYXRlQXV0aG9yaXR5QXVkaXRSZXBvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6RGVzY3JpYmVDZXJ0aWZpY2F0ZUF1dGhvcml0eVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpEZXNjcmliZUNlcnRpZmljYXRlQXV0aG9yaXR5QXVkaXRSZXBvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDc3JcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRQb2xpY3lcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6TGlzdFBlcm1pc3Npb25zXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOkxpc3RUYWdzXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtwYWFBcm5dLFxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhY20tcGNhOkNyZWF0ZUNlcnRpZmljYXRlQXV0aG9yaXR5QXVkaXRSZXBvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6RGVzY3JpYmVDZXJ0aWZpY2F0ZUF1dGhvcml0eVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpEZXNjcmliZUNlcnRpZmljYXRlQXV0aG9yaXR5QXVkaXRSZXBvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDc3JcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRQb2xpY3lcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6TGlzdFBlcm1pc3Npb25zXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhY20tcGNhOkxpc3RUYWdzXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtcIipcIl0sXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25kaXRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nRXF1YWxzIDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImF3czpSZXNvdXJjZVRhZy9tYXR0ZXJDQVR5cGVcIjogXCJwYWlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICk7XG5cbiAgICAgICAgLypcbiAgICAgICAgICAgIE5vdGU6IFRoaXMgcm9sZSBnYWlucyBhY2Nlc3MgdG8gdGhlIFMzIGJ1Y2tldCB3aGVyZSB0aGUgbG9ncyBhcmUgc3RvcmVkIHZpYSBTMyByZXNvdXJjZSBwb2xpY2llcyB3aGVuIHRoZSBidWNrZXQgaXMgY3JlYXRlZC5cbiAgICAgICAgICAgICAgICAgIEFjY2VzcyB0byB0aGUgQ2xvdWRXYXRjaCBMb2dHcm91cCBpcyBhbHNvIGdyYW50ZWQgYmVsb3cgd2hlbiB0aGUgTG9nR3JvdXAgaXMgY3JlYXRlZC5cbiAgICAgICAgKi9cblxuICAgICAgICByZXR1cm4gbWF0dGVyQXVkaXRvclJvbGU7XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlcyB0aGUgSUFNIHJvbGUgZm9yIG1hbmFnaW5nIFByb2R1Y3QgQXR0ZXN0YXRpb24gQXV0aG9yaXRpZXMgKFBBQXMpXG4gICAgcHJpdmF0ZSBjcmVhdGVNYXR0ZXJNYW5hZ2VQQUFSb2xlKHJvbGVOYW1lOiBzdHJpbmcsIHBhYUFybjogc3RyaW5nKTogUm9sZSB7XG4gICAgICAgIGNvbnN0IG1hdHRlck1hbmFnZVBBQVJvbGUgPSBuZXcgUm9sZSh0aGlzLCByb2xlTmFtZSwge1xuICAgICAgICAgICAgYXNzdW1lZEJ5OiBuZXcgQWNjb3VudFByaW5jaXBhbCh0aGlzLmFjY291bnQpLFxuICAgICAgICAgICAgcm9sZU5hbWU6IHJvbGVOYW1lLFxuICAgICAgICAgICAgcGF0aDogTWF0dGVyU3RhY2subWF0dGVyUEtJUm9sZXNQYXRoXG4gICAgICAgIH0pO1xuXG4gICAgICAgIFRhZ3Mub2YobWF0dGVyTWFuYWdlUEFBUm9sZSkuYWRkKE1hdHRlclN0YWNrLm1hdHRlclBLSVRhZywgXCJcIik7XG5cbiAgICAgICAgbWF0dGVyTWFuYWdlUEFBUm9sZS5hdHRhY2hJbmxpbmVQb2xpY3koXG4gICAgICAgICAgICBuZXcgUG9saWN5KHRoaXMsIGBNYXR0ZXJQQUFgLCB7XG4gICAgICAgICAgICAgICAgc3RhdGVtZW50czogW1xuICAgICAgICAgICAgICAgICAgICBuZXcgUG9saWN5U3RhdGVtZW50KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbnM6IFtcImFjbS1wY2E6VXBkYXRlQ2VydGlmaWNhdGVBdXRob3JpdHlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImFjbS1wY2E6RGVzY3JpYmVDZXJ0aWZpY2F0ZUF1dGhvcml0eVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZUF1dGhvcml0eUNlcnRpZmljYXRlXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtwYWFBcm5dLFxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhY20tcGNhOkxpc3RDZXJ0aWZpY2F0ZUF1dGhvcml0aWVzXCJdLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtcIipcIl0sXG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgKTtcblxuICAgICAgICByZXR1cm4gbWF0dGVyTWFuYWdlUEFBUm9sZTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgdGhlIGJhY2t1cCBwbGFuIHVzaW5nIEFXUyBCYWNrdXAgZm9yIHRoZSBNYXR0ZXIgUEtJIGF1ZGl0IGxvZ2dpbmcgUzMgYnVja2V0XG4gICAgcHJpdmF0ZSBjcmVhdGVNYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBQbGFuKHByZWZpeDogc3RyaW5nKTogW0JhY2t1cFBsYW4sIElDb25zdHJ1Y3RbXV0ge1xuICAgICAgICBjb25zdCBkZXBlbmRlbmNpZXM6IElDb25zdHJ1Y3RbXSA9IFtdO1xuXG4gICAgICAgIGNvbnN0IHBsYW4gPSBuZXcgQmFja3VwUGxhbih0aGlzLCBwcmVmaXggKyBcIk1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFBsYW5cIiwge1xuICAgICAgICAgICAgYmFja3VwUGxhbk5hbWU6IHByZWZpeCArIFwiTWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUGxhblwiXG4gICAgICAgIH0pO1xuICAgICAgICBkZXBlbmRlbmNpZXMucHVzaChwbGFuKTtcbiAgICAgICAgY29uc3QgdmF1bHQgPSBuZXcgQmFja3VwVmF1bHQodGhpcywgcHJlZml4ICsgXCJNYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBWYXVsdFwiLCB7XG4gICAgICAgICAgICBiYWNrdXBWYXVsdE5hbWU6IHByZWZpeCArIFwiTWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwVmF1bHRcIlxuICAgICAgICB9KTtcbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2godmF1bHQpO1xuXG4gICAgICAgIHBsYW4uYWRkUnVsZShuZXcgQmFja3VwUGxhblJ1bGUoe1xuICAgICAgICAgICAgYmFja3VwVmF1bHQ6IHZhdWx0LFxuICAgICAgICAgICAgcnVsZU5hbWU6IFwiUnVsZUZvck1vbnRobHlCYWNrdXBzXCIsXG4gICAgICAgICAgICBzY2hlZHVsZUV4cHJlc3Npb246IFNjaGVkdWxlLmNyb24oe21pbnV0ZTogJzAnLCBob3VyOiAnMCcsIGRheTogJzEnLCBtb250aDogJyonLCB5ZWFyOiAnKid9KSwgLy8gbW9udGhseSBiYWNrdXAgb24gZmlyc3Qgb2YgZXZlcnkgbW9udGhcbiAgICAgICAgICAgIGRlbGV0ZUFmdGVyOiBEdXJhdGlvbi5kYXlzKDMyKSwgLy8gMSBleHRyYSBkYXksIHNvIHRoYXQgYXQtbGVhc3Qgb25lIGJhY2t1cCB3aWxsIHN0YXkgaW4gYWxsIGNvbmRpdGlvbnNcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBbcGxhbiwgZGVwZW5kZW5jaWVzXTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGVzIHRoZSBJQU0gcm9sZSB0aGF0IHdpbGwgYmUgdXNlZCBieSBBV1NCYWNrdXAgdG8gYmFjay11cCBkYXRhIGluIGF1ZGl0IGxvZ2dpbmcgUzMgYnVja2V0XG4gICAgcHJpdmF0ZSBjcmVhdGVNYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBSb2xlKHJvbGVOYW1lOiBzdHJpbmcpOiBSb2xlIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSb2xlKHRoaXMsIHJvbGVOYW1lLCB7XG4gICAgICAgICAgICByb2xlTmFtZTogcm9sZU5hbWUsXG4gICAgICAgICAgICBhc3N1bWVkQnk6IG5ldyBTZXJ2aWNlUHJpbmNpcGFsKCdiYWNrdXAuYW1hem9uYXdzLmNvbScpLFxuICAgICAgICAgICAgbWFuYWdlZFBvbGljaWVzOiBbXG4gICAgICAgICAgICAgICAgTWFuYWdlZFBvbGljeS5mcm9tQXdzTWFuYWdlZFBvbGljeU5hbWUoJ3NlcnZpY2Utcm9sZS9BV1NCYWNrdXBTZXJ2aWNlUm9sZVBvbGljeUZvckJhY2t1cCcpLFxuICAgICAgICAgICAgICAgIE1hbmFnZWRQb2xpY3kuZnJvbUF3c01hbmFnZWRQb2xpY3lOYW1lKCdzZXJ2aWNlLXJvbGUvQVdTQmFja3VwU2VydmljZVJvbGVQb2xpY3lGb3JSZXN0b3JlcycpLFxuICAgICAgICAgICAgICAgIE1hbmFnZWRQb2xpY3kuZnJvbUF3c01hbmFnZWRQb2xpY3lOYW1lKCdBV1NCYWNrdXBTZXJ2aWNlUm9sZVBvbGljeUZvclMzQmFja3VwJyksXG4gICAgICAgICAgICAgICAgTWFuYWdlZFBvbGljeS5mcm9tQXdzTWFuYWdlZFBvbGljeU5hbWUoJ0FXU0JhY2t1cFNlcnZpY2VSb2xlUG9saWN5Rm9yUzNSZXN0b3JlJyksXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgcGF0aDogTWF0dGVyU3RhY2subWF0dGVyUEtJUm9sZXNQYXRoXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZXMgdGhlIFMzIGJ1Y2tldCBhbmQgR2xhY2llciB2YXVsdCB0aGF0IHdpbGwgY29udGFpbiB0aGUgbG9ncyBhbmQgYXVkaXQgZGF0YSBmb3IgTWF0dGVyIFBLSS5cbiAgICBwcml2YXRlIGNyZWF0ZU1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldChwcmVmaXg6IHN0cmluZywgbWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUGxhbjogQmFja3VwUGxhbik6IFtCdWNrZXQsIElDb25zdHJ1Y3RbXV0ge1xuICAgICAgICBjb25zdCBkZXBlbmRlbmNpZXM6IElDb25zdHJ1Y3RbXSA9IFtdO1xuXG4gICAgICAgIGNvbnN0IGJ1Y2tldEtNU0tleSA9IG5ldyBLZXkodGhpcywgJ01hdHRlclBLSUF1ZGl0TG9nc0tNU0tleScsIHtcbiAgICAgICAgICAgIGVuYWJsZUtleVJvdGF0aW9uOiB0cnVlXG4gICAgICAgIH0pXG4gICAgICAgIGJ1Y2tldEtNU0tleS5ncmFudEVuY3J5cHQobmV3IFNlcnZpY2VQcmluY2lwYWwoJ2Nsb3VkdHJhaWwuYW1hem9uYXdzLmNvbScpKTtcblxuICAgICAgICBkZXBlbmRlbmNpZXMucHVzaChidWNrZXRLTVNLZXkpO1xuXG4gICAgICAgIGNvbnN0IG1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldCA9IG5ldyBCdWNrZXQodGhpcywgcHJlZml4ICsgYG1hdHRlci1wa2ktYXVkaXQtbG9nc2AsIHtcbiAgICAgICAgICAgIHZlcnNpb25lZDogdHJ1ZSxcbiAgICAgICAgICAgIGJsb2NrUHVibGljQWNjZXNzOiB7XG4gICAgICAgICAgICAgICAgYmxvY2tQdWJsaWNQb2xpY3k6IHRydWUsXG4gICAgICAgICAgICAgICAgcmVzdHJpY3RQdWJsaWNCdWNrZXRzOiB0cnVlLFxuICAgICAgICAgICAgICAgIGJsb2NrUHVibGljQWNsczogZmFsc2UsXG4gICAgICAgICAgICAgICAgaWdub3JlUHVibGljQWNsczogZmFsc2VcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlbmNyeXB0aW9uOiBCdWNrZXRFbmNyeXB0aW9uLktNUyxcbiAgICAgICAgICAgIGVuY3J5cHRpb25LZXk6IGJ1Y2tldEtNU0tleSxcbiAgICAgICAgICAgIGVuZm9yY2VTU0w6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBkZXBlbmRlbmNpZXMucHVzaChtYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQpO1xuXG4gICAgICAgIC8vIEVuYWJsZSBPYmplY3RMb2NrIG9uIFMzIEJ1Y2tldCB3aGljaCBtYWtlcyBvYmplY3RzIHdyaXRlLW9uY2UtcmVhZC1tYW55XG4gICAgICAgIGNvbnN0IGNmbkJ1Y2tldCA9IG1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldC5ub2RlLmRlZmF1bHRDaGlsZCBhcyBDZm5CdWNrZXQ7XG4gICAgICAgIGNmbkJ1Y2tldC5hZGRQcm9wZXJ0eU92ZXJyaWRlKFwiT2JqZWN0TG9ja0VuYWJsZWRcIiwgdHJ1ZSk7XG4gICAgICAgIGNmbkJ1Y2tldC5hZGRQcm9wZXJ0eU92ZXJyaWRlKFxuICAgICAgICAgICAgXCJPYmplY3RMb2NrQ29uZmlndXJhdGlvbi5PYmplY3RMb2NrRW5hYmxlZFwiLFxuICAgICAgICAgICAgXCJFbmFibGVkXCJcbiAgICAgICAgKTtcbiAgICAgICAgY2ZuQnVja2V0LmFkZFByb3BlcnR5T3ZlcnJpZGUoXG4gICAgICAgICAgICBcIk9iamVjdExvY2tDb25maWd1cmF0aW9uLlJ1bGUuRGVmYXVsdFJldGVudGlvbi5Nb2RlXCIsXG4gICAgICAgICAgICBcIkdPVkVSTkFOQ0VcIlxuICAgICAgICApO1xuICAgICAgICBjZm5CdWNrZXQuYWRkUHJvcGVydHlPdmVycmlkZShcbiAgICAgICAgICAgIFwiT2JqZWN0TG9ja0NvbmZpZ3VyYXRpb24uUnVsZS5EZWZhdWx0UmV0ZW50aW9uLkRheXNcIixcbiAgICAgICAgICAgIFJldGVudGlvbkRheXMuRklWRV9ZRUFSU1xuICAgICAgICApO1xuXG4gICAgICAgIC8vIEdyYW50IEF1ZGl0b3Igcm9sZSBhY2Nlc3MgdG8gYnVja2V0XG4gICAgICAgIG1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldC5ncmFudFJlYWQoXG4gICAgICAgICAgICBuZXcgQXJuUHJpbmNpcGFsKHRoaXMubWF0dGVyQXVkaXRvclJvbGUucm9sZUFybikpXG5cbiAgICAgICAgLy8gQWRkIExpZmVjeWNsZSBydWxlIHRvIG1vdmUgb2JqZWN0cyB0byBHbGFjaWVyIGFmdGVyIDIgbW9udGhzIGFuZCBrZWVwIHRoZW0gZm9yIDUgeWVhcnNcbiAgICAgICAgbWF0dGVyQXVkaXRMb2dnaW5nQnVja2V0LmFkZExpZmVjeWNsZVJ1bGUoe1xuICAgICAgICAgICAgaWQ6ICdNYXR0ZXJBdWRpdExvZ3NBcmNoaXZpbmdUb0dsYWNpZXInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIGV4cGlyYXRpb246IER1cmF0aW9uLmRheXMoUmV0ZW50aW9uRGF5cy5GSVZFX1lFQVJTKSxcbiAgICAgICAgICAgIHRyYW5zaXRpb25zOiBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uQWZ0ZXI6IER1cmF0aW9uLmRheXMoUmV0ZW50aW9uRGF5cy5UV09fTU9OVEhTKSxcbiAgICAgICAgICAgICAgICAgICAgc3RvcmFnZUNsYXNzOiBTdG9yYWdlQ2xhc3MuR0xBQ0lFUixcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2gobWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUGxhbi5hZGRTZWxlY3Rpb24oXCJTM0JhY2t1cFNlbGVjdGlvblwiLCB7XG4gICAgICAgICAgICByZXNvdXJjZXM6IFtCYWNrdXBSZXNvdXJjZS5mcm9tQXJuKG1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldC5idWNrZXRBcm4pXSxcbiAgICAgICAgICAgIHJvbGU6IHRoaXMubWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUm9sZVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIFttYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQsIGRlcGVuZGVuY2llc107XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlcyB0aGUgQ2xvdWRXYXRjaCBMb2dHcm91cCB3aGVyZSBtYXR0ZXIgUEtJIGF1ZGl0IGxvZ3Mgd2lsbCBiZSBmaWx0ZXJlZCBhbmQgZGlzcGxheWVkLlxuICAgIHB1YmxpYyBjcmVhdGVBdWRpdExvZ0dyb3VwKHByZWZpeDogc3RyaW5nLCByb290OiBib29sZWFuLCBtYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQ6IEJ1Y2tldCwgbWF0dGVyQXVkaXRMb2dnaW5nQmFja3VwUGxhbjogQmFja3VwUGxhbik6IFtMb2dHcm91cCwgSUNvbnN0cnVjdFtdXSB7XG4gICAgICAgIGNvbnN0IGRlcGVuZGVuY2llczogSUNvbnN0cnVjdFtdID0gW11cblxuICAgICAgICBjb25zdCBsb2dHcm91cCA9IG5ldyBMb2dHcm91cCh0aGlzLCBwcmVmaXggKyBcIk1hdHRlckF1ZGl0XCIsIHtcbiAgICAgICAgICAgIGxvZ0dyb3VwTmFtZTogcHJlZml4ICsgXCJNYXR0ZXJBdWRpdFwiLFxuICAgICAgICAgICAgcmV0ZW50aW9uOiBSZXRlbnRpb25EYXlzLlRXT19NT05USFNcbiAgICAgICAgfSk7XG5cbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2gobG9nR3JvdXApO1xuXG4gICAgICAgIC8vIEdyYW50IEF1ZGl0b3Igcm9sZSBhY2Nlc3MgdG8gTG9nR3JvdXBcbiAgICAgICAgY29uc3QgbG9nR3JvdXBBY3Rpb25zID0gW1wibG9nczpEZXNjcmliZSpcIixcbiAgICAgICAgICAgIFwibG9nczpHZXQqXCIsXG4gICAgICAgICAgICBcImxvZ3M6TGlzdCpcIixcbiAgICAgICAgICAgIFwibG9nczpTdGFydFF1ZXJ5XCIsXG4gICAgICAgICAgICBcImxvZ3M6U3RvcFF1ZXJ5XCIsXG4gICAgICAgICAgICBcImxvZ3M6VGVzdE1ldHJpY0ZpbHRlclwiLFxuICAgICAgICAgICAgXCJsb2dzOkZpbHRlckxvZ0V2ZW50c1wiXVxuICAgICAgICBsb2dHcm91cC5ncmFudCh0aGlzLm1hdHRlckF1ZGl0b3JSb2xlLCAuLi5sb2dHcm91cEFjdGlvbnMpO1xuICAgICAgICBpZiAodGhpcy5tYXR0ZXJBdWRpdG9yUm9sZS5ub2RlLnRyeUZpbmRDaGlsZCgnUG9saWN5JykpXG4gICAgICAgICAgICBkZXBlbmRlbmNpZXMucHVzaCh0aGlzLm1hdHRlckF1ZGl0b3JSb2xlLm5vZGUudHJ5RmluZENoaWxkKCdQb2xpY3knKSBhcyBJQ29uc3RydWN0KTtcblxuICAgICAgICAvLyBGaWx0ZXIgTG9nR3JvdXAgdG8gY29udGFpbiBvbmx5IE1hdHRlciByZWxldmFudCBldmVudHNcbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2godGhpcy5jcmVhdGVNZXRyaWNGaWx0ZXIobG9nR3JvdXAsICdBbGxQQ0FFdmVudHNGaWx0ZXInLCAneyAoJC5ldmVudFNvdXJjZSA9IFwiYWNtLXBjYS5hbWF6b25hd3MuY29tXCIpIH0nKSk7XG4gICAgICAgIGRlcGVuZGVuY2llcy5wdXNoKHRoaXMuY3JlYXRlTWV0cmljRmlsdGVyKGxvZ0dyb3VwLCAnTWF0dGVyQXVkaXRMb2dnaW5nQnVja2V0RmlsdGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJ3sgKCQuZXZlbnRTb3VyY2U9IFwiczMuYW1hem9uYXdzLmNvbVwiKSAmJiAoJC5yZXF1ZXN0UGFyYW1ldGVycy5idWNrZXROYW1lID0gXCInICsgbWF0dGVyQXVkaXRMb2dnaW5nQnVja2V0LmJ1Y2tldE5hbWUgKyAnKlwiKSB9JykpO1xuICAgICAgICBkZXBlbmRlbmNpZXMucHVzaCh0aGlzLmNyZWF0ZU1ldHJpY0ZpbHRlcihsb2dHcm91cCwgJ01hdHRlclRhZ2dlZEZpbHRlcicsIE1hdHRlclN0YWNrLm1hdHRlclBLSVRhZykpO1xuICAgICAgICBpZiAocm9vdCkge1xuICAgICAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2godGhpcy5jcmVhdGVNZXRyaWNGaWx0ZXIobG9nR3JvdXAsICdNYXR0ZXJQQUFSb2xlRmlsdGVyJywgJ2lhbS5hbWF6b25hd3MuY29tICcgKyB0aGlzLm1hdHRlck1hbmFnZVBBQVJvbGUucm9sZU5hbWUpKTtcbiAgICAgICAgICAgIGRlcGVuZGVuY2llcy5wdXNoKHRoaXMuY3JlYXRlTWV0cmljRmlsdGVyKGxvZ0dyb3VwLCAnTWF0dGVyUEFJUm9sZUZpbHRlcicsICdpYW0uYW1hem9uYXdzLmNvbSAnICsgdGhpcy5tYXR0ZXJJc3N1ZVBBSVJvbGUucm9sZU5hbWUpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRlcGVuZGVuY2llcy5wdXNoKHRoaXMuY3JlYXRlTWV0cmljRmlsdGVyKGxvZ0dyb3VwLCAnTWF0dGVySXNzdWVEQUNSb2xlRmlsdGVyJywgJ2lhbS5hbWF6b25hd3MuY29tICcgKyB0aGlzLm1hdHRlcklzc3VlREFDUm9sZS5yb2xlTmFtZSkpO1xuICAgICAgICB9XG4gICAgICAgIGRlcGVuZGVuY2llcy5wdXNoKHRoaXMuY3JlYXRlTWV0cmljRmlsdGVyKGxvZ0dyb3VwLCAnTWF0dGVyQXVkaXRvclJvbGVGaWx0ZXInLCAnaWFtLmFtYXpvbmF3cy5jb20gJyArIHRoaXMubWF0dGVyQXVkaXRvclJvbGUucm9sZU5hbWUpKTtcbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2godGhpcy5jcmVhdGVNZXRyaWNGaWx0ZXIobG9nR3JvdXAsICdNYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBSb2xlRmlsdGVyJywgJ2lhbS5hbWF6b25hd3MuY29tICcgKyB0aGlzLm1hdHRlckF1ZGl0TG9nZ2luZ0JhY2t1cFJvbGUucm9sZU5hbWUpKTtcbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2godGhpcy5jcmVhdGVNZXRyaWNGaWx0ZXIobG9nR3JvdXAsICdNYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBQbGFuRmlsdGVyJywgJ2JhY2t1cC5hbWF6b25hd3MuY29tICcgKyBtYXR0ZXJBdWRpdExvZ2dpbmdCYWNrdXBQbGFuLmJhY2t1cFBsYW5JZCkpO1xuXG4gICAgICAgIGlmIChyb290KSB7XG4gICAgICAgICAgICBuZXcgQ2ZuT3V0cHV0KHRoaXMsICdMb2dHcm91cE5hbWUnLCB7XG4gICAgICAgICAgICAgICAgdmFsdWU6IGxvZ0dyb3VwLmxvZ0dyb3VwTmFtZSxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1RoZSBuYW1lIG9mIHRoZSBDbG91ZFdhdGNoIExvZ0dyb3VwJyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIFtsb2dHcm91cCwgZGVwZW5kZW5jaWVzXTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGVzIHRoZSBDbG91ZFRyYWlsIGZvciByZWNvcmRpbmcgQVdTIGV2ZW50cyB3aGljaCB3aWxsIGJlIHN0b3JlZCBpbiBTM1xuICAgIHB1YmxpYyBjcmVhdGVBdWRpdENsb3VkVHJhaWwocHJlZml4OiBzdHJpbmcsIHJvb3Q6IGJvb2xlYW4sIGF1ZGl0TG9nR3JvdXA6IExvZ0dyb3VwLCBtYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQ6IEJ1Y2tldCk6IFtUcmFpbCwgSUNvbnN0cnVjdFtdXSB7XG4gICAgICAgIGNvbnN0IGRlcGVuZGVuY2llczogSUNvbnN0cnVjdFtdID0gW107XG5cbiAgICAgICAgY29uc3QgdHJhaWwgPSBuZXcgVHJhaWwodGhpcywgcHJlZml4ICsgJ01hdHRlckF1ZGl0VHJhaWwnLCB7XG4gICAgICAgICAgICBzZW5kVG9DbG91ZFdhdGNoTG9nczogdHJ1ZSxcbiAgICAgICAgICAgIGVuYWJsZUZpbGVWYWxpZGF0aW9uOiB0cnVlLFxuICAgICAgICAgICAgYnVja2V0OiBtYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQsXG4gICAgICAgICAgICBjbG91ZFdhdGNoTG9nR3JvdXA6IGF1ZGl0TG9nR3JvdXAsXG4gICAgICAgICAgICBlbmNyeXB0aW9uS2V5OiBtYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQuZW5jcnlwdGlvbktleVxuICAgICAgICB9KTtcbiAgICAgICAgZGVwZW5kZW5jaWVzLnB1c2godHJhaWwpO1xuXG4gICAgICAgIGNvbnN0IHJvbGUgPSB0cmFpbC5ub2RlLmZpbmRDaGlsZCgnTG9nc1JvbGUnKSBhcyBSb2xlXG4gICAgICAgIGNvbnN0IHJvbGVQb2xpY3kgPSByb2xlLm5vZGUuZmluZENoaWxkKFwiRGVmYXVsdFBvbGljeVwiKSBhcyBQb2xpY3k7XG4gICAgICAgIGRlcGVuZGVuY2llcy5wdXNoKHJvbGVQb2xpY3kpO1xuXG4gICAgICAgIGNvbnN0IHMzRXZlbnRTZWxlY3RvcjogUzNFdmVudFNlbGVjdG9yID0ge1xuICAgICAgICAgICAgYnVja2V0OiBtYXR0ZXJBdWRpdExvZ2dpbmdCdWNrZXQsXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGJ1Y2tldFBvbGljeSA9IG1hdHRlckF1ZGl0TG9nZ2luZ0J1Y2tldC5ub2RlLmZpbmRDaGlsZCgnUG9saWN5JykgYXMgUG9saWN5O1xuICAgICAgICBkZXBlbmRlbmNpZXMucHVzaChidWNrZXRQb2xpY3kpO1xuXG4gICAgICAgIHRyYWlsLmFkZFMzRXZlbnRTZWxlY3RvcihbczNFdmVudFNlbGVjdG9yXSk7XG5cbiAgICAgICAgaWYgKHJvb3QpIHtcbiAgICAgICAgICAgIG5ldyBDZm5PdXRwdXQodGhpcywgJ0Nsb3VkVHJhaWxBcm4nLCB7XG4gICAgICAgICAgICAgICAgdmFsdWU6IHRyYWlsLnRyYWlsQXJuLFxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIEFSTiBvZiB0aGUgQ2xvdWRUcmFpbCcsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBbdHJhaWwsIGRlcGVuZGVuY2llc107XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjcmVhdGVNZXRyaWNGaWx0ZXIobG9nR3JvdXA6IExvZ0dyb3VwLCBtZXRyaWNOYW1lOiBzdHJpbmcsIG1ldHJpY1BhdHRlcm46IHN0cmluZyk6IElDb25zdHJ1Y3Qge1xuICAgICAgICByZXR1cm4gbmV3IE1ldHJpY0ZpbHRlcih0aGlzLCBtZXRyaWNOYW1lLCB7XG4gICAgICAgICAgICBtZXRyaWNOYW1lOiBtZXRyaWNOYW1lLFxuICAgICAgICAgICAgZmlsdGVyUGF0dGVybjoge1xuICAgICAgICAgICAgICAgIGxvZ1BhdHRlcm5TdHJpbmc6IG1ldHJpY1BhdHRlcm5cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBsb2dHcm91cDogbG9nR3JvdXAsXG4gICAgICAgICAgICBtZXRyaWNOYW1lc3BhY2U6ICdDbG91ZFRyYWlsJ1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNyZWF0ZVBjYVZhbGlkaXR5SW5zdGFuY2UodmFsaWRpdHlJbkRheXM6IG51bWJlciwgdmFsaWRpdHlFbmREYXRlOiBzdHJpbmcpOiBJQ2ZuUnVsZUNvbmRpdGlvbkV4cHJlc3Npb24ge1xuICAgICAgICBjb25zdCB1c2VWYWxpZGl0eUVuZERhdGUgPSBuZXcgQ2ZuQ29uZGl0aW9uKHRoaXMsICdWYWxpZGl0eUVuZERhdGVXYXNQcm92aWRlZCcsIHtcbiAgICAgICAgICAgIGV4cHJlc3Npb246IEZuLmNvbmRpdGlvbk5vdChGbi5jb25kaXRpb25FcXVhbHModmFsaWRpdHlFbmREYXRlLCAnJykpXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gRm4uY29uZGl0aW9uSWYodXNlVmFsaWRpdHlFbmREYXRlLmxvZ2ljYWxJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtUeXBlOiBcIkVORF9EQVRFXCIsIFZhbHVlOiB2YWxpZGl0eUVuZERhdGV9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1R5cGU6IFwiREFZU1wiLCBWYWx1ZTogdmFsaWRpdHlJbkRheXN9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNyZWF0ZVBjYVZhbGlkaXR5U3RyaW5ncyh2YWxpZGl0eUluRGF5czogbnVtYmVyLCB2YWxpZGl0eUVuZERhdGU6IHN0cmluZyk6IFtJQ2ZuUnVsZUNvbmRpdGlvbkV4cHJlc3Npb24sIElDZm5SdWxlQ29uZGl0aW9uRXhwcmVzc2lvbl0ge1xuICAgICAgICBjb25zdCB1c2VWYWxpZGl0eUVuZERhdGUgPSBuZXcgQ2ZuQ29uZGl0aW9uKHRoaXMsICdWYWxpZGl0eUVuZERhdGVXYXNQcm92aWRlZCcsIHtcbiAgICAgICAgICAgIGV4cHJlc3Npb246IEZuLmNvbmRpdGlvbk5vdChGbi5jb25kaXRpb25FcXVhbHModmFsaWRpdHlFbmREYXRlLCAnJykpXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gW0ZuLmNvbmRpdGlvbklmKHVzZVZhbGlkaXR5RW5kRGF0ZS5sb2dpY2FsSWQsIFwiRU5EX0RBVEVcIiwgXCJEQVlTXCIpLFxuICAgICAgICAgICAgICAgIEZuLmNvbmRpdGlvbklmKHVzZVZhbGlkaXR5RW5kRGF0ZS5sb2dpY2FsSWQsIHZhbGlkaXR5RW5kRGF0ZSwgdmFsaWRpdHlJbkRheXMpXTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNyZWF0ZVBBQShjb21tb25OYW1lOiBzdHJpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgb3JnYW5pemF0aW9uOiBzdHJpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgb3JnYW5pemF0aW9uYWxVbml0OiBzdHJpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgdmFsaWRpdHk6IElDZm5SdWxlQ29uZGl0aW9uRXhwcmVzc2lvbixcbiAgICAgICAgICAgICAgICAgICAgICB2ZW5kb3JJZDogc3RyaW5nKTogQ2ZuQ2VydGlmaWNhdGVBdXRob3JpdHlBY3RpdmF0aW9uIHtcblxuICAgICAgICBjb25zdCBjdXN0b21BdHRyaWJ1dGVzID0gW1xuICAgICAgICAgICAgeyAvLyBTdWJqZWN0IGNhbiBlaXRoZXIgaGF2ZSBzdGFuZGFyZCBhdHRyaWJ1dGVzIG9yIGN1c3RvbSBhdHRyaWJ1dGVzIGJ1dCBub3QgYm90aC5cbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjIuNS40LjNcIiwgICAgICAgICAgICAgICAgLy8gY29tbW9uTmFtZVxuICAgICAgICAgICAgICAgIFZhbHVlOiBjb21tb25OYW1lXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIE9iamVjdElkZW50aWZpZXI6IFwiMS4zLjYuMS40LjEuMzcyNDQuMi4xXCIsICAvLyBWZW5kb3JJRCwgbWF0dGVyLW9pZC12aWRcbiAgICAgICAgICAgICAgICBWYWx1ZTogdmVuZG9ySWRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMFwiLCAgICAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvblxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25cbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcblxuICAgICAgICBjb25zdCBjdXN0b21BdHRyaWJ1dGVzV2l0aE9VID0gW1xuICAgICAgICAgICAgeyAvLyBTdWJqZWN0IGNhbiBlaXRoZXIgaGF2ZSBzdGFuZGFyZCBhdHRyaWJ1dGVzIG9yIGN1c3RvbSBhdHRyaWJ1dGVzIGJ1dCBub3QgYm90aC5cbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjIuNS40LjNcIiwgICAgICAgICAgICAgICAgLy8gY29tbW9uTmFtZVxuICAgICAgICAgICAgICAgIFZhbHVlOiBjb21tb25OYW1lXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIE9iamVjdElkZW50aWZpZXI6IFwiMS4zLjYuMS40LjEuMzcyNDQuMi4xXCIsICAvLyBWZW5kb3JJRCwgbWF0dGVyLW9pZC12aWRcbiAgICAgICAgICAgICAgICBWYWx1ZTogdmVuZG9ySWRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMFwiLCAgICAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvblxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMVwiLCAgICAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvbmFsVW5pdFxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25hbFVuaXRcbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcblxuICAgICAgICBjb25zdCB1c2VDdXN0b21BdHRyc1dpdGhPVSA9IG5ldyBDZm5Db25kaXRpb24odGhpcywgJ09yZ1VuaXRXYXNQcm92aWRlZCcsIHtcbiAgICAgICAgICAgZXhwcmVzc2lvbjogRm4uY29uZGl0aW9uTm90KEZuLmNvbmRpdGlvbkVxdWFscyhvcmdhbml6YXRpb25hbFVuaXQsICcnKSlcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgY2ZuQ0EgPSBuZXcgcGNhLkNmbkNlcnRpZmljYXRlQXV0aG9yaXR5KHRoaXMsICdDQS1QQUEnLCB7XG4gICAgICAgICAgICB0eXBlOiAnUk9PVCcsXG4gICAgICAgICAgICBrZXlBbGdvcml0aG06ICdFQ19wcmltZTI1NnYxJyxcbiAgICAgICAgICAgIHNpZ25pbmdBbGdvcml0aG06ICdTSEEyNTZXSVRIRUNEU0EnLFxuICAgICAgICAgICAga2V5U3RvcmFnZVNlY3VyaXR5U3RhbmRhcmQ6ICdGSVBTXzE0MF8yX0xFVkVMXzNfT1JfSElHSEVSJyxcbiAgICAgICAgICAgIHN1YmplY3Q6IHtcbiAgICAgICAgICAgICAgICBjdXN0b21BdHRyaWJ1dGVzOiBGbi5jb25kaXRpb25JZih1c2VDdXN0b21BdHRyc1dpdGhPVS5sb2dpY2FsSWQsIGN1c3RvbUF0dHJpYnV0ZXNXaXRoT1UsIGN1c3RvbUF0dHJpYnV0ZXMpXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdGFnczogW1xuICAgICAgICAgICAgICAgIHsga2V5OiBcIm1hdHRlckNBVHlwZVwiLCB2YWx1ZTogXCJwYWFcIiB9LFxuICAgICAgICAgICAgICAgIHsga2V5OiBNYXR0ZXJTdGFjay5tYXR0ZXJQS0lUYWcsIHZhbHVlOiBcIlwiICB9XG4gICAgICAgICAgICBdLFxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBTdGF5aW5nIG9uIHNhZmUgc2lkZSBoZXJlLlxuICAgICAgICBjZm5DQS5jZm5PcHRpb25zLmRlbGV0aW9uUG9saWN5ID0gQ2ZuRGVsZXRpb25Qb2xpY3kuUkVUQUlOO1xuICAgICAgICBjZm5DQS5jZm5PcHRpb25zLnVwZGF0ZVJlcGxhY2VQb2xpY3kgPSBDZm5EZWxldGlvblBvbGljeS5SRVRBSU47XG5cbiAgICAgICAgY29uc3QgY2ZuQ2FDZXJ0ID0gbmV3IHBjYS5DZm5DZXJ0aWZpY2F0ZSh0aGlzLCAnQ2VydC1QQUEnLCB7XG4gICAgICAgICAgICBjZXJ0aWZpY2F0ZUF1dGhvcml0eUFybjogY2ZuQ0EuYXR0ckFybixcbiAgICAgICAgICAgIGNlcnRpZmljYXRlU2lnbmluZ1JlcXVlc3Q6IGNmbkNBLmF0dHJDZXJ0aWZpY2F0ZVNpZ25pbmdSZXF1ZXN0LFxuICAgICAgICAgICAgc2lnbmluZ0FsZ29yaXRobTogJ1NIQTI1NldJVEhFQ0RTQScsXG4gICAgICAgICAgICB2YWxpZGl0eTogdmFsaWRpdHksXG4gICAgICAgICAgICAvLyBUaGlzIHRlbXBsYXRlIGNvbWVzIHdpdGgga2V5Q2VydFNpZ24sIGNSTFNpZ24sIGFuZCBkaWdpdGFsU2lnbmF0dXJlIEtleSBVc2FnZSBiaXRzIHNldC5cbiAgICAgICAgICAgIHRlbXBsYXRlQXJuOiBcImFybjphd3M6YWNtLXBjYTo6OnRlbXBsYXRlL1Jvb3RDQUNlcnRpZmljYXRlX0FQSVBhc3N0aHJvdWdoL1YxXCJcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbmV3IENmbk91dHB1dCh0aGlzLCAnUEFBQ2VydEFybicsIHtcbiAgICAgICAgICAgIHZhbHVlOiBjZm5DYUNlcnQuYXR0ckFybixcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIEFSTiBvZiB0aGUgUEFBIGNlcnRpZmljYXRlJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbmV3IENmbk91dHB1dCh0aGlzLCAnUEFBQ2VydExpbmsnLCB7XG4gICAgICAgICAgICB2YWx1ZTpcImh0dHBzOi8vY29uc29sZS5hd3MuYW1hem9uLmNvbS9hY20tcGNhL2hvbWU/cmVnaW9uPVwiICsgdGhpcy5yZWdpb24gKyBcIiMvZGV0YWlscz9hcm49XCIgKyBjZm5DQS5hdHRyQXJuICsgXCImdGFiPWNlcnRpZmljYXRlXCIsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1RoZSBsaW5rIHRvIHRoZSBQQUEgY2VydGlmaWNhdGUgaW4gdGhlIEFXUyBQcml2YXRlIENBIGNvbnNvbGUnLFxuICAgICAgICB9KTtcblxuICAgICAgICBuZXcgQ2ZuT3V0cHV0KHRoaXMsICdQQUEnLCB7XG4gICAgICAgICAgICB2YWx1ZTogXCJWSUQ9XCIgKyB2ZW5kb3JJZCArIFwiIENOPVwiICsgY29tbW9uTmFtZSArIFwiIFwiICsgY2ZuQ0EuYXR0ckFybixcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIEFSTiBvZiB0aGUgUEFBJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIG5ldyBwY2EuQ2ZuQ2VydGlmaWNhdGVBdXRob3JpdHlBY3RpdmF0aW9uKHRoaXMsICdDZXJ0QWN0aXZhdGlvbicgKyAnLVBBQScsIHtcbiAgICAgICAgICAgIGNlcnRpZmljYXRlQXV0aG9yaXR5QXJuOiBjZm5DQS5hdHRyQXJuLFxuICAgICAgICAgICAgY2VydGlmaWNhdGU6IGNmbkNhQ2VydC5hdHRyQ2VydGlmaWNhdGUsXG4gICAgICAgICAgICBzdGF0dXM6IFwiQUNUSVZFXCJcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBjcmVhdGVQQUkoY29tbW9uTmFtZTogc3RyaW5nLFxuICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbjogc3RyaW5nLFxuICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbmFsVW5pdDogSUNmbkNvbmRpdGlvbkV4cHJlc3Npb24sXG4gICAgICAgICAgICAgICAgICAgICAgb3JnYW5pemF0aW9uYWxVbml0U2V0OiBDZm5Db25kaXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgdmFsaWRpdHk6IFtJQ2ZuQ29uZGl0aW9uRXhwcmVzc2lvbiwgSUNmbkNvbmRpdGlvbkV4cHJlc3Npb25dLFxuICAgICAgICAgICAgICAgICAgICAgIHZlbmRvcklkOiBzdHJpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgcGFpSWQ6IG51bWJlcixcbiAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWRzOiBzdHJpbmdbXSxcbiAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWRzU2V0OiBDZm5Db25kaXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgcGFyZW50Q0FBcm46IHN0cmluZyxcbiAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRSZWdpb246IHN0cmluZyxcbiAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRQZW06IHN0cmluZyk6IENmbkNlcnRpZmljYXRlQXV0aG9yaXR5QWN0aXZhdGlvbiB7XG5cbiAgICAgICAgY29uc3QgaWQgPSAnLVBBSS0nICsgcGFpSWQhO1xuXG4gICAgICAgIGNvbnN0IHBpZCA9IEZuLmNvbmRpdGlvbklmKHByb2R1Y3RJZHNTZXQubG9naWNhbElkLCBGbi5zZWxlY3QocGFpSWQsIHByb2R1Y3RJZHMpLCAnJyk7XG5cbiAgICAgICAgY29uc3QgY3VzdG9tQXR0cmlidXRlcyA9IFtcbiAgICAgICAgICAgIHsgLy8gU3ViamVjdCBjYW4gZWl0aGVyIGhhdmUgc3RhbmRhcmQgYXR0cmlidXRlcyBvciBjdXN0b20gYXR0cmlidXRlcyBidXQgbm90IGJvdGguXG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4zXCIsICAgICAgICAgICAgICAgIC8vIGNvbW1vbk5hbWVcbiAgICAgICAgICAgICAgICBWYWx1ZTogY29tbW9uTmFtZVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjEuMy42LjEuNC4xLjM3MjQ0LjIuMVwiLCAgLy8gVmVuZG9ySUQsIG1hdHRlci1vaWQtdmlkXG4gICAgICAgICAgICAgICAgVmFsdWU6IHZlbmRvcklkXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIE9iamVjdElkZW50aWZpZXI6IFwiMi41LjQuMTBcIiwgICAgICAgICAgICAvLyBvcmdhbml6YXRpb25cbiAgICAgICAgICAgICAgICBWYWx1ZTogb3JnYW5pemF0aW9uXG4gICAgICAgICAgICB9XG4gICAgICAgIF07XG5cbiAgICAgICAgY29uc3QgY3VzdG9tQXR0cmlidXRlc1dpdGhQaWQgPSBbXG4gICAgICAgICAgICB7IC8vIFN1YmplY3QgY2FuIGVpdGhlciBoYXZlIHN0YW5kYXJkIGF0dHJpYnV0ZXMgb3IgY3VzdG9tIGF0dHJpYnV0ZXMgYnV0IG5vdCBib3RoLlxuICAgICAgICAgICAgICAgIE9iamVjdElkZW50aWZpZXI6IFwiMi41LjQuM1wiLCAgICAgICAgICAgICAgICAvLyBjb21tb25OYW1lXG4gICAgICAgICAgICAgICAgVmFsdWU6IGNvbW1vbk5hbWVcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIxLjMuNi4xLjQuMS4zNzI0NC4yLjFcIiwgIC8vIFZlbmRvcklELCBtYXR0ZXItb2lkLXZpZFxuICAgICAgICAgICAgICAgIFZhbHVlOiB2ZW5kb3JJZFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjIuNS40LjEwXCIsICAgICAgICAgICAgLy8gb3JnYW5pemF0aW9uXG4gICAgICAgICAgICAgICAgVmFsdWU6IG9yZ2FuaXphdGlvblxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjEuMy42LjEuNC4xLjM3MjQ0LjIuMlwiLCAgLy8gUHJvZHVjdElELCBtYXR0ZXItb2lkLXBpZFxuICAgICAgICAgICAgICAgIFZhbHVlOiBwaWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcblxuICAgICAgICBjb25zdCBjdXN0b21BdHRyaWJ1dGVzV2l0aE91ID0gW1xuICAgICAgICAgICAgeyAvLyBTdWJqZWN0IGNhbiBlaXRoZXIgaGF2ZSBzdGFuZGFyZCBhdHRyaWJ1dGVzIG9yIGN1c3RvbSBhdHRyaWJ1dGVzIGJ1dCBub3QgYm90aC5cbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjIuNS40LjNcIiwgICAgICAgICAgICAgICAgLy8gY29tbW9uTmFtZVxuICAgICAgICAgICAgICAgIFZhbHVlOiBjb21tb25OYW1lXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIE9iamVjdElkZW50aWZpZXI6IFwiMS4zLjYuMS40LjEuMzcyNDQuMi4xXCIsICAvLyBWZW5kb3JJRCwgbWF0dGVyLW9pZC12aWRcbiAgICAgICAgICAgICAgICBWYWx1ZTogdmVuZG9ySWRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMFwiLCAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvblxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMVwiLCAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvbmFsVW5pdFxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25hbFVuaXRcbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcblxuICAgICAgICBjb25zdCBjdXN0b21BdHRyaWJ1dGVzV2l0aE91UGlkID0gW1xuICAgICAgICAgICAgeyAvLyBTdWJqZWN0IGNhbiBlaXRoZXIgaGF2ZSBzdGFuZGFyZCBhdHRyaWJ1dGVzIG9yIGN1c3RvbSBhdHRyaWJ1dGVzIGJ1dCBub3QgYm90aC5cbiAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiBcIjIuNS40LjNcIiwgICAgICAgICAgICAgICAgLy8gY29tbW9uTmFtZVxuICAgICAgICAgICAgICAgIFZhbHVlOiBjb21tb25OYW1lXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIE9iamVjdElkZW50aWZpZXI6IFwiMS4zLjYuMS40LjEuMzcyNDQuMi4xXCIsICAvLyBWZW5kb3JJRCwgbWF0dGVyLW9pZC12aWRcbiAgICAgICAgICAgICAgICBWYWx1ZTogdmVuZG9ySWRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMFwiLCAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvblxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIyLjUuNC4xMVwiLCAgICAgICAgICAgIC8vIG9yZ2FuaXphdGlvbmFsVW5pdFxuICAgICAgICAgICAgICAgIFZhbHVlOiBvcmdhbml6YXRpb25hbFVuaXRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgT2JqZWN0SWRlbnRpZmllcjogXCIxLjMuNi4xLjQuMS4zNzI0NC4yLjJcIiwgIC8vIFByb2R1Y3RJRCwgbWF0dGVyLW9pZC1waWRcbiAgICAgICAgICAgICAgICBWYWx1ZTogcGlkXG4gICAgICAgICAgICB9XG4gICAgICAgIF07XG5cbiAgICAgICAgY29uc3QgcGlkQW5kT3VTZXQgPSBuZXcgQ2ZuQ29uZGl0aW9uKHRoaXMsIGBQYWlQaWRBbmRPdVdlcmVQcm92aWRlZC0ke3BhaUlkfWAsIHtcbiAgICAgICAgICAgIGV4cHJlc3Npb246IEZuLmNvbmRpdGlvbkFuZChwcm9kdWN0SWRzU2V0LCBvcmdhbml6YXRpb25hbFVuaXRTZXQpXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCB0YXJnZXRDdXN0b21BdHRyaWJ1dGVzID1cbiAgICAgICAgICAgIEZuLmNvbmRpdGlvbklmKHBpZEFuZE91U2V0LmxvZ2ljYWxJZCwgY3VzdG9tQXR0cmlidXRlc1dpdGhPdVBpZCxcbiAgICAgICAgICAgICAgICBGbi5jb25kaXRpb25JZihwcm9kdWN0SWRzU2V0LmxvZ2ljYWxJZCwgY3VzdG9tQXR0cmlidXRlc1dpdGhQaWQsXG4gICAgICAgICAgICAgICAgICAgIEZuLmNvbmRpdGlvbklmKG9yZ2FuaXphdGlvbmFsVW5pdFNldC5sb2dpY2FsSWQsIGN1c3RvbUF0dHJpYnV0ZXNXaXRoT3UsIGN1c3RvbUF0dHJpYnV0ZXMpKSk7XG5cbiAgICAgICAgY29uc3QgY2ZuQ0EgPSBuZXcgcGNhLkNmbkNlcnRpZmljYXRlQXV0aG9yaXR5KHRoaXMsICdDQScgKyBpZCwge1xuICAgICAgICAgICAgdHlwZTogJ1NVQk9SRElOQVRFJyxcbiAgICAgICAgICAgIGtleUFsZ29yaXRobTogJ0VDX3ByaW1lMjU2djEnLFxuICAgICAgICAgICAgc2lnbmluZ0FsZ29yaXRobTogJ1NIQTI1NldJVEhFQ0RTQScsXG4gICAgICAgICAgICBrZXlTdG9yYWdlU2VjdXJpdHlTdGFuZGFyZDogJ0ZJUFNfMTQwXzJfTEVWRUxfM19PUl9ISUdIRVInLFxuICAgICAgICAgICAgc3ViamVjdDoge1xuICAgICAgICAgICAgICAgIGN1c3RvbUF0dHJpYnV0ZXM6IHRhcmdldEN1c3RvbUF0dHJpYnV0ZXNcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0YWdzOiBbXG4gICAgICAgICAgICAgICAgeyBrZXk6IE1hdHRlclN0YWNrLm1hdHRlckNBVHlwZVRhZywgdmFsdWU6IFwicGFpXCIgfSxcbiAgICAgICAgICAgICAgICB7IGtleTogTWF0dGVyU3RhY2subWF0dGVyUEtJVGFnLCB2YWx1ZTogXCJcIiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFN0YXlpbmcgb24gc2FmZSBzaWRlIGhlcmUuXG4gICAgICAgIGNmbkNBLmNmbk9wdGlvbnMuZGVsZXRpb25Qb2xpY3kgPSBDZm5EZWxldGlvblBvbGljeS5SRVRBSU47XG4gICAgICAgIGNmbkNBLmNmbk9wdGlvbnMudXBkYXRlUmVwbGFjZVBvbGljeSA9IENmbkRlbGV0aW9uUG9saWN5LlJFVEFJTjtcblxuICAgICAgICAvLyBDREsgd29ya2Fyb3VuZC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gV2UgbmVlZCB0byByZW1vdmUgJ1xcbicgY2hhcmFjdGVycyBmcm9tIHRoZSBDU1IgKHdoaWNoIG11c3QgYmUgcHJlc2VudCkuIE90aGVyd2lzZSwgQXdzQ3VzdG9tUmVzb3VyY2UsIHdoaWxlIGZvcm1hdHRpbmcgTGFtYmRhXG4gICAgICAgIC8vIGlucHV0IEpTT04gc3RyaW5nLCB3b3VsZCBhZGQgdGhlbSBhcyBpcywgZW5kaW5nIHVwIHdpdGggYW4gaW52YWxpZCBKU09OLiBJbnN0ZWFkLCB0aGV5IG5lZWQgdG8gYmUgZXNjYXBlZCBsaWtlICdcXFxcbicuXG4gICAgICAgIC8vXG4gICAgICAgIC8vIFdlIGNvdWxkIGp1c3QgdXNlIEZuLmpvaW4oJ1xcXFxuJywgRm4uc3BsaXQoJ1xcbicsIC4uLikpIGlmIEF3c0N1c3RvbVJlc291cmNlIGRpZG4ndCBlc2NhcGUgdGhvc2UgbGl0ZXJhbHMgaW50byAgJ1xcXFxcXFxcbicgYW5kXG4gICAgICAgIC8vICdcXFxcbicsIHdoaWNoIHByZXZlbnRzIEZuLnNwbGl0KCkgZnJvbSBmaW5kaW5nIGFueSBjaGFyYWN0ZXJzLiBXZSBhbHNvIGNhbm5vdCBwYXNzIGluIGFueSBUb2tlbiBhcyBhIGRlbGltaXRlciwgaXQncyBub3RcbiAgICAgICAgLy8gc3VwcG9ydGVkLlxuICAgICAgICAvL1xuICAgICAgICAvLyBIZXJlIHdlIHNpbXBseSB3cml0ZSBDU1Igd2l0aCBlc2NhcGVkIG5ld2xpbmUgY2hhcmFjdGVycyBpbnRvIGFuIFNTTSBwYXJhbWV0ZXIsIGFuZCB0aGVuIHBhc3MgaXRzIHZhbHVlIHRvIEF3c0N1c3RvbVJlc291cmNlLlxuICAgICAgICAvLyBUaGlzIHdheSB3ZSBhdm9pZCBhbnkgaXNzdWVzLlxuICAgICAgICBjb25zdCBjYUNlcnRDc3JQYXJhbSA9IG5ldyBTdHJpbmdQYXJhbWV0ZXIodGhpcywgdGhpcy5ub2RlLmlkICsgJy1QQUktQ1NSLScgKyBwYWlJZCwge1xuICAgICAgICAgICAgcGFyYW1ldGVyTmFtZTogJy8nICsgdGhpcy5ub2RlLmlkICsgJy9QQUktQ1NSJyArIHBhaUlkLFxuICAgICAgICAgICAgc3RyaW5nVmFsdWU6IEZuLmpvaW4oJ1xcXFxuJywgRm4uc3BsaXQoJ1xcbicsIGNmbkNBLmF0dHJDZXJ0aWZpY2F0ZVNpZ25pbmdSZXF1ZXN0KSlcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgY2FDZXJ0QXJuID0gbmV3IEF3c0N1c3RvbVJlc291cmNlKHRoaXMsICdDZXJ0aWZpY2F0ZScgKyBpZCwge1xuICAgICAgICAgICAgb25VcGRhdGU6IHtcbiAgICAgICAgICAgICAgICBzZXJ2aWNlOiAnQUNNUENBJyxcbiAgICAgICAgICAgICAgICBhY3Rpb246ICdpc3N1ZUNlcnRpZmljYXRlJyxcbiAgICAgICAgICAgICAgICBwYXJhbWV0ZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgIENlcnRpZmljYXRlQXV0aG9yaXR5QXJuOiBwYXJlbnRDQUFybixcbiAgICAgICAgICAgICAgICAgICAgQ3NyOiBjYUNlcnRDc3JQYXJhbS5zdHJpbmdWYWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgU2lnbmluZ0FsZ29yaXRobTogJ1NIQTI1NldJVEhFQ0RTQScsXG4gICAgICAgICAgICAgICAgICAgIFZhbGlkaXR5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBUeXBlOiB2YWxpZGl0eVswXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFZhbHVlOiBUb2tlbi5hc051bWJlcih2YWxpZGl0eVsxXSlcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgVGVtcGxhdGVBcm46IFwiYXJuOmF3czphY20tcGNhOjo6dGVtcGxhdGUvQmxhbmtTdWJvcmRpbmF0ZUNBQ2VydGlmaWNhdGVfUGF0aExlbjBfQVBJUGFzc3Rocm91Z2gvVjFcIixcbiAgICAgICAgICAgICAgICAgICAgLy8gQ3VycmVudGx5IHRoZSBvbmx5IHdheSB0byBvbmx5IHNldCBrZXlDZXJ0U2lnbiBhbmQgY1JMU2lnbiBiaXRzIChhbmQgbm90IGRpZ2l0YWxTaWduYXR1cmUpIGFuZCBnZXQgTWF0dGVyLWNvbXBhdGlibGUgY2VydGlmaWNhdGUuXG4gICAgICAgICAgICAgICAgICAgIEFwaVBhc3N0aHJvdWdoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBFeHRlbnNpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tRXh0ZW5zaW9uczogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3RJZGVudGlmaWVyOiAnMi41LjI5LjE1JywgIC8vIEtleVVzYWdlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBWYWx1ZTogJ0F3SUJCZz09JywgICAgICAgICAgICAgIC8vIGJpdHN0cmluZyB3aXRoIDcgYml0cyAwMDAwIDAxMVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3JpdGljYWw6IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcmVnaW9uOiBwYXJlbnRSZWdpb24sXG4gICAgICAgICAgICAgICAgcGh5c2ljYWxSZXNvdXJjZUlkOiB7aWQ6IERhdGUubm93KCkudG9TdHJpbmcoKX0gLy8gVXBkYXRlIHBoeXNpY2FsIGlkIHRvIGFsd2F5cyBmZXRjaCB0aGUgbGF0ZXN0IHZlcnNpb25cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwb2xpY3k6IHtcbiAgICAgICAgICAgICAgICBzdGF0ZW1lbnRzOiBbXG4gICAgICAgICAgICAgICAgICAgIG5ldyBQb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb3VyY2VzOiBbcGFyZW50Q0FBcm5dLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uczogWydhY20tcGNhOklzc3VlQ2VydGlmaWNhdGUnXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVmZmVjdDogRWZmZWN0LkFMTE9XLFxuICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGluc3RhbGxMYXRlc3RBd3NTZGs6IHRydWUgICAvLyBTdGFuZGFyZCwgcHJvdmlkZWQgYnkgTGFtYmRhLCB2ZXJzaW9uIGRvZXNuJ3QgaGF2ZSBDdXN0b21FeHRlbnNpb25zIVxuICAgICAgICB9KS5nZXRSZXNwb25zZUZpZWxkKCdDZXJ0aWZpY2F0ZUFybicpO1xuXG4gICAgICAgIGNvbnN0IGNlcnRpZmljYXRlID0gbmV3IEF3c0N1c3RvbVJlc291cmNlKHRoaXMsICdDZXJ0aWZpY2F0ZVBlbScgKyBpZCwge1xuICAgICAgICAgICAgb25VcGRhdGU6IHtcbiAgICAgICAgICAgICAgICBzZXJ2aWNlOiAnQUNNUENBJyxcbiAgICAgICAgICAgICAgICBhY3Rpb246ICdnZXRDZXJ0aWZpY2F0ZScsXG4gICAgICAgICAgICAgICAgcGFyYW1ldGVyczoge1xuICAgICAgICAgICAgICAgICAgICBDZXJ0aWZpY2F0ZUFybjogY2FDZXJ0QXJuLFxuICAgICAgICAgICAgICAgICAgICBDZXJ0aWZpY2F0ZUF1dGhvcml0eUFybjogcGFyZW50Q0FBcm5cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHJlZ2lvbjogcGFyZW50UmVnaW9uLFxuICAgICAgICAgICAgICAgIHBoeXNpY2FsUmVzb3VyY2VJZDoge2lkOiBEYXRlLm5vdygpLnRvU3RyaW5nKCl9IC8vIFVwZGF0ZSBwaHlzaWNhbCBpZCB0byBhbHdheXMgZmV0Y2ggdGhlIGxhdGVzdCB2ZXJzaW9uXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcG9saWN5OiB7XG4gICAgICAgICAgICAgICAgc3RhdGVtZW50czogW1xuICAgICAgICAgICAgICAgICAgICBuZXcgUG9saWN5U3RhdGVtZW50KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc291cmNlczogW3BhcmVudENBQXJuXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbnM6IFsnYWNtLXBjYTpHZXRDZXJ0aWZpY2F0ZSddLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW5zdGFsbExhdGVzdEF3c1NkazogZmFsc2VcbiAgICAgICAgfSkuZ2V0UmVzcG9uc2VGaWVsZCgnQ2VydGlmaWNhdGUnKTtcblxuICAgICAgICBjb25zdCBjYUNlcnRBcm5PdXRwdXROYW1lID0gJ0NlcnRBcm5QQUknICsgcGFpSWQhO1xuXG4gICAgICAgIG5ldyBDZm5PdXRwdXQodGhpcywgY2FDZXJ0QXJuT3V0cHV0TmFtZSwge1xuICAgICAgICAgICAgdmFsdWU6IGNhQ2VydEFybixcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIGNlcnRpZmljYXRlIEFybiBmb3IgUEFJJyArIHBhaUlkISxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgY2FBcm5PdXRwdXROYW1lID0gJ1BBSScgKyBwYWlJZCE7XG5cbiAgICAgICAgbmV3IENmbk91dHB1dCh0aGlzLCBjYUFybk91dHB1dE5hbWUsIHtcbiAgICAgICAgICAgIHZhbHVlOiBcIlZJRD1cIiArIHZlbmRvcklkICsgXCIgUElEPVwiICsgcGlkICsgXCIgQ049XCIgKyBjb21tb25OYW1lICsgXCIgXCIgKyBjZm5DQS5hdHRyQXJuLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdUaGUgQVJOIG9mIFBBSScgKyBwYWlJZCEsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IGNlcnRMaW5rT3V0cHV0TmFtZSA9ICdDZXJ0TGlua1BBSScgKyBwYWlJZCE7XG5cbiAgICAgICAgbmV3IENmbk91dHB1dCh0aGlzLCBjZXJ0TGlua091dHB1dE5hbWUsIHtcbiAgICAgICAgICAgIHZhbHVlOlwiaHR0cHM6Ly9jb25zb2xlLmF3cy5hbWF6b24uY29tL2FjbS1wY2EvaG9tZT9yZWdpb249XCIgKyB0aGlzLnJlZ2lvbiArIFwiIy9kZXRhaWxzP2Fybj1cIiArIGNmbkNBLmF0dHJBcm4gKyBcIiZ0YWI9Y2VydGlmaWNhdGVcIixcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIGxpbmsgdG8gdGhlIFBBSSBjZXJ0aWZpY2F0ZSBpbiB0aGUgQVdTIFByaXZhdGUgQ0EgY29uc29sZScsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBuZXcgcGNhLkNmbkNlcnRpZmljYXRlQXV0aG9yaXR5QWN0aXZhdGlvbih0aGlzLCAnQ2VydEFjdGl2YXRpb24nICsgaWQsIHtcbiAgICAgICAgICAgIGNlcnRpZmljYXRlQXV0aG9yaXR5QXJuOiBjZm5DQS5hdHRyQXJuLFxuICAgICAgICAgICAgY2VydGlmaWNhdGU6IGNlcnRpZmljYXRlLFxuICAgICAgICAgICAgY2VydGlmaWNhdGVDaGFpbjogcGFyZW50UGVtLFxuICAgICAgICAgICAgc3RhdHVzOiBcIkFDVElWRVwiXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgZ2V0Q2VydGlmaWNhdGVQZW0oaWQ6IHN0cmluZywgcGFyZW50Q0FBcm46IHN0cmluZywgcGFyZW50UmVnaW9uOiBzdHJpbmcpIHtcbiAgICAgICAgLy8gTmVlZCB0byByZW1vdmUgbmV3bGluZSBjaGFyYWN0ZXJzIGFzIHdlJ3JlIGdvaW5nIHRvIHBhc3MgaXQgaW50byBKU09OIGF0dHJpYnV0ZS5cbiAgICAgICAgcmV0dXJuIG5ldyBBd3NDdXN0b21SZXNvdXJjZSh0aGlzLCAnUGFhUGVtJyArIGlkLCB7XG4gICAgICAgICAgICBvblVwZGF0ZToge1xuICAgICAgICAgICAgICAgIHNlcnZpY2U6ICdBQ01QQ0EnLFxuICAgICAgICAgICAgICAgIGFjdGlvbjogJ2dldENlcnRpZmljYXRlQXV0aG9yaXR5Q2VydGlmaWNhdGUnLFxuICAgICAgICAgICAgICAgIHBhcmFtZXRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgQ2VydGlmaWNhdGVBdXRob3JpdHlBcm46IHBhcmVudENBQXJuXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICByZWdpb246IHBhcmVudFJlZ2lvbixcbiAgICAgICAgICAgICAgICBwaHlzaWNhbFJlc291cmNlSWQ6IHtpZDogRGF0ZS5ub3coKS50b1N0cmluZygpfSAvLyBVcGRhdGUgcGh5c2ljYWwgaWQgdG8gYWx3YXlzIGZldGNoIHRoZSBsYXRlc3QgdmVyc2lvblxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHBvbGljeToge1xuICAgICAgICAgICAgICAgIHN0YXRlbWVudHM6IFtcbiAgICAgICAgICAgICAgICAgICAgbmV3IFBvbGljeVN0YXRlbWVudCh7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvdXJjZXM6IFtwYXJlbnRDQUFybl0sXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbJ2FjbS1wY2E6R2V0Q2VydGlmaWNhdGVBdXRob3JpdHlDZXJ0aWZpY2F0ZSddLFxuICAgICAgICAgICAgICAgICAgICAgICAgZWZmZWN0OiBFZmZlY3QuQUxMT1csXG4gICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW5zdGFsbExhdGVzdEF3c1NkazogZmFsc2VcbiAgICAgICAgfSkuZ2V0UmVzcG9uc2VGaWVsZCgnQ2VydGlmaWNhdGUnKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGNyZWF0ZURhY0lzc3VpbmdMYW1iZGEoZGFjVmFsaWRpdHlJbkRheXM6IG51bWJlcikge1xuICAgICAgICBjb25zdCBsYW1iZGFUaW1lb3V0ID0gRHVyYXRpb24ubWludXRlcygxKTtcbiAgICAgICAgY29uc3QgbGFtYmRhQmF0Y2hTaXplID0gNTtcbiAgICAgICAgY29uc3QgcGNhSXNzdWVDZXJ0aWZpY2F0ZU1heFRwcyA9IDI1O1xuICAgICAgICBjb25zdCBsYW1iZGFBdmdFeGVjVGltZUluU2Vjb25kcyA9IDExO1xuXG4gICAgICAgIGNvbnN0IHMzVG9TcXMgPSBuZXcgUzNUb1Nxcyh0aGlzLCAnRGFjSW5wdXRTM1RvU1FTJywge1xuICAgICAgICAgICAgczNFdmVudEZpbHRlcnM6IFtcbiAgICAgICAgICAgICAgICB7cHJlZml4OiAnJywgc3VmZml4OiAnLmNzcid9XG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgcXVldWVQcm9wczoge1xuICAgICAgICAgICAgICAgIHZpc2liaWxpdHlUaW1lb3V0OiBEdXJhdGlvbi5taW51dGVzKGxhbWJkYVRpbWVvdXQudG9NaW51dGVzKCkgKiA2KSwgIC8vIExhbWJkYSdzIHJlY29tbWVuZGVkIGF0IGxlYXN0IDYgdGltZXMuXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBUYWdzLm9mKHMzVG9TcXMuc3FzUXVldWUpLmFkZChNYXR0ZXJTdGFjay5tYXR0ZXJQS0lUYWcsIFwiXCIpO1xuICAgICAgICBUYWdzLm9mKHMzVG9TcXMuZGVhZExldHRlclF1ZXVlIS5xdWV1ZSkuYWRkKE1hdHRlclN0YWNrLm1hdHRlclBLSVRhZywgXCJcIik7XG4gICAgICAgIFRhZ3Mub2YoczNUb1Nxcy5zM0J1Y2tldCEpLmFkZChNYXR0ZXJTdGFjay5tYXR0ZXJQS0lUYWcsIFwiXCIpO1xuICAgICAgICBUYWdzLm9mKHMzVG9TcXMuczNMb2dnaW5nQnVja2V0ISkuYWRkKE1hdHRlclN0YWNrLm1hdHRlclBLSVRhZywgXCJcIik7XG5cbiAgICAgICAgczNUb1Nxcy5zM0xvZ2dpbmdCdWNrZXQ/LmdyYW50UmVhZCh0aGlzLm1hdHRlckF1ZGl0b3JSb2xlKTtcblxuICAgICAgICBjb25zdCBzcXNUb0xhbWJkYSA9IG5ldyBTcXNUb0xhbWJkYSh0aGlzLCAnU3FzVG9EYWNJc3N1aW5nTGFtYmRhJywge1xuICAgICAgICAgICAgZXhpc3RpbmdRdWV1ZU9iajogczNUb1Nxcy5zcXNRdWV1ZSxcbiAgICAgICAgICAgIGxhbWJkYUZ1bmN0aW9uUHJvcHM6IHtcbiAgICAgICAgICAgICAgICAvLyBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vbGFtYmRhL2xhdGVzdC9kZy9qYXZhLXBhY2thZ2UuaHRtbCNqYXZhLXBhY2thZ2UtZ3JhZGxlXG4gICAgICAgICAgICAgICAgY29kZTogbGFtYmRhLkNvZGUuZnJvbUFzc2V0KCdsYW1iZGEvYnVpbGQvZGlzdHJpYnV0aW9ucy9sYW1iZGEuemlwJyksXG4gICAgICAgICAgICAgICAgcnVudGltZTogbGFtYmRhLlJ1bnRpbWUuSkFWQV8xMSxcbiAgICAgICAgICAgICAgICBoYW5kbGVyOiAnY29tLnNhbXBsZS5IYW5kbGVyJyxcblxuICAgICAgICAgICAgICAgIHRpbWVvdXQ6IGxhbWJkYVRpbWVvdXQsXG4gICAgICAgICAgICAgICAgbWVtb3J5U2l6ZTogNTEyLFxuICAgICAgICAgICAgICAgIHJlc2VydmVkQ29uY3VycmVudEV4ZWN1dGlvbnM6IHBjYUlzc3VlQ2VydGlmaWNhdGVNYXhUcHMgLyBsYW1iZGFCYXRjaFNpemUgKiBsYW1iZGFBdmdFeGVjVGltZUluU2Vjb25kcyxcblxuICAgICAgICAgICAgICAgIGxvZ1JldGVudGlvbjogUmV0ZW50aW9uRGF5cy5UV09fTU9OVEhTLFxuICAgICAgICAgICAgICAgIGVudmlyb25tZW50OiB7XG4gICAgICAgICAgICAgICAgICAgIFwiZGFjVmFsaWRpdHlJbkRheXNcIjogZGFjVmFsaWRpdHlJbkRheXMudG9TdHJpbmcoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBtYXhSZWNlaXZlQ291bnQ6IDUsIC8vIE51bWJlciBvZiByZXRyaWVzXG4gICAgICAgICAgICBzcXNFdmVudFNvdXJjZVByb3BzOiB7XG4gICAgICAgICAgICAgICAgcmVwb3J0QmF0Y2hJdGVtRmFpbHVyZXM6IHRydWUsXG4gICAgICAgICAgICAgICAgYmF0Y2hTaXplOiBsYW1iZGFCYXRjaFNpemUsXG4gICAgICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgVGFncy5vZihzcXNUb0xhbWJkYS5sYW1iZGFGdW5jdGlvbikuYWRkKE1hdHRlclN0YWNrLm1hdHRlclBLSVRhZywgXCJcIik7XG5cbiAgICAgICAgczNUb1Nxcy5zM0J1Y2tldCEuZ3JhbnRSZWFkV3JpdGUoc3FzVG9MYW1iZGEubGFtYmRhRnVuY3Rpb24pO1xuXG4gICAgICAgIGZvciAoY29uc3Qgc3RtdCBvZiB0aGlzLmdldFBvbGljeVN0YXRlbWVudHNGb3JEQUNJc3N1YW5jZSgpKSB7XG4gICAgICAgICAgICBzcXNUb0xhbWJkYS5sYW1iZGFGdW5jdGlvbi5hZGRUb1JvbGVQb2xpY3koc3RtdCk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhdWRpdG9yTG9nR3JvdXBBY3Rpb25zID0gW1wibG9nczpEZXNjcmliZSpcIixcbiAgICAgICAgICAgIFwibG9nczpHZXQqXCIsXG4gICAgICAgICAgICBcImxvZ3M6TGlzdCpcIixcbiAgICAgICAgICAgIFwibG9nczpTdGFydFF1ZXJ5XCIsXG4gICAgICAgICAgICBcImxvZ3M6U3RvcFF1ZXJ5XCIsXG4gICAgICAgICAgICBcImxvZ3M6VGVzdE1ldHJpY0ZpbHRlclwiLFxuICAgICAgICAgICAgXCJsb2dzOkZpbHRlckxvZ0V2ZW50c1wiXVxuICAgICAgICBzcXNUb0xhbWJkYS5sYW1iZGFGdW5jdGlvbi5sb2dHcm91cC5ncmFudCh0aGlzLm1hdHRlckF1ZGl0b3JSb2xlLCAuLi5hdWRpdG9yTG9nR3JvdXBBY3Rpb25zKTtcblxuICAgICAgICBuZXcgQ2ZuT3V0cHV0KHRoaXMsICdEQUNJc3N1aW5nTGFtYmRhRnVuY3Rpb25OYW1lJywge1xuICAgICAgICAgICAgdmFsdWU6IHNxc1RvTGFtYmRhLmxhbWJkYUZ1bmN0aW9uLmZ1bmN0aW9uTmFtZSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIG5hbWUgb2YgdGhlIExhbWJkYSBGdW5jdGlvbiB0aGF0IGlzc3VlcyBEQUNzJyxcbiAgICAgICAgfSk7XG4gICAgfVxufSJdfQ==